import { prisma } from '../db/client';
import { getServerConfig } from '../config/serverConfigService';
import { EmbedBuilder, type Client, type TextChannel } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { checkRapidBetting, checkAbnormalWinrate } from './antifraud';

let _client: Client | null = null;

export function setLogClient(client: Client) {
  _client = client;
}

export function getLogClient(): Client | null {
  return _client;
}

// ─── Утилита: безопасная отправка embed в канал ───

async function safeSendToChannel(channelId: string, embed: EmbedBuilder) {
  if (!_client) return;
  try {
    const channel = await _client.channels.fetch(channelId) as TextChannel | null;
    if (channel?.isTextBased()) {
      await channel.send({ embeds: [embed] });
    }
  } catch (err) {
    console.error(`[Log] Failed to send to channel ${channelId}:`, err);
  }
}

// ─── logBet ───

export async function logBet(options: {
  serverId: string;
  userId: string;
  gameType: string;
  betAmount: number;
  payoutAmount: number;
  outcome: string;
  seed: string;
}) {
  const { serverId, userId, gameType, betAmount, payoutAmount, outcome, seed } = options;

  await prisma.betLog.create({
    data: { serverId, userId, gameType, betAmount, payoutAmount, outcome, seed },
  });

  // Лог-канал: аудит ставки + seed
  sendBetAuditLog(options).catch(() => {});

  // Канал объявлений: крупные победы
  if (outcome === 'win' && payoutAmount > 0) {
    sendBigWinAnnouncement(options).catch(() => {});
  }

  // Антифрод (не блокируем игру)
  if (_client) {
    checkRapidBetting(_client, serverId, userId).catch(() => {});
    if (outcome === 'win') {
      checkAbnormalWinrate(_client, serverId, userId).catch(() => {});
    }
  }
}

// ─── logBalanceChange - лог изменения баланса в лог-канал ───

export async function logBalanceChange(options: {
  serverId: string;
  userId: string;
  delta: number;
  reason: string;
  newBalance: number;
}) {
  if (!_client) return;

  const config = await getServerConfig(options.serverId);
  if (!config?.logChannelId) return;

  const sign = options.delta >= 0 ? '+' : '';
  const emoji = options.delta >= 0 ? UI_CONFIG.EMOJI.PLUS : UI_CONFIG.EMOJI.MINUS;

  const embed = new EmbedBuilder()
    .setTitle(`${emoji} Изменение баланса`)
    .addFields(
      { name: 'Игрок', value: `<@${options.userId}>`, inline: true },
      { name: 'Изменение', value: `${sign}${options.delta}`, inline: true },
      { name: 'Новый баланс', value: `${options.newBalance}`, inline: true },
      { name: 'Причина', value: options.reason, inline: false },
    )
    .setColor(options.delta >= 0 ? UI_CONFIG.COLORS.BALANCE_UP : UI_CONFIG.COLORS.BALANCE_DOWN)
    .setTimestamp();

  await safeSendToChannel(config.logChannelId, embed);
}

// ─── Аудит ставки (seed + детали) ───

async function sendBetAuditLog(options: {
  serverId: string;
  userId: string;
  gameType: string;
  betAmount: number;
  payoutAmount: number;
  outcome: string;
  seed: string;
}) {
  const config = await getServerConfig(options.serverId);
  if (!config?.logChannelId) return;

  const outcomeEmoji = options.outcome === 'win' ? UI_CONFIG.EMOJI.WIN
    : options.outcome === 'lose' ? UI_CONFIG.EMOJI.LOSS
    : UI_CONFIG.EMOJI.INFO;

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Аудит ставки`)
    .addFields(
      { name: 'Игрок', value: `<@${options.userId}>`, inline: true },
      { name: 'Игра', value: options.gameType, inline: true },
      { name: 'Результат', value: `${outcomeEmoji} ${options.outcome}`, inline: true },
      { name: 'Ставка', value: `${options.betAmount}`, inline: true },
      { name: 'Выплата', value: `${options.payoutAmount}`, inline: true },
      { name: 'Seed (RNG)', value: `\`${options.seed}\``, inline: false },
    )
    .setColor(options.outcome === 'win' ? UI_CONFIG.COLORS.WIN : options.outcome === 'lose' ? UI_CONFIG.COLORS.LOSS : UI_CONFIG.COLORS.PRIMARY)
    .setTimestamp();

  await safeSendToChannel(config.logChannelId, embed);
}

// ─── Объявления крупных побед ───

async function sendBigWinAnnouncement(options: {
  serverId: string;
  userId: string;
  gameType: string;
  betAmount: number;
  payoutAmount: number;
  outcome: string;
  seed: string;
}) {
  const config = await getServerConfig(options.serverId);
  if (!config?.announceChannelId) return;

  const threshold = config.bigWinThreshold ?? 500;
  if (options.payoutAmount < threshold) return;

  const gameNames: Record<string, string> = {
    dice: 'Кости',
    dicepoker: 'Покер на кубиках',
    intervention: 'Интервенция 21.5',
    blind: 'Покер',
    duel: 'Дуэль',
    tug: 'Перетягивание каната',
    poker: 'Покер (2 vs 3 кости)',
  };

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.WIN} Крупная победа!`)
    .setDescription(
      `${UI_CONFIG.EMOJI.FIRE} <@${options.userId}> выиграл **${options.payoutAmount}** ${UI_CONFIG.EMOJI.COIN} ` +
      `в игре **${gameNames[options.gameType] ?? options.gameType}**!`,
    )
    .addFields(
      { name: 'Ставка', value: `${options.betAmount}`, inline: true },
      { name: 'Выигрыш', value: `${options.payoutAmount}`, inline: true },
    )
    .setColor(UI_CONFIG.COLORS.GOLD)
    .setTimestamp();

  await safeSendToChannel(config.announceChannelId, embed);
}

