/**
 * Очистка данных из БД: рейтинг, статистика игр, балансы.
 * Каналы и настройки ServerConfig сохраняются.
 */
import { prisma } from '../db/client';

const DEFAULT_START_BALANCE = 1000;

async function main() {
  const r1 = await prisma.arenaFightWin.deleteMany({});
  console.log(`ArenaFightWin (рейтинг): ${r1.count}`);

  const r2 = await prisma.betLog.deleteMany({});
  console.log(`BetLog (статистика игр): ${r2.count}`);

  const r3 = await prisma.balanceLog.deleteMany({});
  console.log(`BalanceLog: ${r3.count}`);

  const configs = await prisma.serverConfig.findMany({
    select: { serverId: true, startBalance: true },
  });
  const startByServer = new Map(configs.map((c) => [c.serverId, c.startBalance ?? DEFAULT_START_BALANCE]));

  const profiles = await prisma.userProfile.findMany({ select: { userId: true, serverId: true } });
  for (const p of profiles) {
    const start = startByServer.get(p.serverId) ?? DEFAULT_START_BALANCE;
    await prisma.userProfile.update({
      where: { userId_serverId: { userId: p.userId, serverId: p.serverId } },
      data: {
        balance: BigInt(start),
        totalWon: BigInt(0),
        totalLost: BigInt(0),
        lastDailyAt: null,
      },
    });
  }
  console.log(`UserProfile (балансы сброшены): ${profiles.length}`);

  await prisma.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
