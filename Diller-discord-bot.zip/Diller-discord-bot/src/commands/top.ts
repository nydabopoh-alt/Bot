import { EmbedBuilder } from 'discord.js';
import type { Client } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { getTopByArenaFightWins, getTeamFightRosters, ARENA_FIGHT_TYPES } from '../services/economy';
import { getServerConfig } from '../config/serverConfigService';
import { prisma } from '../db/client';

const TOP_PLACES = 5;

/** Невидимый символ для выравнивания рейтинга */
const PAD = '\u3164'.repeat(10);

const PLACE_LABELS = [`Чемпион${PAD}`, `2 место${PAD}`, `3 место${PAD}`, `4 место${PAD}`, `5 место${PAD}`];

/** Картинка-разделитель между местами (как на скрине) */
const RATING_DIVIDER_IMAGE =
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471471443958173856/dc5a9a3aee99cb4d.png';

/** Иконки мест (1–5) как на скрине */
const PLACE_ICONS = [
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471462089792028752/111.png',
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471462088068042832/2222.png',
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471462086847627326/333.png',
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471462088680538175/4444.png',
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471462087422378079/555.png',
];

/** Цвета эмбедов по форматам боёв */
const RATING_COLORS: Record<string, number> = {
  white_flag: 0xc0392b,   // тёмно-красный
  team_fight: 0x2980b9,  // синий
  funeral_fight: 0x2c3e50, // тёмно-серый
};

/** Баннеры и картинки по форматам */
const DEFAULT_FORMAT_CONFIG: Record<string, { title: string; bannerImage: string }> = {
  white_flag: {
    title: ' ',
    bannerImage: 'https://cdn.discordapp.com/attachments/1471462038998880430/1471471881453437019/304eff1c0b8537ea.png',
  },
  team_fight: {
    title: ' ',
    bannerImage: 'https://cdn.discordapp.com/attachments/1471462038998880430/1471471868375728212/ee0862f491eefca3.png',
  },
  funeral_fight: {
    title: ' ',
    bannerImage: 'https://cdn.discordapp.com/attachments/1471462038998880430/1471482936460312667/2b3c6b7a28d09fe8.png',
  },
};

type RatingFormatConfig = Record<string, { title?: string; image?: string }>;

/** Текст для места. Без лишней пустой строки между заголовком и данными. */
function getPlaceText(
  index: number,
  userId?: string,
  winsCount?: number,
  teamName?: string,
  roster?: { userId: string; winsInTeam: number }[],
): string {
  const label = PLACE_LABELS[index] ?? `${index + 1} место${PAD}`;
  if (teamName != null && winsCount != null) {
    let text = `# ${label}\n**${teamName}** — **${winsCount}** побед в битвах`;
    if (roster && roster.length > 0) {
      const members = roster.slice(0, 10).map((r) => `<@${r.userId}>`).join(', ');
      const more = roster.length > 10 ? '…' : '';
      text += `\n_Состав:_ ${members}${more}`;
    }
    return text;
  }
  if (userId != null && winsCount != null) {
    return `# ${label}\n<@${userId}> — **${winsCount}** побед в битвах`;
  }
  return `# ${label}\n@ Имя (пишет админ)`;
}

/** 10 эмбедов по формату: баннер + 5 блоков (иконка + текст) + 4 разделителя между ними, как на скрине */
async function buildFormatRatingEmbeds(
  serverId: string,
  eventType: string,
  config: { title?: string; image?: string } | null,
): Promise<EmbedBuilder[]> {
  const users = await getTopByArenaFightWins(serverId, eventType, TOP_PLACES);
  const def = DEFAULT_FORMAT_CONFIG[eventType] ?? { title: eventType, bannerImage: '' };
  const bannerImage = config?.image?.trim() || def.bannerImage;

  const embeds: EmbedBuilder[] = [];
  const color = RATING_COLORS[eventType] ?? UI_CONFIG.COLORS.GOLD;

  // 1. Баннер сверху
  const bannerEmbed = new EmbedBuilder().setColor(color);
  if (bannerImage) bannerEmbed.setImage(bannerImage);
  embeds.push(bannerEmbed);

  // 2–6. 5 мест: каждый блок = иконка + текст + разделитель
  let rosters: Record<string, { userId: string; winsInTeam: number }[]> = {};
  if (eventType === 'team_fight') {
    const teamNames = users.map((u) => u.teamName).filter((t): t is string => !!t);
    rosters = await getTeamFightRosters(serverId, teamNames);
  }

  for (let i = 0; i < TOP_PLACES; i++) {
    const user = users[i];
    const roster = user?.teamName ? rosters[user.teamName] : undefined;
    const text = getPlaceText(i, user?.userId, user?.winsCount, user?.teamName, roster);
    const icon = PLACE_ICONS[i] ?? PLACE_ICONS[0];

    embeds.push(
      new EmbedBuilder()
        .setThumbnail(icon)
        .setDescription(text)
        .setImage(RATING_DIVIDER_IMAGE)
        .setColor(color),
    );
  }

  return embeds;
}

/** Payload для одного формата (10 эмбедов). Для обратной совместимости — один общий payload. */
export async function buildRatingMessagePayload(
  serverId: string,
  config: { ratingFormatConfig?: RatingFormatConfig | null } | null,
): Promise<{ formatPayloads: { embeds: EmbedBuilder[] }[] }> {
  const formatConfig = (config?.ratingFormatConfig as RatingFormatConfig) ?? {};

  const formatPayloads: { embeds: EmbedBuilder[] }[] = [];
  for (const eventType of ARENA_FIGHT_TYPES) {
    const cfg = formatConfig[eventType] ?? null;
    const embeds = await buildFormatRatingEmbeds(serverId, eventType, cfg);
    formatPayloads.push({ embeds });
  }
  return { formatPayloads };
}


const MSG_ID_SEP = '|';

/** Обновить сообщения с рейтингом в канале (3 сообщения — по одному на формат). Если сообщения удалены — переотправляет. */
export async function updateRatingMessage(client: Client, serverId: string): Promise<boolean> {
  const config = await getServerConfig(serverId);
  const channelId = config?.ratingChannelId ?? null;
  const messageIdsRaw = (config as { ratingMessageId?: string | null })?.ratingMessageId ?? null;

  if (!channelId) return false;

  // Нет сохранённых id — отправляем впервые
  if (!messageIdsRaw?.trim()) {
    const newIds = await sendRatingMessage(client, serverId, channelId);
    if (newIds) {
      const { updateServerRatingEmbed } = await import('../config/serverConfigService');
      await updateServerRatingEmbed(serverId, { ratingMessageId: newIds });
      return true;
    }
    return false;
  }

  const messageIds = messageIdsRaw.includes(MSG_ID_SEP) ? messageIdsRaw.split(MSG_ID_SEP) : [messageIdsRaw];

  try {
    const channel = await client.channels.fetch(channelId);
    if (!channel?.isTextBased()) return false;

    const { formatPayloads } = await buildRatingMessagePayload(serverId, config as any);
    const textChannel = channel as import('discord.js').TextChannel;

    if (messageIds.length === formatPayloads.length) {
      let allExist = true;
      for (let i = 0; i < formatPayloads.length; i++) {
        const msg = await textChannel.messages.fetch(messageIds[i]).catch(() => null);
        if (msg) {
          await msg.edit(formatPayloads[i]);
        } else {
          allExist = false;
        }
      }
      if (allExist) return true;
    }

    // Сообщения удалены или миграция: пересоздаём
    for (const id of messageIds) {
      try {
        await textChannel.messages.delete(id);
      } catch {
        /* ignore */
      }
    }
    const newIds = await sendRatingMessage(client, serverId, channelId);
    if (newIds) {
      const { updateServerRatingEmbed } = await import('../config/serverConfigService');
      await updateServerRatingEmbed(serverId, { ratingMessageId: newIds });
    }
    return !!newIds;
  } catch {
    return false;
  }
}

/** Отправить 3 сообщения рейтинга (по формату) и вернуть "id1|id2|id3". */
export async function sendRatingMessage(
  client: Client,
  serverId: string,
  channelId: string,
): Promise<string | null> {
  const config = await getServerConfig(serverId);
  const { formatPayloads } = await buildRatingMessagePayload(serverId, config as any);

  try {
    const channel = await client.channels.fetch(channelId);
    if (!channel?.isTextBased()) return null;
    const textChannel = channel as import('discord.js').TextChannel;

    const ids: string[] = [];
    for (const payload of formatPayloads) {
      const msg = await textChannel.send(payload);
      ids.push(msg.id);
    }
    return ids.join(MSG_ID_SEP);
  } catch {
    return null;
  }
}

const MINUTE_MS = 60 * 1000;
const DAILY_HOUR_UTC = 12;

let ratingSchedulerInterval: ReturnType<typeof setInterval> | null = null;

async function tickRatingUpdate(client: Client) {
  try {
    const configs = await prisma.serverConfig.findMany({
      where: {
        autoRatingInterval: { not: 'none' },
        ratingChannelId: { not: null },
      },
      select: { serverId: true, autoRatingInterval: true },
    });
    const now = new Date();
    const minute = now.getUTCMinutes();
    const hour = now.getUTCHours();

    for (const c of configs) {
      const interval = c.autoRatingInterval ?? 'none';
      const runMinute = interval === 'minute';
      const runHour = (interval === 'hour' || interval === 'hourly') && minute === 0;
      const runDay = (interval === 'day' || interval === 'daily' || interval === 'weekly') && hour === DAILY_HOUR_UTC && minute === 0;
      if (runMinute || runHour || runDay) {
        await updateRatingMessage(client, c.serverId);
      }
    }
  } catch (e) {
    console.error('[Rating] Scheduler tick error:', e);
  }
}

/** Запуск планировщика: обновление рейтинга каждую минуту (minute / hour / day). */
export function startRatingScheduler(client: Client) {
  if (ratingSchedulerInterval) return;

  const tick = () => tickRatingUpdate(client);

  ratingSchedulerInterval = setInterval(tick, MINUTE_MS);
  setTimeout(tick, 30 * 1000);
  console.log('[Rating] Scheduler started (tick every minute)');
}

export function stopRatingScheduler() {
  if (ratingSchedulerInterval) {
    clearInterval(ratingSchedulerInterval);
    ratingSchedulerInterval = null;
    console.log('[Rating] Scheduler stopped');
  }
}
