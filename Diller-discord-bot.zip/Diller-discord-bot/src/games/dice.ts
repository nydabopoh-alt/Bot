import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  EmbedBuilder,
  ModalSubmitInteraction,
  MessageFlags,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier, creditAdminCommissionFromPayout } from '../services/economy';
import { logBet } from '../services/logs';
import { checkBetPerMinuteLimit, checkWinPerHourLimit } from '../services/limits';
import { setSession, getSession, deleteSession } from '../services/sessions';

const DICE_SYMBOLS = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'] as const;

export function diceStr(n: number): string {
  return n >= 1 && n <= 6 ? DICE_SYMBOLS[n] : String(n);
}

export type CeeloResult =
  | { type: 'instant_win'; multiplier: number; label: string }
  | { type: 'instant_123'; multiplier: number; label: string }
  | { type: 'instant_loss'; label: string }
  | { type: 'point'; point: number }
  | { type: 'reroll' };

/** Комбо = автоматический выигрыш (456, 123, трипс, пара+6) */
export function isCeeloCombo(r: CeeloResult): boolean {
  return r.type === 'instant_win' || r.type === 'instant_123';
}

export function evaluateCeelo(d1: number, d2: number, d3: number): CeeloResult {
  const sorted = [d1, d2, d3].sort((a, b) => a - b);

  if (sorted[0] === 4 && sorted[1] === 5 && sorted[2] === 6) {
    return { type: 'instant_win', multiplier: 2, label: `${diceStr(4)}${diceStr(5)}${diceStr(6)}` };
  }
  if (sorted[0] === 1 && sorted[1] === 2 && sorted[2] === 3) {
    return { type: 'instant_123', multiplier: 1.5, label: `${diceStr(1)}${diceStr(2)}${diceStr(3)}` };
  }
  if (d1 === d2 && d2 === d3) {
    return { type: 'instant_win', multiplier: 3, label: `Трипс ${diceStr(d1)}${diceStr(d2)}${diceStr(d3)}` };
  }
  if (
    (d1 === d2 && d3 === 6) || (d1 === d3 && d2 === 6) || (d2 === d3 && d1 === 6)
  ) {
    return { type: 'instant_win', multiplier: 1.5, label: `Пара + ${diceStr(6)}` };
  }
  if (d1 === d2) return { type: 'point', point: d3 };
  if (d1 === d3) return { type: 'point', point: d2 };
  if (d2 === d3) return { type: 'point', point: d1 };
  return { type: 'reroll' };
}

interface DiceSession {
  betAmount: number;
  rerollsLeft: number;
  seed: string;
  memberRoleIds: string[];
}

export { buildDiceStartEmbed, showDiceBetModal } from './diceEmbed';

export async function handleDiceBetModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const serverId = interaction.guild.id;
  const userId = interaction.user.id;
  const betRaw = interaction.fields.getTextInputValue('bet_amount');
  const betAmount = Number.parseInt(betRaw, 10);

  if (Number.isNaN(betAmount) || betAmount <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма ставки.`, flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(serverId);
  const profile = await getOrCreateProfile(serverId, userId);

  if (betAmount < config.minBet || betAmount > config.maxBet) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ставка должна быть между ${config.minBet} и ${config.maxBet}.`, flags: MessageFlags.Ephemeral });
  }
  if (profile.balance < BigInt(betAmount)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance}.`, flags: MessageFlags.Ephemeral });
  }

  const limitCheck = await checkBetPerMinuteLimit(serverId, userId);
  if (!limitCheck.ok) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} ${limitCheck.reason}`, flags: MessageFlags.Ephemeral });
  }

  await adjustBalance({ serverId, userId, delta: -betAmount, reason: 'dice_bet' });

  const seed = crypto.randomUUID();
  const member = interaction.member as { roles?: { cache?: { map: (fn: (r: { id: string }) => string) => string[] } } };
  const memberRoleIds: string[] = member?.roles?.cache?.map((r: { id: string }) => r.id) ?? [];
  const sessionKey = `dice:${serverId}:${userId}`;
  await setSession<DiceSession>(sessionKey, { betAmount, rerollsLeft: 2, seed, memberRoleIds });

  return rollDice(interaction, serverId, userId);
}

async function rollDice(
  interaction: ModalSubmitInteraction | ButtonInteraction,
  serverId: string,
  userId: string,
) {
  const sessionKey = `dice:${serverId}:${userId}`;
  const session = await getSession<DiceSession>(sessionKey);
  if (!session) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия истекла.`, flags: MessageFlags.Ephemeral });
  }

  const d1 = crypto.randomInt(1, 7);
  const d2 = crypto.randomInt(1, 7);
  const d3 = crypto.randomInt(1, 7);
  const result = evaluateCeelo(d1, d2, d3);

  const lines: string[] = [];
  lines.push(`${UI_CONFIG.EMOJI.DICE} Бросок:\n**\`${diceStr(d1)}\` \`${diceStr(d2)}\` \`${diceStr(d3)}\`**`);

  if (result.type === 'instant_win' || result.type === 'instant_123') {
    const vipMul = await getVipMultiplier(serverId, session.memberRoleIds);
    const config = await getServerConfig(serverId);
    const rawPayout = Math.floor(session.betAmount * result.multiplier);
    const payout = calculatePayout(rawPayout, vipMul, config?.casinoCommission);
    await creditAdminCommissionFromPayout(serverId, rawPayout, config?.casinoCommission);

    let actualPayout = payout;
    const winLimit = await checkWinPerHourLimit(serverId, userId, payout);
    if (!winLimit.ok) actualPayout = 0;

    if (actualPayout > 0) {
      await adjustBalance({ serverId, userId, delta: actualPayout, reason: 'dice_payout' });
    }

    const profile = await getOrCreateProfile(serverId, userId);
    await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: actualPayout, outcome: 'win', seed: session.seed });
    await deleteSession(sessionKey);

    lines.push(`Комбинация: **${result.label}** (x${result.multiplier})`);
    lines.push(`${UI_CONFIG.EMOJI.WIN} Выигрыш: **${actualPayout}**`);
    lines.push(`Баланс: **${profile.balance}**`);

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — Победа!`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.WIN);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:bet').setLabel('Ещё разок').setStyle(ButtonStyle.Success),
    );

    return replyOrUpdate(interaction, { embeds: [embed], components: [row] });
  }

  if (result.type === 'instant_loss') {
    await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: 0, outcome: 'lose', seed: session.seed });
    await deleteSession(sessionKey);
    const profile = await getOrCreateProfile(serverId, userId);
    lines.push(`Комбинация: **${result.label}** — проигрыш!`);
    lines.push(`${UI_CONFIG.EMOJI.LOSS} Фляга забрала **${session.betAmount}** септимов`);
    lines.push(`Баланс: **${profile.balance}**`);

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — Проигрыш`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.LOSS);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:bet').setLabel('Ещё разок').setStyle(ButtonStyle.Success),
    );

    return replyOrUpdate(interaction, { embeds: [embed], components: [row] });
  }

  if (result.type === 'point') {
    lines.push(`Ваше очко: **${diceStr(result.point)}** (${result.point})`);
    lines.push(`Крысёныш бросает кости...`);

    let botPoint = 0;
    let botD1 = 0, botD2 = 0, botD3 = 0;
    for (let attempt = 0; attempt < 5; attempt++) {
      botD1 = crypto.randomInt(1, 7);
      botD2 = crypto.randomInt(1, 7);
      botD3 = crypto.randomInt(1, 7);
      const botResult = evaluateCeelo(botD1, botD2, botD3);
      if (botResult.type === 'instant_win') {
        botPoint = 99;
        break;
      }
      if (botResult.type === 'instant_123' || botResult.type === 'instant_loss') {
        botPoint = -1;
        break;
      }
      if (botResult.type === 'point') {
        botPoint = botResult.point;
        break;
      }
    }

    const botPointStr = botPoint >= 0 ? (botPoint === 99 ? 'комбо' : `${diceStr(botPoint)} (${botPoint})`) : 'проигрыш';
    lines.push(`Бот бросил: **${diceStr(botD1)}** **${diceStr(botD2)}** **${diceStr(botD3)}** (очко: **${botPointStr}**)`);

    const playerWins = botPoint < 0 || (botPoint < 99 && result.point > botPoint);
    const isDraw = botPoint >= 0 && botPoint < 99 && result.point === botPoint;

    const config = await getServerConfig(serverId);
    if (playerWins) {
      const vipMul2 = await getVipMultiplier(serverId, session.memberRoleIds);
      const rawPayout2 = session.betAmount * 2;
      const payout = calculatePayout(rawPayout2, vipMul2, config?.casinoCommission);
      await creditAdminCommissionFromPayout(serverId, rawPayout2, config?.casinoCommission);
      let actualPayout = payout;
      const winLimit = await checkWinPerHourLimit(serverId, userId, payout);
      if (!winLimit.ok) actualPayout = 0;
      if (actualPayout > 0) await adjustBalance({ serverId, userId, delta: actualPayout, reason: 'dice_payout' });
      await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: actualPayout, outcome: 'win', seed: session.seed });
      const profile = await getOrCreateProfile(serverId, userId);
      lines.push(`${UI_CONFIG.EMOJI.WIN} Вы выиграли **${actualPayout}**!`);
      lines.push(`Баланс: **${profile.balance}**`);
    } else if (isDraw) {
      await adjustBalance({ serverId, userId, delta: session.betAmount, reason: 'dice_draw_refund' });
      await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: session.betAmount, outcome: 'draw', seed: session.seed });
      const profile = await getOrCreateProfile(serverId, userId);
      lines.push(`Ничья! Ставка возвращена.`);
      lines.push(`Баланс: **${profile.balance}**`);
    } else {
      await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: 0, outcome: 'lose', seed: session.seed });
      const profile = await getOrCreateProfile(serverId, userId);
      lines.push(`${UI_CONFIG.EMOJI.LOSS} Вы проиграли **${session.betAmount}**`);
      lines.push(`Баланс: **${profile.balance}**`);
    }

    await deleteSession(sessionKey);

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — Результат`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.DICE);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:bet').setLabel('Ещё разок').setStyle(ButtonStyle.Success),
    );

    return replyOrUpdate(interaction, { embeds: [embed], components: [row] });
  }

  if (session.rerollsLeft <= 0) {
    await adjustBalance({ serverId, userId, delta: session.betAmount, reason: 'dice_reroll_refund' });
    await logBet({ serverId, userId, gameType: 'dice', betAmount: session.betAmount, payoutAmount: session.betAmount, outcome: 'draw', seed: session.seed });
    await deleteSession(sessionKey);
    const profile = await getOrCreateProfile(serverId, userId);
    lines.push('Перебросы закончились — ничья. Ставка возвращена.');
    lines.push(`Баланс: **${profile.balance}**`);

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — Ничья`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.DRAW);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:bet').setLabel('Ещё разок').setStyle(ButtonStyle.Success),
    );

    return replyOrUpdate(interaction, { embeds: [embed], components: [row] });
  }

  session.rerollsLeft -= 1;
  await setSession(sessionKey, session);

  lines.push(`Нет комбинации — переброс! Осталось перебросов: **${session.rerollsLeft}**`);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — Переброс`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.DICE);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dice:reroll').setLabel('Перебросить').setStyle(ButtonStyle.Primary),
  );

  return replyOrUpdate(interaction, { embeds: [embed], components: [row] });
}

export async function handleDiceReroll(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  return rollDice(interaction, interaction.guild.id, interaction.user.id);
}

function replyOrUpdate(interaction: ModalSubmitInteraction | ButtonInteraction, data: { embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] }) {
  if ('isButton' in interaction && interaction.isButton?.()) {
    return interaction.update(data);
  }
  return interaction.reply({ ...data, flags: MessageFlags.Ephemeral });
}
