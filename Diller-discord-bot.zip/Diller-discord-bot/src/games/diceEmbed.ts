import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';

const RULES_TEXT =
  '**Правила (3 кости, по одному броску каждому):**\n' +
  '• **Комбо:** 4-5-6, 1-2-3, трипс (три одинаковых), пара + шестёрка\n' +
  '• Комбо бьёт не-комбо. Оба выбили комбо или оба не выбили — **ничья**, ставки возвращаются.\n\n' +
  'Игра в **приватной ветке** (видят только вы, оппонент и админ).';

export function buildDiceStartEmbed() {
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — PvP`)
    .setDescription(
      RULES_TEXT +
        '\n\n**Команда:** `/dice opponent:@игрок` — укажите оппонента (ставку можно ввести в команде или в форме).',
    )
    .setColor(UI_CONFIG.COLORS.DICE);

  return { embeds: [embed], components: [] };
}

/** Модалка ставки для PvP (после /dice opponent:@user без ставки) */
export function showDicePvPStakeModal(interaction: ChatInputCommandInteraction) {
  const modal = new ModalBuilder()
    .setCustomId('dice:stakeModal')
    .setTitle('Кости PvP — ставка');

  const input = new TextInputBuilder()
    .setCustomId('stake')
    .setLabel('Ставка с каждого (септимы)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
  return interaction.showModal(modal);
}

export function showDiceBetModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId('dice:betModal')
    .setTitle('Кости — ставка');

  const input = new TextInputBuilder()
    .setCustomId('bet_amount')
    .setLabel('Сколько септимов на кон?')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(input),
  );

  return interaction.showModal(modal);
}
