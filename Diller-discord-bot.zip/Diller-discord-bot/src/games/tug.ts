import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  type TextChannel,
  type Client,
  type GuildMember,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { checkBetPerMinuteLimit } from '../services/limits';
import { redis } from '../db/redis';

const TUG_EVENT_TTL = 900; // 15 мин
const JOIN_MINUTES = 5;
const JOIN_MS = JOIN_MINUTES * 60 * 1000;

interface TugEventPlayer {
  userId: string;
  userName: string;
  betAmount: number;
  memberRoleIds: string[];
  damageDealt?: number;
}

export const TUG_STAKES = [50, 100, 350, 500, 1000] as const;
export type TugStake = (typeof TUG_STAKES)[number];

export interface TugEventSession {
  serverId: string;
  channelId: string;
  messageId: string;
  phase: 'lobby' | 'ongoing';
  joinEndsAt: number;
  adminId: string;
  fixedStake: number; // ставка с каждого: 50 | 100 | 350 | 500 | 1000
  players: TugEventPlayer[];
  botHp?: number;
  botMaxHp?: number;
  damageScale?: number;
  totalDamage?: number;
  rolls: string[];
}

function tugEventKey(serverId: string, channelId: string) {
  return `tugEvent:${serverId}:${channelId}`;
}

export async function getTugEvent(serverId: string, channelId: string): Promise<TugEventSession | null> {
  const raw = await redis.get(tugEventKey(serverId, channelId));
  if (!raw) return null;
  return JSON.parse(raw) as TugEventSession;
}

export async function setTugEvent(ev: TugEventSession): Promise<void> {
  await redis.set(tugEventKey(ev.serverId, ev.channelId), JSON.stringify(ev), 'EX', TUG_EVENT_TTL);
}

async function deleteTugEvent(serverId: string, channelId: string): Promise<void> {
  await redis.del(tugEventKey(serverId, channelId));
}

// ——— Ивент: только админ запускает, 5 мин набор, масштаб HP/урона по числу игроков ———

export function buildTugEventLobbyEmbed(ev: TugEventSession, canStart: boolean) {
  const endsAt = new Date(ev.joinEndsAt);
  const timeLeft = Math.max(0, Math.ceil((ev.joinEndsAt - Date.now()) / 1000));
  const stake = ev.fixedStake ?? 100;
  const desc = [
    `**Набор участников.** Осталось **${Math.floor(timeLeft / 60)} мин** (до ${endsAt.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })})`,
    `**Ставка с каждого:** **${stake}** септимов (выбрал админ в команде). Комиссия — в настройках сервера.`,
    'Чем больше людей — тем больше HP у крысёныша и чуть меньше урон; чем меньше — меньше HP и чуть выше урон.',
    '',
    `Участников: **${ev.players.length}**`,
    ev.players.length > 0 ? ev.players.map((p, i) => `${i + 1}. <@${p.userId}>`).join('\n') : '_Пока никого_',
  ].join('\n');

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TUG} Перетягивание каната — ивент`)
    .setDescription(desc)
    .setColor(UI_CONFIG.COLORS.TUG);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('tug:eventJoin').setLabel('Войти').setStyle(ButtonStyle.Success),
  );
  if (canStart && ev.players.length >= 1) {
    row.addComponents(
      new ButtonBuilder().setCustomId('tug:eventStart').setLabel('Старт').setStyle(ButtonStyle.Primary),
    );
  }
  return { embeds: [embed], components: [row] };
}

function hpBar(hp: number, maxHp: number): string {
  const total = 10;
  const filled = Math.round((hp / maxHp) * total);
  return '█'.repeat(filled) + '░'.repeat(total - filled);
}

export function buildTugEventOngoingEmbed(ev: TugEventSession) {
  const lines = [
    `HP крысёныша: ${hpBar(ev.botHp!, ev.botMaxHp!)} **${ev.botHp}/${ev.botMaxHp}**`,
    `Суммарный урон: **${ev.totalDamage ?? 0}**`,
    `Участников: ${ev.players.length} (множитель урона: **${(ev.damageScale ?? 1).toFixed(2)}**)`,
  ];
  if (ev.rolls.length > 0) {
    lines.push('', '**Последние броски:**', ...ev.rolls.slice(-5));
  }
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TUG} Перетягивание каната — бой`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.TUG);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('tug:eventRoll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
  );
  return { embeds: [embed], components: [row] };
}

async function updateTugEventMessage(client: Client, ev: TugEventSession, payload: { embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] }) {
  try {
    const ch = await client.channels.fetch(ev.channelId) as TextChannel | null;
    if (!ch) return;
    const msg = await ch.messages.fetch(ev.messageId).catch(() => null);
    if (!msg) return;
    await msg.edit({ embeds: payload.embeds, components: payload.components });
  } catch (e) {
    console.error('[Tug] updateEventMessage', e);
  }
}

/** Вход в ивент по кнопке «Войти»: списывается фиксированная ставка с события. */
export async function handleTugEventJoin(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const serverId = interaction.guild.id;
  const channelId = interaction.channelId!;
  const userId = interaction.user.id;
  const ev = await getTugEvent(serverId, channelId);
  if (!ev || ev.phase !== 'lobby') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Набор уже завершён или ивент не идёт.`, flags: MessageFlags.Ephemeral });
  }
  if (Date.now() >= ev.joinEndsAt) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Время на вход вышло.`, flags: MessageFlags.Ephemeral });
  }
  if (ev.players.some((p) => p.userId === userId)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Вы уже в списке.`, flags: MessageFlags.Ephemeral });
  }

  const betAmount = ev.fixedStake ?? 100;
  const config = await ensureServerConfig(serverId);
  const profile = await getOrCreateProfile(serverId, userId);
  if (betAmount < config.minBet || betAmount > config.maxBet) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ставка ивента ${betAmount} вне лимитов сервера (${config.minBet}–${config.maxBet}).`, flags: MessageFlags.Ephemeral });
  }
  if (profile.balance < BigInt(betAmount)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Нужно **${betAmount}** септимов, баланс: ${profile.balance}.`, flags: MessageFlags.Ephemeral });
  }
  const limitCheck = await checkBetPerMinuteLimit(serverId, userId);
  if (!limitCheck.ok) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} ${limitCheck.reason}`, flags: MessageFlags.Ephemeral });
  }

  await adjustBalance({ serverId, userId, delta: -betAmount, reason: 'tug_event_bet' });
  const member = interaction.member as GuildMember | null;
  const memberRoleIds: string[] = member?.roles?.cache ? Array.from(member.roles.cache.keys()) : [];
  ev.players.push({
    userId,
    userName: interaction.user.displayName || interaction.user.username,
    betAmount,
    memberRoleIds,
  });
  await setTugEvent(ev);

  const isAdmin = interaction.guild.ownerId === userId || (member?.permissions?.has(PermissionFlagsBits.Administrator) ?? false);
  await updateTugEventMessage(interaction.client, ev, buildTugEventLobbyEmbed(ev, isAdmin));
  return interaction.reply({ content: `${UI_CONFIG.EMOJI.TUG} Вы вошли в ивент. Списанная ставка: **${betAmount}** септимов.`, flags: MessageFlags.Ephemeral });
}

// Масштаб: больше людей → больше HP, чуть меньше урон; меньше людей → меньше HP, чуть выше урон
function scaleTugEvent(n: number): { maxHp: number; damageScale: number } {
  const baseHp = 100;
  const perPlayerHp = 40;
  const maxHp = baseHp + n * perPlayerHp;
  // damageScale: 2 игрока = 1.2, 10+ = 0.65
  const damageScale = Math.max(0.65, Math.min(1.2, 1.4 - n * 0.06));
  return { maxHp, damageScale };
}

export async function handleTugEventStart(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const serverId = interaction.guild.id;
  const channelId = interaction.channelId!;
  const userId = interaction.user.id;
  const ev = await getTugEvent(serverId, channelId);
  if (!ev || ev.phase !== 'lobby') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ивент не в наборе.`, flags: MessageFlags.Ephemeral });
  }
  const member = interaction.member as GuildMember | null;
  const isAdmin = interaction.guild.ownerId === userId || (member?.permissions?.has(PermissionFlagsBits.Administrator) ?? false);
  if (!isAdmin) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Запустить может только админ.`, flags: MessageFlags.Ephemeral });
  }
  if (Date.now() < ev.joinEndsAt && ev.players.length < 2) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Дождитесь окончания набора (5 мин) или наберите минимум 2 участников.`, flags: MessageFlags.Ephemeral });
  }
  if (ev.players.length === 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нужен хотя бы один участник.`, flags: MessageFlags.Ephemeral });
  }

  const { maxHp, damageScale } = scaleTugEvent(ev.players.length);
  ev.phase = 'ongoing';
  ev.botHp = maxHp;
  ev.botMaxHp = maxHp;
  ev.damageScale = damageScale;
  ev.totalDamage = 0;
  ev.rolls = [];
  for (const p of ev.players) {
    p.damageDealt = 0;
  }
  await setTugEvent(ev);

  await updateTugEventMessage(interaction.client, ev, buildTugEventOngoingEmbed(ev));
  return interaction.reply({ content: `${UI_CONFIG.EMOJI.TUG} Ивент начался! HP: **${maxHp}**, участников: **${ev.players.length}**. Кидайте по очереди.`, flags: MessageFlags.Ephemeral });
}

function rollDamage(scale: number): { d1: number; d2: number; sum: number; isDouble: boolean; multiplier: number; damage: number; label: string } {
  const d1 = crypto.randomInt(1, 7);
  const d2 = crypto.randomInt(1, 7);
  const sum = d1 + d2;
  const isDouble = d1 === d2;
  let mult: number;
  let label: string;
  if (isDouble) {
    mult = 2;
    label = 'Дубль! x2';
  } else if (sum === 7) {
    mult = 1;
    label = 'x1';
  } else if (sum >= 2 && sum <= 6) {
    mult = 0.5;
    label = 'x0.5';
  } else {
    mult = 1.5;
    label = 'x1.5';
  }
  const baseDamage = sum;
  const damage = Math.floor(baseDamage * mult * scale);
  return { d1, d2, sum, isDouble, multiplier: mult, damage, label };
}

export async function handleTugEventRoll(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const serverId = interaction.guild.id;
  const channelId = interaction.channelId!;
  const userId = interaction.user.id;
  const ev = await getTugEvent(serverId, channelId);
  if (!ev || ev.phase !== 'ongoing' || ev.botHp == null || ev.botMaxHp == null || ev.damageScale == null) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас нельзя кидать.`, flags: MessageFlags.Ephemeral });
  }
  if (!ev.players.some((p) => p.userId === userId)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Вы не участник этого ивента.`, flags: MessageFlags.Ephemeral });
  }

  const { d1, d2, sum, damage, label } = rollDamage(ev.damageScale);
  ev.botHp = Math.max(0, ev.botHp - damage);
  ev.totalDamage = (ev.totalDamage ?? 0) + damage;
  const player = ev.players.find((p) => p.userId === userId);
  if (player) {
    player.damageDealt = (player.damageDealt ?? 0) + damage;
  }
  ev.rolls.push(`<@${userId}>: ${d1}+${d2}=${sum} (${label}) → **${damage}** урона`);
  await setTugEvent(ev);

  if (ev.botHp <= 0) {
    await finishTugEvent(interaction.client, ev);
    await updateTugEventMessage(interaction.client, ev, buildTugEventResultPayload(ev));
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.WIN} Крысёныш повержен! Урон: **${damage}**. Выплаты начислены.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await updateTugEventMessage(interaction.client, ev, buildTugEventOngoingEmbed(ev));
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.TUG} ${d1}+${d2}=${sum} (${label}) → **${damage}** урона. HP: ${ev.botHp}/${ev.botMaxHp}`,
    flags: MessageFlags.Ephemeral,
  });
}

function buildTugEventResultPayload(ev: TugEventSession): { embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] } {
  const pot = ev.players.reduce((s, p) => s + p.betAmount, 0);
  const totalD = ev.totalDamage ?? 1;
  const sorted = [...ev.players].sort((a, b) => (b.damageDealt ?? 0) - (a.damageDealt ?? 0));
  const lines = [
    '**Крысёныш повержен!**',
    `Суммарный урон: **${ev.totalDamage ?? 0}**`,
    `Общий банк: **${pot}** септимов. Награды — по доле урона:`,
    '',
    ...sorted.map((p) => {
      const d = p.damageDealt ?? 0;
      const share = totalD > 0 ? (d / totalD * 100).toFixed(1) : '0';
      return `• <@${p.userId}> — **${d}** урона (${share}%)`;
    }),
  ];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TUG} Перетягивание каната — результат`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.TUG);
  return { embeds: [embed], components: [] };
}

async function finishTugEvent(client: Client, ev: TugEventSession) {
  const config = await getServerConfig(ev.serverId);
  const pot = ev.players.reduce((s, p) => s + p.betAmount, 0);
  const totalPrize = pot * 2; // при победе общий призовой фонд x2
  const totalD = ev.totalDamage ?? 1;
  for (const p of ev.players) {
    const d = p.damageDealt ?? 0;
    const shareOfPrize = totalD > 0 ? (d / totalD) * totalPrize : totalPrize / ev.players.length;
    const vipMul = await getVipMultiplier(ev.serverId, p.memberRoleIds);
    const payout = Math.floor(calculatePayout(shareOfPrize, vipMul, config?.casinoCommission));
    const { creditAdminCommissionFromPayout } = await import('../services/economy');
    await creditAdminCommissionFromPayout(ev.serverId, shareOfPrize, config?.casinoCommission);
    if (payout > 0) {
      await adjustBalance({ serverId: ev.serverId, userId: p.userId, delta: payout, reason: 'tug_event_win' });
    }
    await logBet({
      serverId: ev.serverId, userId: p.userId, gameType: 'tug_event',
      betAmount: p.betAmount, payoutAmount: payout, outcome: payout > 0 ? 'win' : 'lose', seed: '',
    });
  }
  await deleteTugEvent(ev.serverId, ev.channelId);
}

// ——— Старый одиночный режим убран: перетягивание только ивент (запуск — админ). ———

export function buildTugStartEmbed() {
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TUG} Перетягивание каната`)
    .setDescription(
      'Перетягивание каната — **ивент**. Запустить его может только **админ**.\n' +
        'Ждите объявления о наборе (5 минут на вход). Чем больше участников — тем больше HP у крысёныша и чуть меньше урон; чем меньше — меньше HP и чуть выше урон.',
    )
    .setColor(UI_CONFIG.COLORS.TUG);
  return { embeds: [embed], components: [] };
}

export async function handleTugButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const { customId } = interaction;

  if (customId === 'tug:eventJoin') {
    return handleTugEventJoin(interaction);
  }
  if (customId === 'tug:eventStart') {
    return handleTugEventStart(interaction);
  }
  if (customId === 'tug:eventRoll') {
    return handleTugEventRoll(interaction);
  }
}
