/**
 * Стандартные покерные комбинации (5 карт).
 * Ранги: 2..14 (J=11, Q=12, K=13, A=14).
 */

export type Card = { suit: number; rank: number };

export type PokerHand =
  | { type: 'royal_flush'; rank: 1 }
  | { type: 'straight_flush'; high: number; rank: 2 }
  | { type: 'four_of_a_kind'; quad: number; kicker: number; rank: 3 }
  | { type: 'full_house'; triple: number; pair: number; rank: 4 }
  | { type: 'flush'; cards: number[]; rank: 5 }
  | { type: 'straight'; high: number; rank: 6 }
  | { type: 'three_of_a_kind'; triple: number; kickers: number[]; rank: 7 }
  | { type: 'two_pair'; highPair: number; lowPair: number; kicker: number; rank: 8 }
  | { type: 'one_pair'; pair: number; kickers: number[]; rank: 9 }
  | { type: 'high_card'; cards: number[]; rank: 10 };

const HAND_NAMES: Record<string, string> = {
  royal_flush: 'Роял-флеш',
  straight_flush: 'Стрит-флеш',
  four_of_a_kind: 'Каре',
  full_house: 'Фулл-хаус',
  flush: 'Флеш',
  straight: 'Стрит',
  three_of_a_kind: 'Тройка',
  two_pair: 'Две пары',
  one_pair: 'Пара',
  high_card: 'Старшая карта',
};

export function getHandName(hand: PokerHand): string {
  return HAND_NAMES[hand.type] ?? hand.type;
}

/** Оценить лучшую 5-карточную комбинацию из набора карт. */
export function evaluatePokerHand(cards: Card[]): PokerHand {
  if (cards.length < 5) {
    const sorted = [...cards].sort((a, b) => b.rank - a.rank);
    return { type: 'high_card', cards: sorted.map((c) => c.rank), rank: 10 };
  }

  const byRank = new Map<number, Card[]>();
  const bySuit = new Map<number, Card[]>();
  for (const c of cards) {
    byRank.set(c.rank, [...(byRank.get(c.rank) ?? []), c]);
    bySuit.set(c.suit, [...(bySuit.get(c.suit) ?? []), c]);
  }

  const ranks = [...new Set(cards.map((c) => c.rank))].sort((a, b) => b - a);
  const counts = new Map<number, number>();
  for (const r of ranks) {
    counts.set(r, (byRank.get(r)?.length ?? 0));
  }

  // Flush check
  let flushSuit: number | null = null;
  for (const [suit, list] of bySuit) {
    if (list.length >= 5) {
      flushSuit = suit;
      break;
    }
  }

  const flushCards = flushSuit != null ? (bySuit.get(flushSuit) ?? []).sort((a, b) => b.rank - a.rank) : [];

  // Straight check (A can be 1 or 14)
  function getStraightHigh(rr: number[]): number | null {
    const uniq = [...new Set(rr)].sort((a, b) => b - a);
    for (let i = 0; i <= uniq.length - 5; i++) {
      const slice = uniq.slice(i, i + 5);
      if (slice[0] - slice[4] === 4) return slice[0];
    }
    if (uniq.includes(14)) {
      const low = uniq.filter((r) => r !== 14).concat([1]);
      for (let i = 0; i <= low.length - 4; i++) {
        const s = [14, ...low.slice(i, i + 4)].sort((a, b) => b - a);
        if (s[0] - s[4] === 4) return s[0];
      }
    }
    return null;
  }

  const allRanks = cards.map((c) => c.rank);
  const straightHigh = getStraightHigh(allRanks);
  const flushRanks = flushCards.map((c) => c.rank);
  const straightFlushHigh = flushSuit != null ? getStraightHigh(flushRanks) : null;

  if (flushSuit != null && straightFlushHigh === 14 && flushRanks.includes(13) && flushRanks.includes(12)) {
    return { type: 'royal_flush', rank: 1 };
  }
  if (flushSuit != null && straightFlushHigh != null) {
    return { type: 'straight_flush', high: straightFlushHigh, rank: 2 };
  }

  const quad = [...counts.entries()].find(([, n]) => n >= 4);
  if (quad) {
    const kicker = ranks.find((r) => r !== quad[0]) ?? 0;
    return { type: 'four_of_a_kind', quad: quad[0], kicker, rank: 3 };
  }

  const triple = [...counts.entries()].find(([, n]) => n >= 3);
  const pair = [...counts.entries()].find(([r, n]) => n >= 2 && r !== triple?.[0]);
  if (triple && pair) {
    return { type: 'full_house', triple: triple[0], pair: pair[0], rank: 4 };
  }

  if (flushSuit != null && flushCards.length >= 5) {
    return { type: 'flush', cards: flushCards.slice(0, 5).map((c) => c.rank), rank: 5 };
  }

  if (straightHigh != null) {
    return { type: 'straight', high: straightHigh, rank: 6 };
  }

  if (triple) {
    const kickers = ranks.filter((r) => r !== triple[0]).slice(0, 2);
    return { type: 'three_of_a_kind', triple: triple[0], kickers, rank: 7 };
  }

  const pairs = [...counts.entries()].filter(([, n]) => n >= 2).sort((a, b) => b[0] - a[0]);
  if (pairs.length >= 2) {
    const kicker = ranks.find((r) => r !== pairs[0][0] && r !== pairs[1][0]) ?? 0;
    return { type: 'two_pair', highPair: pairs[0][0], lowPair: pairs[1][0], kicker, rank: 8 };
  }

  if (pairs.length === 1) {
    const kickers = ranks.filter((r) => r !== pairs[0][0]).slice(0, 3);
    return { type: 'one_pair', pair: pairs[0][0], kickers, rank: 9 };
  }

  return { type: 'high_card', cards: ranks.slice(0, 5), rank: 10 };
}

/** Все комбинации C(n,k). */
function combinations<T>(arr: T[], k: number): T[][] {
  if (k === 0) return [[]];
  if (arr.length < k) return [];
  const result: T[][] = [];
  for (let i = 0; i <= arr.length - k; i++) {
    const rest = combinations(arr.slice(i + 1), k - 1);
    for (const r of rest) result.push([arr[i], ...r]);
  }
  return result;
}

/** Лучшая 5-карточная рука из 7 карт (Техасский холдем). */
export function evaluateBestHand(cards: Card[]): PokerHand {
  if (cards.length < 5) {
    const sorted = [...cards].sort((a, b) => b.rank - a.rank);
    return { type: 'high_card', cards: sorted.map((c) => c.rank), rank: 10 };
  }
  if (cards.length === 5) return evaluatePokerHand(cards);
  const fives = combinations(cards, 5);
  let best = evaluatePokerHand(fives[0]);
  for (let i = 1; i < fives.length; i++) {
    const h = evaluatePokerHand(fives[i]);
    if (compareHands(h, best) > 0) best = h;
  }
  return best;
}

/** Сравнить две руки. Возврат: 1 если a выигрывает, -1 если b, 0 если равны. */
export function compareHands(a: PokerHand, b: PokerHand): number {
  if (a.rank !== b.rank) return b.rank - a.rank; // меньше rank = сильнее
  switch (a.type) {
    case 'straight_flush':
      return (a.high ?? 0) - ((b as PokerHand & { high: number }).high ?? 0);
    case 'four_of_a_kind':
      const aq = a.quad - ((b as PokerHand & { quad: number }).quad ?? 0);
      if (aq !== 0) return aq;
      return (a.kicker ?? 0) - ((b as PokerHand & { kicker: number }).kicker ?? 0);
    case 'full_house':
      const at = a.triple - ((b as PokerHand & { triple: number }).triple ?? 0);
      if (at !== 0) return at;
      return (a.pair ?? 0) - ((b as PokerHand & { pair: number }).pair ?? 0);
    case 'flush':
    case 'high_card':
      const ac = a.cards ?? [];
      const bc = (b as PokerHand & { cards: number[] }).cards ?? [];
      for (let i = 0; i < Math.max(ac.length, bc.length); i++) {
        const d = (ac[i] ?? 0) - (bc[i] ?? 0);
        if (d !== 0) return d;
      }
      return 0;
    case 'straight':
      return (a.high ?? 0) - ((b as PokerHand & { high: number }).high ?? 0);
    case 'three_of_a_kind':
      const at3 = a.triple - ((b as PokerHand & { triple: number }).triple ?? 0);
      if (at3 !== 0) return at3;
      const ak = a.kickers ?? [];
      const bk = (b as PokerHand & { kickers: number[] }).kickers ?? [];
      for (let i = 0; i < Math.max(ak.length, bk.length); i++) {
        const d = (ak[i] ?? 0) - (bk[i] ?? 0);
        if (d !== 0) return d;
      }
      return 0;
    case 'two_pair':
      const ahp = (a.highPair ?? 0) - ((b as PokerHand & { highPair: number }).highPair ?? 0);
      if (ahp !== 0) return ahp;
      const alp = (a.lowPair ?? 0) - ((b as PokerHand & { lowPair: number }).lowPair ?? 0);
      if (alp !== 0) return alp;
      return (a.kicker ?? 0) - ((b as PokerHand & { kicker: number }).kicker ?? 0);
    case 'one_pair':
      const ap = (a.pair ?? 0) - ((b as PokerHand & { pair: number }).pair ?? 0);
      if (ap !== 0) return ap;
      const ak2 = a.kickers ?? [];
      const bk2 = (b as PokerHand & { kickers: number[] }).kickers ?? [];
      for (let i = 0; i < Math.max(ak2.length, bk2.length); i++) {
        const d = (ak2[i] ?? 0) - (bk2[i] ?? 0);
        if (d !== 0) return d;
      }
      return 0;
    default:
      return 0;
  }
}
