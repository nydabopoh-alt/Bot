import path from 'node:path';
import { REST, Routes } from 'discord.js';
import { config } from 'dotenv';
config();
config({ path: path.resolve(process.cwd(), 'src/.env') });
import { getSlashCommandData } from '../commands/definitions';

const BOT_TOKEN = process.env.BOT_TOKEN;
const APPLICATION_ID = process.env.APPLICATION_ID;
const GUILD_ID = process.env.GUILD_ID;

if (!BOT_TOKEN) {
  throw new Error('BOT_TOKEN is required in .env');
}

if (!APPLICATION_ID) {
  throw new Error('APPLICATION_ID is required in .env');
}

async function main() {
  const rest = new REST({ version: '10' }).setToken(BOT_TOKEN!);
  const commands = getSlashCommandData();

  console.log(`Registering ${commands.length} slash commands...`);

  if (GUILD_ID) {
    await rest.put(
      Routes.applicationGuildCommands(APPLICATION_ID!, GUILD_ID),
      { body: commands },
    );
    console.log(`✅ ${commands.length} guild commands deployed to ${GUILD_ID}.`);
  } else {
    await rest.put(
      Routes.applicationCommands(APPLICATION_ID!),
      { body: commands },
    );
    console.log(`✅ ${commands.length} global commands deployed.`);
  }
}

main().catch((err) => {
  console.error('Failed to deploy commands:', err);
  process.exit(1);
});
