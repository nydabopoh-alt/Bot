import path from 'node:path';
import { config } from 'dotenv';

// Подгрузка .env из корня и из src/ (при запуске из корня проекта)
config();
config({ path: path.resolve(process.cwd(), 'src/.env') });

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

export const ENV = {
  BOT_TOKEN: requireEnv('BOT_TOKEN'),
  REDIS_URL: requireEnv('REDIS_URL'),
  DEFAULT_RTP: parseFloat(requireEnv('DEFAULT_RTP')),
  GLOBAL_COMMISSION: parseFloat(requireEnv('GLOBAL_COMMISSION')),
};

