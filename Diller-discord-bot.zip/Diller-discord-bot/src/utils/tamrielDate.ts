/**
 * Формат даты/времени в стиле TES (Тамриэль).
 * Только для отображения в публичных сообщениях и каналах; админ-панель — григорианский.
 */

const TAMRIEL_DAYS: Record<number, string> = {
  0: 'Сандас',   // Sunday
  1: 'Морндас',  // Monday
  2: 'Тирдас',   // Tuesday
  3: 'Миддас',   // Wednesday
  4: 'Турдас',   // Thursday
  5: 'Фредас',   // Friday
  6: 'Лордас',   // Saturday
};

const TAMRIEL_DAYS_FULL: Record<number, string> = {
  0: 'Сандас (Воскресенье)',
  1: 'Морндас (Понедельник)',
  2: 'Тирдас (Вторник)',
  3: 'Миддас (Среда)',
  4: 'Турдас (Четверг)',
  5: 'Фредас (Пятница)',
  6: 'Лордас (Суббота)',
};

const TAMRIEL_MONTHS: Record<number, string> = {
  0: 'Утренней звезды',    // January - Morning Star
  1: 'Восхода солнца',     // February - Sun's Dawn
  2: 'Первого зерна',      // March - First Seed
  3: 'Руки дождя',         // April - Rain's Hand
  4: 'Второго зерна',      // May - Second Seed
  5: 'Середины года',      // June - Mid Year
  6: 'Высокого солнца',    // July - Sun's Height
  7: 'Последнего зерна',   // August - Last Seed
  8: 'Огня очага',         // September - Hearthfire
  9: 'Начала морозов',     // October - Frostfall
  10: 'Заката солнца',     // November - Sun's Dusk
  11: 'Вечерней звезды',   // December - Evening Star
};

export type TimeOfDayRange = { start: number; end: number; label: string };

/** Утро 06–11, день 12–17, вечер 18–23, ночь 00–05. Можно вынести в настройки. */
export const DEFAULT_TIME_OF_DAY: TimeOfDayRange[] = [
  { start: 0, end: 5, label: 'ночь' },
  { start: 6, end: 11, label: 'утро' },
  { start: 12, end: 17, label: 'день' },
  { start: 18, end: 23, label: 'вечер' },
];

function getTimeOfDay(hours: number, ranges: TimeOfDayRange[] = DEFAULT_TIME_OF_DAY): string {
  for (const r of ranges) {
    if (hours >= r.start && hours <= r.end) return r.label;
  }
  return 'день';
}

/**
 * Форматирует дату в тамриэльском стиле для публичных сообщений.
 * @param date — дата (учитывается локальное время или переданная таймзона)
 * @param options.short — короткий вариант (без скобок с григорианским днём)
 * @param options.timeOfDayRanges — диапазоны времени суток (утро/день/вечер/ночь)
 */
export function formatTamrielDate(
  date: Date,
  options?: { short?: boolean; timeOfDayRanges?: TimeOfDayRange[] },
): string {
  const short = options?.short !== false;
  const ranges = options?.timeOfDayRanges ?? DEFAULT_TIME_OF_DAY;
  const dayOfWeek = date.getDay();
  const day = date.getDate();
  const month = date.getMonth();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const tamrielDay = short ? TAMRIEL_DAYS[dayOfWeek] : TAMRIEL_DAYS_FULL[dayOfWeek];
  const timeOfDay = getTimeOfDay(hours, ranges);
  const monthName = TAMRIEL_MONTHS[month];
  const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  return `${tamrielDay}, ${day} ${timeOfDay} ${monthName} в ${timeStr}`;
}
