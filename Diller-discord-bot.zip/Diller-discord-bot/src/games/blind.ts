import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { setSession, getSession, deleteSession } from '../services/sessions';

// Номинал: 2..14 (J=11, Q=12, K=13, A=14)
const CARD_NAMES: Record<number, string> = {
  2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9', 10: '10',
  11: 'J', 12: 'Q', 13: 'K', 14: 'A',
};

// Масти: черви, буби, пики, крести (Unicode: hearts, diamonds, spades, clubs)
const SUIT_BASES: Record<number, number> = {
  0: 0x1f0b0, // черви
  1: 0x1f0c0, // буби
  2: 0x1f0a0, // пики
  3: 0x1f0d0, // крести
};

function cardToSymbol(suit: number, rank: number): string {
  if (rank < 2 || rank > 14) return '🂠';
  const base = SUIT_BASES[suit] ?? 0x1f0a0;
  const index = rank === 14 ? 1 : rank;
  return String.fromCodePoint(base + index);
}

function rankToName(rank: number): string {
  return CARD_NAMES[rank] ?? String(rank);
}

// Символы мастей: черви ♥, буби ♦, пики ♠, крести ♣
const SUIT_SYMBOLS = ['♥', '♦', '♠', '♣'];

// Названия мастей по-русски
const SUIT_NAMES_RU = ['черви', 'буби', 'пики', 'крести'];

const RANK_NAMES_RU: Record<number, string> = {
  2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9', 10: '10',
  11: 'валет', 12: 'дама', 13: 'король', 14: 'туз',
};

/** Карта в виде `[A]♦` — номинал в скобках и масть (для эмбедов) */
function cardToShort(suit: number, rank: number): string {
  const r = rankToName(rank);
  const s = SUIT_SYMBOLS[suit] ?? '?';
  return `\`[${r}]\`${s}`;
}

/** Карта по-русски: «9 пик», «туз червей» — для ЛС игроку */
function cardToHuman(suit: number, rank: number): string {
  const rankStr = RANK_NAMES_RU[rank] ?? String(rank);
  const suitStr = SUIT_NAMES_RU[suit] ?? '?';
  return `${rankStr} ${suitStr}`;
}

/** Колода 52 карты, тасованная (без повторений) */
function createShuffledDeck(): Array<{ suit: number; rank: number }> {
  const deck: Array<{ suit: number; rank: number }> = [];
  for (let suit = 0; suit < 4; suit++) {
    for (let rank = 2; rank <= 14; rank++) {
      deck.push({ suit, rank });
    }
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

/** Сравнение карт: сначала номинал, при равенстве — масть (черви > буби > пики > крести) */
function cardGreater(a: { suit: number; rank: number }, b: { suit: number; rank: number }): boolean {
  if (a.rank !== b.rank) return a.rank > b.rank;
  return a.suit < b.suit; // 0 (черви) старше 1,2,3
}

/** Нормализация карты из сессии (поддержка старого формата: card = число) */
function normalizeCard(c: unknown): { suit: number; rank: number } | null {
  if (c && typeof c === 'object' && 'suit' in c && 'rank' in c) {
    return { suit: (c as { suit: number }).suit, rank: (c as { rank: number }).rank };
  }
  if (typeof c === 'number' && c >= 2 && c <= 14) return { suit: 0, rank: c };
  return null;
}

/** Форматировать карты для отображения в эмбедах */
function formatCards(cards: Array<{ suit: number; rank: number }>): string {
  return cards.map((c) => cardToShort(c.suit, c.rank)).join(' ');
}

/** Форматировать карты по-русски для ЛС игроку */
function formatCardsHuman(cards: Array<{ suit: number; rank: number }>): string {
  return cards.map((c) => cardToHuman(c.suit, c.rank)).join(', ');
}

import { evaluateBestHand, compareHands, getHandName, type Card } from './pokerHands';

interface BlindPlayer {
  id: string;
  /** 2 карты (холдем). Для совместимости: card — старая 1 карта. */
  cards?: Array<{ suit: number; rank: number }>;
  card?: { suit: number; rank: number };
  bet: number;
  folded: boolean;
  /** Фишки на столе (ставки идут из них, не из кошелька) */
  stack?: number;
}

type Street = 'preflop' | 'flop' | 'turn' | 'river' | 'showdown';

interface BlindSession {
  hostId: string;
  players: BlindPlayer[];
  pot: number;
  seed: string;
  phase: 'lobby' | 'betting' | 'reveal';
  street: Street;
  /** 5 общих карт на столе (вскрываются: 3 → +1 → +1) */
  communityCards: Array<{ suit: number; rank: number }>;
  currentTurnIndex: number;
  currentBet: number;
  minBet: number;
  /** Взнос в банк стола (игрок вносит при старте, ставки идут из него) */
  buyIn?: number;
  respondersNeeded: number;
}

function sessionKey(serverId: string, channelId: string, hostId: string) {
  return `blind:${serverId}:${channelId}:${hostId}`;
}

function getNextActivePlayerIndex(session: BlindSession, fromIndex: number): number {
  const len = session.players.length;
  let i = (fromIndex + 1) % len;
  let checked = 0;
  while (checked < len) {
    if (!session.players[i].folded) return i;
    i = (i + 1) % len;
    checked++;
  }
  return -1;
}

function countActivePlayers(session: BlindSession): number {
  return session.players.filter(p => !p.folded).length;
}

const POKER_RULES =
  '**Техасский холдем:**\n' +
  'Каждому по **2 карты** в ЛС. На стол выкладывают **5 общих**: сначала 3, потом ещё 1, потом последняя.\n' +
  'Игроки по очереди: **Проверить** / **Уравнять** / **Поставить** / **Сбросить**.\n' +
  'Лучшая комбинация из 7 карт (2 своих + 5 общих) забирает банк.';

const POKER_COMBINATIONS =
  '**Комбинации** (от старшей к младшей):\n' +
  '1. Роял-флеш (10–J–Q–K–A одной масти)\n' +
  '2. Стрит-флеш (5 карт подряд одной масти)\n' +
  '3. Каре (4 карты одного номинала)\n' +
  '4. Фулл-хаус (тройка + пара)\n' +
  '5. Флеш (5 карт одной масти)\n' +
  '6. Стрит (5 карт подряд)\n' +
  '7. Тройка (3 карты одного номинала)\n' +
  '8. Две пары\n' +
  '9. Пара (2 карты одного номинала)\n' +
  '10. Старшая карта';

const POKER_COMBINATIONS_IMAGE =
  'https://cdn.discordapp.com/attachments/1471462038998880430/1478469919602507798/ugc_851605207737570447_1EDA40DF27D6D6506A96D05EF1B3232C8DAAFD96_.png?ex=69a883e9&is=69a73269&hm=d334adc121bccc98a29d6218b02ec4470d72afd169989b050d2ee8379cd5736d&';

export function buildBlindStartEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🃏 Покер — Техасский холдем')
    .setDescription(
      '*Стандартный покер по правилам мира. Карты в ЛС, торги в канале.*\n\n' +
        POKER_RULES +
        '\n\n' +
        POKER_COMBINATIONS +
        '\n\n**Войти** в стол, затем организатор жмёт **Старт**.',
    )
    .setImage(POKER_COMBINATIONS_IMAGE)
    .setColor(UI_CONFIG.COLORS.BLIND);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('blind:join').setLabel('Войти в стол').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('blind:start').setLabel('Старт').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row] };
}

export async function handleBlindButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const serverId = interaction.guild.id;
  const channelId = interaction.channelId;
  const userId = interaction.user.id;
  const { customId } = interaction;

  if (customId === 'blind:join') {
    return handleBlindJoin(interaction, serverId, channelId, userId);
  }
  if (customId === 'blind:start') {
    return handleBlindStartGame(interaction, serverId, channelId, userId);
  }
  if (customId === 'blind:check') {
    return handleBlindAction(interaction, serverId, channelId, userId, 'check');
  }
  if (customId === 'blind:call') {
    return handleBlindAction(interaction, serverId, channelId, userId, 'call');
  }
  if (customId === 'blind:raise') {
    return handleBlindRaiseModal(interaction);
  }
  if (customId === 'blind:fold') {
    return handleBlindAction(interaction, serverId, channelId, userId, 'fold');
  }
}

async function findOrCreateSession(serverId: string, channelId: string, hostId: string): Promise<BlindSession> {
  const key = sessionKey(serverId, channelId, hostId);
  const existing = await getSession<BlindSession>(key);
  if (existing) return existing;

  const config = await ensureServerConfig(serverId);
  const session: BlindSession = {
    hostId,
    players: [],
    pot: 0,
    seed: crypto.randomUUID(),
    phase: 'lobby',
    street: 'preflop',
    communityCards: [],
    currentTurnIndex: 0,
    currentBet: config.minBet,
    minBet: config.minBet,
    buyIn: config.minBet,
    respondersNeeded: 0,
  };
  await setSession(key, session);
  return session;
}

// Для поиска сессии в канале по любому hostId
async function findSessionInChannel(serverId: string, channelId: string): Promise<{ session: BlindSession; key: string } | null> {
  const { redis } = await import('../db/redis');
  const pattern = `session:blind:${serverId}:${channelId}:*`;
  let cursor = '0';
  do {
    const [nextCursor, keys] = await redis.scan(cursor, 'MATCH', pattern, 'COUNT', 100);
    cursor = nextCursor;
    for (const fullKey of keys) {
      const raw = await redis.get(fullKey);
      if (raw) {
        const session = JSON.parse(raw) as BlindSession;
        const key = fullKey.replace('session:', '');
        return { session, key };
      }
    }
  } while (cursor !== '0');
  return null;
}

async function handleBlindJoin(
  interaction: ButtonInteraction, serverId: string, channelId: string, userId: string,
) {
  let found = await findSessionInChannel(serverId, channelId);
  if (!found) {
    const session = await findOrCreateSession(serverId, channelId, userId);
    found = { session, key: sessionKey(serverId, channelId, userId) };
  }

  const { session, key } = found;

  if (session.phase !== 'lobby') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Игра уже идёт, дождитесь следующего раунда.`, flags: MessageFlags.Ephemeral });
  }

  if (session.players.some(p => p.id === userId)) {
    const isHost = session.hostId === userId;
    const msg = isHost
      ? `${UI_CONFIG.EMOJI.INFO} **Вы уже в лобби.** Нажмите **Старт**, когда будет 2+ игроков.`
      : `${UI_CONFIG.EMOJI.INFO} **Вы уже в лобби.** Ждём Старт от организатора (<@${session.hostId}>).`;
    return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
  }

  session.players.push({ id: userId, cards: [], bet: 0, folded: false });
  await setSession(key, session);

  const names = session.players.map(p => `<@${p.id}>`).join(', ');

  const embed = new EmbedBuilder()
    .setTitle('🃏 Покер — Лобби')
    .setDescription(
      `Игроки (${session.players.length}): ${names}\n` +
        `Организатор: <@${session.hostId}>\n\n` +
        'Ждём за столом. Организатор жмёт **Старт** — раздаём карты.',
    )
    .setColor(UI_CONFIG.COLORS.BLIND);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('blind:join').setLabel('Войти в стол').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('blind:start').setLabel('Старт').setStyle(ButtonStyle.Primary),
  );

  await interaction.update({ embeds: [embed], components: [row] });
  return interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} **Вы в лобби.** Минимум 2 игрока — затем организатор жмёт **Старт**.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

async function handleBlindStartGame(
  interaction: ButtonInteraction, serverId: string, channelId: string, userId: string,
) {
  // Сразу подтверждаем, чтобы избежать 40060 при двойном клике и таймаута 3 сек
  if (!interaction.replied && !interaction.deferred) {
    await interaction.deferUpdate().catch((e) => console.error('[blind] deferUpdate failed:', e));
  }

  const respond = async (opts: { content: string; embeds?: import('discord.js').APIEmbed[]; components?: import('discord.js').ActionRowBuilder<import('discord.js').ButtonBuilder>[] }) => {
    try {
      if (interaction.deferred) {
        await interaction.editReply(opts);
      } else {
        await interaction.reply({ content: opts.content, flags: MessageFlags.Ephemeral });
      }
    } catch (e) {
      console.error('[blind] respond error:', e);
    }
  };

  const found = await findSessionInChannel(serverId, channelId);
  if (!found) return respond({ content: `${UI_CONFIG.EMOJI.ERROR} Нет активного лобби.`, embeds: [], components: [] });

  const { session, key } = found;

  if (session.hostId !== userId) {
    return respond({
      content: `${UI_CONFIG.EMOJI.ERROR} Только организатор (<@${session.hostId}>) может запустить игру.`,
      embeds: [],
      components: [],
    });
  }

  if (session.phase !== 'lobby') return respond({ content: `${UI_CONFIG.EMOJI.ERROR} Игра уже идёт.`, embeds: [], components: [] });
  if (session.players.length < 2) return respond({ content: `${UI_CONFIG.EMOJI.ERROR} Нужно минимум 2 игрока.`, embeds: [], components: [] });

  const buyIn = session.buyIn ?? session.minBet;
  const config = await getServerConfig(serverId);
  const canAfford = await Promise.all(
    session.players.map((p) => getOrCreateProfile(serverId, p.id).then((pr) => pr.balance >= BigInt(buyIn))),
  );
  const ableCount = canAfford.filter(Boolean).length;
  if (ableCount < 2) {
    return respond({
      content: `${UI_CONFIG.EMOJI.ERROR} Минимум 2 игрока должны иметь на балансе **${buyIn}** септимов. Сейчас только **${ableCount}** могут внести взнос.`,
      embeds: [],
      components: [],
    });
  }
  const ante = Math.min(config?.minBet ?? 10, Math.max(1, Math.floor(buyIn / 50)));

  const deck = createShuffledDeck();
  let deckIdx = 0;
  const client = interaction.client;

  for (let i = 0; i < session.players.length; i++) {
    const player = session.players[i];
    player.cards = deck.slice(deckIdx, deckIdx + 2);
    deckIdx += 2;
    player.folded = false;

    const profile = await getOrCreateProfile(serverId, player.id);
    if (profile.balance < BigInt(buyIn)) {
      player.folded = true;
      player.bet = 0;
      player.stack = 0;
    } else {
      await adjustBalance({ serverId, userId: player.id, delta: -buyIn, reason: 'blind_buyin' });
      player.stack = buyIn;
      player.stack -= ante;
      player.bet = ante;
      session.pot += ante;
    }

    // Отправить 2 карты в ЛС + правила
    try {
      const user = await client.users.fetch(player.id);
      const cardsStr = formatCardsHuman(player.cards!);
      const rulesDm =
        POKER_RULES +
        '\n\n**Кнопки в ветке:** Проверить / Уравнять / Поставить / Сбросить. Ход по очереди.';
      await user.send({
        content:
          `🃏 **Ваши карты:** ${cardsStr}\n\n` +
          `Игра в ветке <#${channelId}>.\n\n` +
          `**Правила:**\n${rulesDm}`,
      });
    } catch {
      // ЛС закрыты — игрок увидит карты при вскрытии
    }
  }

  // Общие карты: сброс 1, флоп 3, сброс 1, терн 1, сброс 1, ривер 1
  deckIdx += 1;
  const flop = deck.slice(deckIdx, deckIdx + 3);
  deckIdx += 3;
  deckIdx += 1;
  const turn = deck.slice(deckIdx, deckIdx + 1);
  deckIdx += 1;
  deckIdx += 1;
  const river = deck.slice(deckIdx, deckIdx + 1);
  session.communityCards = [...flop, ...turn, ...river];

  session.phase = 'betting';
  session.street = 'preflop';
  session.currentBet = ante;
  session.minBet = Math.max(ante, config?.minBet ?? 10);

  let startIdx = 0;
  while (startIdx < session.players.length && session.players[startIdx].folded) {
    startIdx++;
  }
  session.currentTurnIndex = startIdx;
  session.respondersNeeded = countActivePlayers(session);

  await setSession(key, session);

  const thread = interaction.channel as import('discord.js').TextChannel | null;
  const ui = buildBettingPhaseUI(session);
  if (!ui) {
    return respond({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось начать — проверьте баланс игроков.`,
      embeds: [],
      components: [],
    });
  }

  await interaction.editReply({
    content: '🃏 **Игра началась!** Карты в ЛС. Игровые кнопки ниже.',
    embeds: [],
    components: [],
  }).catch(() => {});

  if (thread) {
    void thread
      .send({
        content:
          `📋 **Правила:** ${POKER_RULES}\n\n` +
          `**Комбинации:** Роял-флеш → Стрит-флеш → Каре → Фулл-хаус → Флеш → Стрит → Тройка → Две пары → Пара → Старшая карта`,
      })
      .catch(() => {});
  }

  const gameMsg = await thread?.send({
    embeds: [ui.embed],
    components: [ui.row],
  }).catch(() => null);

  if (!gameMsg) {
    return respond({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось отправить игровое сообщение.`,
      embeds: [],
      components: [],
    });
  }
}

function getVisibleCommunityCount(street: Street): number {
  switch (street) {
    case 'preflop': return 0;
    case 'flop': return 3;
    case 'turn': return 4;
    case 'river':
    case 'showdown': return 5;
    default: return 0;
  }
}

const STREET_LABELS: Record<Street, string> = {
  preflop: 'Префлоп',
  flop: 'Флоп',
  turn: 'Терн',
  river: 'Ривер',
  showdown: 'Вскрытие',
};

function buildBettingPhaseUI(session: BlindSession): { embed: EmbedBuilder; row: ActionRowBuilder<ButtonBuilder> } | null {
  const active = countActivePlayers(session);
  if (active <= 1 || session.respondersNeeded <= 0) return null;

  const currentPlayer = session.players[session.currentTurnIndex];
  const needsCall = currentPlayer.bet < session.currentBet;
  const callAmount = session.currentBet - currentPlayer.bet;

  const street = session.street ?? 'preflop';
  const community = session.communityCards ?? [];
  const visibleCount = getVisibleCommunityCount(street);
  const communityStr = visibleCount > 0
    ? `\n**Стол:** ${formatCards(community.slice(0, visibleCount))}\n`
    : '';

  const names = session.players.map(p => {
    const stack = p.stack ?? 0;
    const status = p.folded ? '(пас)' : `ставка: ${p.bet} | фишки: ${stack}`;
    return `<@${p.id}> ${status}`;
  }).join('\n');

  const embed = new EmbedBuilder()
    .setTitle(`🃏 Покер — ${STREET_LABELS[street]}`)
    .setDescription(
      `${communityStr}\n` +
        `${names}\n\n` +
        `Банк: **${session.pot}**\n` +
        `Текущая ставка: **${session.currentBet}**\n\n` +
        `Ход: <@${currentPlayer.id}>` +
        (needsCall ? ` (доплата **${callAmount}** для колла)` : ''),
    )
    .setColor(UI_CONFIG.COLORS.BLIND);

  const buttons: ButtonBuilder[] = [];
  if (needsCall) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId('blind:call')
        .setLabel(`Уравнять (+${callAmount})`)
        .setStyle(ButtonStyle.Primary),
    );
  } else {
    buttons.push(
      new ButtonBuilder()
        .setCustomId('blind:check')
        .setLabel('Проверить')
        .setStyle(ButtonStyle.Primary),
    );
  }
  buttons.push(
    new ButtonBuilder().setCustomId('blind:raise').setLabel('Поставить ставку').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('blind:fold').setLabel('Сбросить').setStyle(ButtonStyle.Danger),
  );
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(...buttons);
  return { embed, row };
}

async function renderBettingPhase(interaction: any, session: BlindSession) {
  const ui = buildBettingPhaseUI(session);
  if (!ui) return revealCards(interaction, session);
  const payload = { embeds: [ui.embed], components: [ui.row] };
  try {
    if (interaction.deferred) {
      return await interaction.editReply(payload);
    }
    return await interaction.update(payload);
  } catch (err) {
    console.error('[blind] renderBettingPhase edit failed:', err);
    const msg = interaction.message;
    if (msg && typeof (msg as { edit?: (o: unknown) => Promise<unknown> }).edit === 'function') {
      await (msg as { edit: (o: unknown) => Promise<unknown> }).edit(payload);
    } else {
      throw err;
    }
  }
}

async function advanceTurn(interaction: any, session: BlindSession, key: string) {
  const active = countActivePlayers(session);
  if (active <= 1) {
    await setSession(key, session);
    return revealCards(interaction, session);
  }

  if (session.respondersNeeded > 0) {
    session.currentTurnIndex = getNextActivePlayerIndex(session, session.currentTurnIndex);
    await setSession(key, session);
    return renderBettingPhase(interaction, session);
  }

  // Круг ставок завершён — переходим на следующую улицу или вскрытие
  const curStreet = session.street ?? 'preflop';
  const nextStreet: Record<Street, Street | null> = {
    preflop: 'flop',
    flop: 'turn',
    turn: 'river',
    river: 'showdown',
    showdown: null,
  };
  const next = nextStreet[curStreet];
  if (next === 'showdown') {
    await setSession(key, session);
    return revealCards(interaction, session);
  }
  if (next) {
    session.street = next;
    session.currentBet = 0;
    session.respondersNeeded = countActivePlayers(session);
    session.currentTurnIndex = getNextActivePlayerIndex(session, -1);
    await setSession(key, session);
    return renderBettingPhase(interaction, session);
  }

  await setSession(key, session);
  return revealCards(interaction, session);
}

async function handleBlindAction(
  interaction: ButtonInteraction,
  serverId: string,
  channelId: string,
  userId: string,
  action: 'check' | 'call' | 'fold',
) {
  const err = (content: string) =>
    interaction.deferred
      ? interaction.followUp({ content, flags: MessageFlags.Ephemeral }).catch(() => {})
      : interaction.reply({ content, flags: MessageFlags.Ephemeral });

  const found = await findSessionInChannel(serverId, channelId);
  if (!found) return err(`${UI_CONFIG.EMOJI.ERROR} Нет активной игры.`);

  const { session, key } = found;

  if (session.phase !== 'betting') return err(`${UI_CONFIG.EMOJI.ERROR} Сейчас не фаза ставок.`);

  const currentPlayer = session.players[session.currentTurnIndex];
  if (currentPlayer.id !== userId) return err(`${UI_CONFIG.EMOJI.ERROR} Сейчас не ваш ход.`);

  if (action === 'check') {
    if (currentPlayer.bet < session.currentBet) {
      return err(`${UI_CONFIG.EMOJI.ERROR} Нельзя проверить — ваша ставка ниже текущей (${currentPlayer.bet} < ${session.currentBet}). Используйте Уравнять.`);
    }
  }

  if (action === 'call') {
    const diff = session.currentBet - currentPlayer.bet;
    if (diff <= 0) return err(`${UI_CONFIG.EMOJI.ERROR} Ваша ставка уже соответствует. Используйте Проверить.`);
    const stack = currentPlayer.stack ?? 0;
    if (stack < diff) return err(`${UI_CONFIG.EMOJI.ERROR} Недостаточно фишек на столе (нужно ${diff}, у вас: ${stack}).`);
    currentPlayer.stack = stack - diff;
    currentPlayer.bet = session.currentBet;
    session.pot += diff;
  }

  if (action === 'fold') {
    currentPlayer.folded = true;
  }

  session.respondersNeeded--;

  return advanceTurn(interaction, session, key);
}

function handleBlindRaiseModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId('blind:raiseModal')
    .setTitle('Поставить ставку — сумма');

  const input = new TextInputBuilder()
    .setCustomId('raise_amount')
    .setLabel('На сколько повысить ставку?')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(input),
  );

  return interaction.showModal(modal);
}

export async function handleBlindRaiseSubmit(interaction: ModalSubmitInteraction) {
  if (!interaction.guild || !interaction.channelId) return;

  const serverId = interaction.guild.id;
  const channelId = interaction.channelId;
  const userId = interaction.user.id;

  const found = await findSessionInChannel(serverId, channelId);
  if (!found) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нет активной игры.`, flags: MessageFlags.Ephemeral });
  }

  const { session, key } = found;
  const currentPlayer = session.players[session.currentTurnIndex];
  if (!currentPlayer || currentPlayer.id !== userId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не ваш ход.`, flags: MessageFlags.Ephemeral });
  }

  const raiseRaw = interaction.fields.getTextInputValue('raise_amount');
  const raiseAmount = Number.parseInt(raiseRaw, 10);

  if (Number.isNaN(raiseAmount) || raiseAmount <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма.`, flags: MessageFlags.Ephemeral });
  }

  // Рейз = доплата до текущей ставки + повышение
  const diff = session.currentBet - currentPlayer.bet;
  const totalCost = diff + raiseAmount;

  const stack = currentPlayer.stack ?? 0;
  if (stack < totalCost) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно фишек на столе. Нужно ${totalCost} (колл ${diff} + рейз ${raiseAmount}), у вас: ${stack}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  currentPlayer.stack = stack - totalCost;
  currentPlayer.bet = session.currentBet + raiseAmount;
  session.pot += totalCost;
  session.currentBet = currentPlayer.bet;

  // После рейза все остальные активные игроки должны ответить
  session.respondersNeeded = countActivePlayers(session) - 1;

  return advanceTurn(interaction as any, session, key);
}

async function buildRevealResult(serverId: string, channelId: string, session: BlindSession, guild: import('discord.js').Guild | null) {
  const lines: string[] = [];
  const community = session.communityCards ?? [];
  if (community.length > 0) lines.push('**Стол:** ' + formatCards(community) + '\n');
  lines.push('**Вскрытие:**\n');

  const playerHands: { player: BlindPlayer; hand: ReturnType<typeof evaluateBestHand> }[] = [];
  for (const p of session.players) {
    const holeCards = p.cards && p.cards.length >= 2 ? p.cards : (p.card ? [normalizeCard(p.card)!] : []);
    const cardStr = holeCards.length > 0 ? formatCards(holeCards) : '?';
    let line = `<@${p.id}> — ${p.folded ? '(сброс)' : `**${cardStr}**`}`;
    if (!p.folded && holeCards.length >= 2 && community.length >= 5) {
      const all7 = [...holeCards, ...community] as Card[];
      const hand = evaluateBestHand(all7);
      playerHands.push({ player: p, hand });
      line += ` → **${getHandName(hand)}**`;
    }
    lines.push(line);
  }

  let winnerId: string | null = null;
  if (playerHands.length >= 1) {
    let best = playerHands[0];
    for (let i = 1; i < playerHands.length; i++) {
      if (compareHands(playerHands[i].hand, best.hand) > 0) best = playerHands[i];
    }
    winnerId = best.player.id;
  }
  if (winnerId && session.pot > 0 && guild) {
    const winnerMember = guild.members.cache.get(winnerId);
    const winnerRoleIds: string[] = winnerMember?.roles.cache.map((r: any) => r.id) ?? [];
    const vipMul = await getVipMultiplier(guild.id, winnerRoleIds);
    const config = await getServerConfig(guild.id);
    const payout = calculatePayout(session.pot, vipMul, config?.casinoCommission);
    const { creditAdminCommissionFromPayout } = await import('../services/economy');
    await creditAdminCommissionFromPayout(guild.id, session.pot, config?.casinoCommission);
    await adjustBalance({ serverId: guild.id, userId: winnerId, delta: payout, reason: 'blind_win' });
    await logBet({
      serverId: guild.id, userId: winnerId, gameType: 'blind',
      betAmount: session.buyIn ?? session.minBet, payoutAmount: payout, outcome: 'win', seed: session.seed,
    });
    lines.push(`\n${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> забирает банк **${payout}**!`);
  } else if (winnerId && session.pot > 0) {
    lines.push(`\n${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> забирает банк **${session.pot}**!`);
  } else {
    lines.push(`\nНикто не выиграл.`);
  }
  const found = await findSessionInChannel(serverId, channelId);
  if (found) await deleteSession(found.key);
  const embed = new EmbedBuilder()
    .setTitle('🃏 Покер — Результат')
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.BLIND);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('blind:join').setLabel('Ещё разок').setStyle(ButtonStyle.Success),
  );
  return { embed, row };
}

async function revealCards(interaction: any, session: BlindSession) {
  const { embed, row } = await buildRevealResult(
    interaction.guild?.id ?? '', interaction.channelId ?? '', session, interaction.guild ?? null,
  );
  const payload = { embeds: [embed], components: [row] };
  try {
    if (interaction.deferred) {
      return await interaction.editReply(payload);
    }
    return await interaction.update(payload);
  } catch (err) {
    console.error('[blind] revealCards edit failed:', err);
    const msg = interaction.message;
    if (msg && typeof (msg as { edit?: (o: unknown) => Promise<unknown> }).edit === 'function') {
      await (msg as { edit: (o: unknown) => Promise<unknown> }).edit(payload);
    } else {
      throw err;
    }
  }
}

/** Создать лобби Слепой ставки из стола. Редактирует эмбед лобби (если есть lobbyEmbedMessageId), иначе отправляет новое сообщение. */
export async function startBlindFromLobby(
  thread: import('discord.js').ThreadChannel,
  lobby: { serverId: string; hostId: string; memberIds: string[]; lobbyEmbedMessageId?: string },
  stake: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const channelId = thread.id;
  const hostId = lobby.hostId;

  const session: BlindSession = {
    hostId,
    players: lobby.memberIds.map((id) => ({ id, card: { suit: 0, rank: 0 }, bet: 0, folded: false })),
    pot: 0,
    seed: crypto.randomUUID(),
    phase: 'lobby',
    street: 'preflop',
    communityCards: [],
    currentTurnIndex: 0,
    currentBet: stake,
    minBet: stake,
    buyIn: stake,
    respondersNeeded: 0,
  };

  const key = sessionKey(serverId, channelId, hostId);
  await setSession(key, session);

  const names = session.players.map((p) => `<@${p.id}>`).join(', ');
  const embed = new EmbedBuilder()
    .setTitle('🃏 Покер — Техасский холдем')
    .setDescription(
      '*Стандартный покер по правилам мира. Карты в ЛС, торги в канале.*\n\n' +
        POKER_RULES +
        '\n\n' +
        POKER_COMBINATIONS +
        `\n\n**Банк стола:** ${stake} септимов (лимит ставки ×2 = ${stake * 2}).\n` +
        `Игроки вносят ${stake} в стол — ставки идут из фишек, не из кошелька.\n\n` +
        `Игроки (${session.players.length}): ${names}\n` +
        `Организатор: <@${hostId}>\n\n` +
        'Организатор жмёт **Старт** — раздаём карты.',
    )
    .setImage(POKER_COMBINATIONS_IMAGE)
    .setColor(UI_CONFIG.COLORS.BLIND);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('blind:join').setLabel('Войти в стол').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('blind:start').setLabel('Старт').setStyle(ButtonStyle.Primary),
  );

  const payload = { embeds: [embed], components: [row] };
  const msgId = lobby.lobbyEmbedMessageId;
  if (msgId) {
    const msg = await thread.messages.fetch(msgId).catch(() => null);
    if (msg) {
      await msg.edit(payload).catch(() => {});
      return { ok: true };
    }
  }
  await thread.send(payload);
  return { ok: true };
}
