import {
  ActionRowBuilder,
  ButtonInteraction,
  Interaction,
  ModalBuilder,
  ModalSubmitInteraction,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextInputBuilder,
  TextInputStyle,
  type GuildMember,
  MessageFlags,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { getServerConfig, isChannelAllowedForGames } from '../config/serverConfigService';
import type { CommandName } from '../commands/definitions';

// Commands
import { handleHelp } from '../commands/help';
import { handleBalance } from '../commands/balance';
import { handleDaily } from '../commands/daily';
import { handleProfile } from '../commands/profile';
import { handleSettingsRoot, handleSettingsButton, handleSettingsChannelsModal, handleSettingsChannelsTicketsModal, handleSettingsEconomyModal, handleSettingsRolesModal, handleSettingsLimitsModal, handleSettingsSelect, handleSettingsRatingIntervalSelect } from '../commands/settings';
import { handleTableRoot, handleTableCreateModal } from '../commands/table';
import { handleDiceRoot, handleBlindRoot, handleDuelRoot, handleTugRoot, handleInterventionRoot, handlePokerRoot } from '../commands/games';

// Game button/modal handlers
import { handleInterventionBetModal, handleInterventionButton, handleInterventionPvPBetModal } from '../games/intervention';
import { handleBlindButton, handleBlindRaiseSubmit } from '../games/blind';
import { handleDicePokerButton, handleDicePokerRaiseModal, handleDicePokerRerollSelect } from '../games/dicePoker';
import { handleDuelButton, handleDuelBetModal } from '../games/duel';
import { handleTugButton } from '../games/tug';
import { handleGamesChannelButton, handleGamesChannelDiceModal, handleGamesChannelDuelModal, handleGamesChannelInterventionModal, handleGamesChannelCreateTableGameSelect, handleGamesChannelCreateTableSeatsSelect, handleGamesChannelJoinTable } from '../games/gamesChannelPanel';
import { handleShop, handleShopButton } from '../services/shop';
import {
  handleEventRoot,
  handleEventCreateModal,
  handleEventButton,
  handleBroadcastSelectMenu,
  handleArenaSignUpButton,
  handleArenaSignUpRoleButton,
  handleArenaSignUpTeamSelect,
  handleArenaSignUpLeaderModal,
  handleArenaSignUpMemberModal,
  handleArenaAdminAddExpenseModal,
  handleArenaCreateEventButton,
  handleArenaUnsignButton,
  handleArenaAdminStart,
  handleArenaAdminComplete,
  handleArenaAdminAddExpense,
  handleArenaAdminSettle,
  handleArenaAdminAddPrize,
  handleArenaAdminWinner,
  handleArenaAdminEquipment,
  handleArenaAdminExportExcel,
  handleArenaAdminEditList,
  handleArenaCreateSelect,
  handleArenaCreateTeamSizeSelect,
  handleArenaBetSelect,
  handleArenaAdminRemoveParticipantSelect,
  handleArenaSignUpModal,
  handleEventCreateArenaModal,
  handleArenaBetModal,
  handleArenaAdminAddPrizeModal,
} from '../commands/event';
import { handleStats, handleStatsSelect } from '../commands/stats';
import { handleCurrencyRoot } from '../commands/currency';
import { showPokerBetModal, handlePokerBetModal } from '../games/poker';
import { handleDiceStakeModal } from '../games/diceStakeModal';
import * as diceModule from '../games/dice';
import { handleDicePvPAccept, handleDicePvPDecline, handleDicePvPRoll, handleDicePvPCategory, handleDiceMultiRoll } from '../games/dicePvP';
import { handleTableButton, handleTableGameSelect } from '../commands/table';
import {
  handleTicketsWithdraw,
  handleTicketsDeposit,
  handleTicketsDepositApprove,
  handleTicketsDepositDecline,
  handleTicketsWithdrawApprove,
  handleTicketsWithdrawDecline,
  handleTicketsWithdrawModal,
  handleTicketsDepositModal,
  handleTicketsStakesSelect,
} from '../services/tickets';

const processedInteractionIds = new Set<string>();
const DEDUP_TTL_MS = 5000;

export async function onInteractionCreate(interaction: Interaction) {
  const id = interaction.id;
  if (processedInteractionIds.has(id)) {
    return;
  }
  processedInteractionIds.add(id);
  setTimeout(() => processedInteractionIds.delete(id), DEDUP_TTL_MS);

  const kind = interaction.isChatInputCommand() ? `command:${interaction.commandName}`
    : interaction.isButton() ? `button:${interaction.customId.slice(0, 30)}`
    : interaction.isModalSubmit() ? `modal:${interaction.customId}`
    : interaction.isAnySelectMenu() ? `select:${interaction.customId}` : 'other';
  console.log('[Interaction]', kind);

  // showModal — только синхронно, без await до вызова, иначе Unknown interaction (10062)
  if (interaction.isButton() && interaction.guild) {
    const cid = interaction.customId;
    if (cid === 'gamesChannel:createTable') {
      const select = new StringSelectMenuBuilder()
        .setCustomId('gamesChannel:createTableGameSelect')
        .setPlaceholder('Выберите игру')
        .addOptions(
          { label: 'Кости', value: 'dice', emoji: '🎲' },
          { label: 'Покер на кубиках', value: 'dicepoker', emoji: '🎲' },
          { label: 'Покер', value: 'blind', emoji: '🃏' },
          { label: 'Дуэль', value: 'duel', emoji: '⚔️' },
          { label: 'Интервенция 21.5', value: 'intervention', emoji: '🃏' },
        );
      const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
      return interaction.reply({
        content: '**Создать стол** — выберите игру:',
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    }
    if (cid === 'poker:bet') return showPokerBetModal(interaction);
    if (cid.startsWith('arena:adminAddExpense:')) {
      const eventId = cid.replace('arena:adminAddExpense:', '');
      const modal = new ModalBuilder()
        .setCustomId(`arena:adminAddExpenseModal:${eventId}`)
        .setTitle('Добавить расход');
      modal.addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId('amount').setLabel('Сумма (септимы)').setStyle(TextInputStyle.Short)
            .setPlaceholder('500').setRequired(true),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId('reason').setLabel('Причина (опционально)').setStyle(TextInputStyle.Short)
            .setPlaceholder('призы, выпивка, донат').setRequired(false),
        ),
      );
      return interaction.showModal(modal);
    }
    if (cid.startsWith('arena:adminAddPrize:')) {
      const eventId = cid.replace('arena:adminAddPrize:', '');
      const modal = new ModalBuilder()
        .setCustomId(`arena:adminAddPrizeModal:${eventId}`)
        .setTitle('Добавить к выигрышу');
      modal.addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId('bonus').setLabel('Сумма бонуса (септимы)').setStyle(TextInputStyle.Short)
            .setPlaceholder('500').setRequired(true),
        ),
      );
      return interaction.showModal(modal);
    }
  }

  // Ветки с играми: сбрасываем таймер 3 мин (fire-and-forget, не блокирует ответ)
  if ((interaction.isButton() || interaction.isModalSubmit() || interaction.isAnySelectMenu())
    && interaction.channel?.isThread?.() && interaction.guild?.id) {
    void (async () => {
      const { getLobby, setLobbyLastMessage } = await import('../games/lobbyTables');
      const lobby = await getLobby(interaction.guild!.id, interaction.channel!.id);
      if (lobby) void setLobbyLastMessage(interaction.guild!.id, interaction.channel!.id);
    })();
  }

  try {
    if (interaction.isChatInputCommand()) {
      await handleSlashCommand(interaction);
    } else if (interaction.isButton()) {
      await handleButton(interaction);
    } else if (interaction.isModalSubmit()) {
      await handleModal(interaction);
    } else if (interaction.isAnySelectMenu()) {
      await handleSelect(interaction as StringSelectMenuInteraction);
    } else if (interaction.isRepliable()) {
      await interaction.reply({ content: 'Тип взаимодействия не поддерживается.', flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  } catch (err) {
    console.error('Interaction error', err);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: 'Произошла ошибка при обработке команды.',
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    } else if (interaction.isRepliable() && (interaction.deferred || interaction.replied)) {
      await interaction.followUp({
        content: 'Произошла ошибка при обработке команды.',
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }
  }
}

// ─── Slash command router ───

async function handleSlashCommand(interaction: any) {
  const { commandName, guild } = interaction;

  if (!guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Бот работает только на серверах.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const isSettings = commandName === 'settings';
  const isHelp = commandName === 'help';
  const isCurrency = commandName === 'currency';
  const needsConfig = !isSettings && !isHelp && !isCurrency;

  // Defer сразу, если будут долгие операции (getServerConfig и т.д.) — иначе 10062
  if (needsConfig && interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const editReply = interaction.editReply.bind(interaction);
    (interaction as any).reply = editReply;
  }

  const config = await getServerConfig(guild.id);
  if (!isSettings && !isHelp && !isCurrency && !config) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Бот не настроен. Используйте \`/settings\`, чтобы включить игры на этом сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const gameCommands: CommandName[] = [
    'dice', 'blind', 'duel', 'tug', 'intervention', 'poker', 'table',
  ];
  const isGameCommand = gameCommands.includes(commandName as CommandName);

  if (isGameCommand && config) {
    const isTug = commandName === 'tug';
    if (!isTug) {
      const ch = interaction.channel;
      const effectiveChannelId = ch?.isThread?.() ? (ch as { parentId?: string }).parentId : interaction.channelId;
      const allowed = isChannelAllowedForGames(config, effectiveChannelId ?? interaction.channelId);
      const mode = (config as { channelAccessMode?: string }).channelAccessMode ?? 'none';
      const inGamesThread = ch?.isThread?.() && (ch as { parentId?: string }).parentId === config.gamesChannelId;
      const requireThread = mode !== 'whitelist' && config.gamesChannelId;
      if (!allowed || (requireThread && !inGamesThread)) {
        const hint = mode === 'whitelist'
          ? 'Игровые команды доступны только в разрешённых каналах (см. /settings → Доступ).'
          : `Игровые команды доступны только в ветках канала <#${config.gamesChannelId}>.`;
        return interaction.reply({
          content: `${UI_CONFIG.EMOJI.ERROR} ${hint}`,
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    const member = interaction.member as GuildMember;
    const playerRole = config.roles.find((r: any) => r.type === 'PLAYER');
    if (playerRole && !member.roles.cache.has(playerRole.roleId)) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Для игры требуется роль <@&${playerRole.roleId}>.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    const gameKey = commandName === 'table' ? 'table' : (commandName as CommandName);
    const enabled = config.enabledGames.find(
      (g: any) => g.gameKey === gameKey && g.enabled,
    );
    if (!enabled) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.INFO} Эта игра сейчас отключена в настройках.`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  switch (commandName as CommandName) {
    case 'settings':
      return handleSettingsRoot(interaction);
    case 'help':
      return handleHelp(interaction);
    case 'dice':
      return handleDiceRoot(interaction);
    case 'balance':
      return handleBalance(interaction);
    case 'daily':
      return handleDaily(interaction);
    case 'profile':
      return handleProfile(interaction);
    case 'blind':
      return handleBlindRoot(interaction);
    case 'duel':
      return handleDuelRoot(interaction);
    case 'tug':
      return handleTugRoot(interaction);
    case 'intervention':
      return handleInterventionRoot(interaction);
    case 'poker':
      return handlePokerRoot(interaction);
    case 'shop':
      return handleShop(interaction);
    case 'table':
      return handleTableRoot(interaction);
    case 'event':
      return handleEventRoot(interaction);
    case 'stats':
      return handleStats(interaction);
    case 'currency':
      return handleCurrencyRoot(interaction);
    default:
      return interaction.reply({
        content: 'Эта команда ещё не реализована.',
        flags: MessageFlags.Ephemeral,
      });
  }
}

// ─── Button router ───

async function handleButton(interaction: ButtonInteraction) {
  if (interaction.replied || interaction.deferred) return;

  const { customId } = interaction;

  if (customId.startsWith('settings:')) {
    return handleSettingsButton(interaction);
  }

  if (customId.startsWith('gamesChannel:')) {
    return handleGamesChannelButton(interaction);
  }

  if (customId === 'poker:bet') return showPokerBetModal(interaction);
  if (customId === 'dice:bet') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Кости только с другим игроком. Используйте \`/dice opponent:@игрок\` или кнопку **Кости** в канале игр и укажите оппонента.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (customId === 'dice:reroll') return diceModule.handleDiceReroll(interaction);
  if (customId === 'dice:accept') return handleDicePvPAccept(interaction);
  if (customId === 'dice:decline') return handleDicePvPDecline(interaction);
  if (customId === 'dice:roll') return handleDicePvPRoll(interaction);
  if (customId === 'diceMulti:roll') return handleDiceMultiRoll(interaction);

  if (customId.startsWith('blind:')) {
    const action = customId.replace('blind:', '').split(':')[0];
    if (['check', 'call', 'fold'].includes(action)) {
      await interaction.deferUpdate().catch(() => {});
    }
    return handleBlindButton(interaction);
  }
  if (customId.startsWith('dicePoker:')) {
    return handleDicePokerButton(interaction);
  }

  if (customId.startsWith('duel:')) {
    return handleDuelButton(interaction);
  }

  if (customId.startsWith('tug:')) {
    return handleTugButton(interaction);
  }

  if (customId.startsWith('table:')) return handleTableButton(interaction);

  if (customId.startsWith('intervention:')) {
    return handleInterventionButton(interaction);
  }

  if (customId.startsWith('shop:')) {
    return handleShopButton(interaction);
  }

  if (customId === 'arena:createEvent') return handleArenaCreateEventButton(interaction);
  if (customId.startsWith('arena:signUp:')) return handleArenaSignUpButton(interaction);
  if (customId.startsWith('arena:signUpRole:')) return handleArenaSignUpRoleButton(interaction);
  if (customId.startsWith('arena:unsign:')) return handleArenaUnsignButton(interaction);
  if (customId.startsWith('arena:adminStart:')) return handleArenaAdminStart(interaction);
  if (customId.startsWith('arena:adminComplete:')) return handleArenaAdminComplete(interaction);
  if (customId.startsWith('arena:adminAddExpense:')) return handleArenaAdminAddExpense(interaction);
  if (customId.startsWith('arena:adminSettle:')) return handleArenaAdminSettle(interaction);
  if (customId.startsWith('arena:adminAddPrize:')) return handleArenaAdminAddPrize(interaction);
  if (customId.startsWith('arena:adminWinner:')) return handleArenaAdminWinner(interaction);
  if (customId.startsWith('arena:adminEquipment:')) return handleArenaAdminEquipment(interaction);
  if (customId.startsWith('arena:adminExportExcel:')) return handleArenaAdminExportExcel(interaction);
  if (customId.startsWith('arena:adminEditList:')) return handleArenaAdminEditList(interaction);
  if (customId.startsWith('event:')) {
    return handleEventButton(interaction);
  }

  if (customId === 'tickets:withdraw') return handleTicketsWithdraw(interaction);
  if (customId === 'tickets:deposit') return handleTicketsDeposit(interaction);
  if (customId.startsWith('tickets:depositApprove:')) return handleTicketsDepositApprove(interaction);
  if (customId.startsWith('tickets:depositDecline:')) return handleTicketsDepositDecline(interaction);
  if (customId.startsWith('tickets:withdrawApprove:')) return handleTicketsWithdrawApprove(interaction);
  if (customId.startsWith('tickets:withdrawDecline:')) return handleTicketsWithdrawDecline(interaction);

  // Любая кнопка должна получить ответ, иначе Discord показывает "ошибку"
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.WARNING} Неизвестная кнопка.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

// ─── Modal router ───

async function handleModal(interaction: ModalSubmitInteraction) {
  if (interaction.replied || interaction.deferred) return;

  const { customId } = interaction;

  if (customId === 'settings:channelsModal') {
    return handleSettingsChannelsModal(interaction);
  }
  if (customId === 'settings:commandsModal') {
    const { handleSettingsCommandsModal } = await import('../commands/settings');
    return handleSettingsCommandsModal(interaction);
  }
  if (customId === 'settings:channelsAdminArenaModal') {
    const { handleSettingsChannelsAdminArenaModal } = await import('../commands/settings');
    return handleSettingsChannelsAdminArenaModal(interaction);
  }
  if (customId === 'settings:channelsTicketsModal') {
    return handleSettingsChannelsTicketsModal(interaction);
  }
  if (customId === 'settings:economyModal') {
    return handleSettingsEconomyModal(interaction);
  }
  if (customId === 'settings:rolesModal') {
    return handleSettingsRolesModal(interaction);
  }
  if (customId === 'settings:limitsModal') {
    return handleSettingsLimitsModal(interaction);
  }
  if (customId === 'settings:accessModal') {
    const { handleSettingsAccessModal } = await import('../commands/settings');
    return handleSettingsAccessModal(interaction);
  }

  if (customId === 'poker:betModal') return handlePokerBetModal(interaction);
  if (customId === 'dice:betModal') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Кости только с другим игроком. Используйте \`/dice opponent:@игрок\` или кнопку **Кости** в канале игр.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (customId === 'dice:stakeModal') return handleDiceStakeModal(interaction);
  if (customId === 'gamesChannel:diceModal') {
    return handleGamesChannelDiceModal(interaction);
  }
  if (customId === 'gamesChannel:duelModal') {
    return handleGamesChannelDuelModal(interaction);
  }
  if (customId === 'gamesChannel:interventionModal') {
    return handleGamesChannelInterventionModal(interaction);
  }
  if (customId.startsWith('gamesChannel:createTableStakeModal:blind:')) {
    const { handleGamesChannelCreateTableStakeModal } = await import('../games/gamesChannelPanel');
    return handleGamesChannelCreateTableStakeModal(interaction);
  }
  if (customId.startsWith('gamesChannel:startTableStake:')) {
    const { handleGamesChannelStartTableStakeModal } = await import('../games/gamesChannelPanel');
    return handleGamesChannelStartTableStakeModal(interaction);
  }
  if (customId === 'intervention:betModal') {
    return handleInterventionBetModal(interaction);
  }
  if (customId.startsWith('interventionPvP:betModal')) {
    return handleInterventionPvPBetModal(interaction);
  }
  if (customId === 'dicePoker:raiseModal') return handleDicePokerRaiseModal(interaction);
  if (customId === 'blind:raiseModal') {
    return handleBlindRaiseSubmit(interaction);
  }
  if (customId.startsWith('duel:betModal')) {
    return handleDuelBetModal(interaction);
  }
  if (customId === 'table:createModal') {
    return handleTableCreateModal(interaction);
  }
  if (customId === 'event:createModal') {
    return handleEventCreateModal(interaction);
  }
  if (customId.startsWith('event:createArenaModal:')) return handleEventCreateArenaModal(interaction);
  if (customId.startsWith('arena:signUpModal:')) return handleArenaSignUpModal(interaction);
  if (customId.startsWith('arena:signUpLeaderModal:')) return handleArenaSignUpLeaderModal(interaction);
  if (customId.startsWith('arena:signUpMemberModal:')) return handleArenaSignUpMemberModal(interaction);
  if (customId.startsWith('arena:betModal:')) return handleArenaBetModal(interaction);
  if (customId.startsWith('arena:adminAddPrizeModal:')) return handleArenaAdminAddPrizeModal(interaction);
  if (customId.startsWith('arena:adminAddExpenseModal:')) return handleArenaAdminAddExpenseModal(interaction);
  if (customId === 'tickets:withdrawModal') return handleTicketsWithdrawModal(interaction);
  if (customId === 'tickets:depositModal') return handleTicketsDepositModal(interaction);

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.WARNING} Неизвестная форма.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

// ─── Select menu router ───

async function handleSelect(interaction: StringSelectMenuInteraction) {
  if (interaction.replied || interaction.deferred) return;

  const { customId } = interaction;

  if (customId === 'settings:gamesSelect') {
    return handleSettingsSelect(interaction);
  }
  if (customId === 'settings:ratingIntervalSelect') {
    return handleSettingsRatingIntervalSelect(interaction);
  }

  if (customId === 'event:broadcastSelect') return handleBroadcastSelectMenu(interaction);
  if (customId === 'arena:createSelect') return handleArenaCreateSelect(interaction);
  if (customId.startsWith('arena:createTeamSizeSelect:')) return handleArenaCreateTeamSizeSelect(interaction);
  if (customId.startsWith('arena:betSelect:')) return handleArenaBetSelect(interaction);
  if (customId.startsWith('arena:adminRemoveParticipant:')) return handleArenaAdminRemoveParticipantSelect(interaction);
  if (customId.startsWith('arena:signUpTeamSelect:')) return handleArenaSignUpTeamSelect(interaction);

  if (customId === 'stats:gameSelect') {
    return handleStatsSelect(interaction);
  }

  if (customId === 'table:createSelect') return handleTableGameSelect(interaction, false);
  if (customId === 'table:createPublicSelect') return handleTableGameSelect(interaction, true);
  if (customId === 'dice:category') return handleDicePvPCategory(interaction);
  if (customId === 'tickets:stakesMenu') return handleTicketsStakesSelect(interaction);

  if (customId === 'gamesChannel:joinTable') {
    return handleGamesChannelJoinTable(interaction);
  }
  if (customId === 'gamesChannel:createTableGameSelect') {
    return handleGamesChannelCreateTableGameSelect(interaction);
  }
  if (customId.startsWith('gamesChannel:createTableSeats:')) {
    return handleGamesChannelCreateTableSeatsSelect(interaction);
  }
  if (customId.startsWith('gamesChannel:createTableStakeSelect:')) {
    const { handleGamesChannelCreateTableStakeSelect } = await import('../games/gamesChannelPanel');
    return handleGamesChannelCreateTableStakeSelect(interaction);
  }
  if (customId.startsWith('dicePoker:rerollSelect:')) {
    return handleDicePokerRerollSelect(interaction);
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.WARNING} Неизвестное меню.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}
