import { redis } from '../db/redis';
import { prisma } from '../db/client';
import { LimitType } from '@prisma/client';

type LimitsMap = Partial<Record<LimitType, number>>;

async function getLimits(serverId: string): Promise<LimitsMap> {
  const rows = await prisma.limitConfig.findMany({
    where: { server: { serverId } },
  });

  const map: LimitsMap = {};
  for (const row of rows) {
    map[row.type] = row.value;
  }
  return map;
}

export async function checkBetPerMinuteLimit(
  serverId: string,
  userId: string,
): Promise<{ ok: true } | { ok: false; reason: string }> {
  try {
    const limits = await getLimits(serverId);
    const maxBets = limits[LimitType.BET_PER_MINUTE];
    if (!maxBets || maxBets <= 0) {
      return { ok: true };
    }

    const key = `limits:bet_per_minute:${serverId}:${userId}`;
    const current = await redis.incr(key);
    if (current === 1) {
      await redis.expire(key, 60);
    }

    if (current > maxBets) {
      return {
        ok: false,
        reason: 'Превышен лимит количества ставок в минуту.',
      };
    }

    return { ok: true };
  } catch {
    return { ok: true }; // Limits disabled when Redis unavailable
  }
}

export async function checkWinPerHourLimit(
  serverId: string,
  userId: string,
  payout: number,
): Promise<{ ok: true } | { ok: false; reason: string }> {
  if (payout <= 0) return { ok: true };

  try {
    const limits = await getLimits(serverId);
    const maxWin = limits[LimitType.WIN_PER_HOUR];
    if (!maxWin || maxWin <= 0) {
      return { ok: true };
    }

    const key = `limits:win_per_hour:${serverId}:${userId}`;
    const prevRaw = await redis.get(key);
    const prev = prevRaw ? Number.parseInt(prevRaw, 10) : 0;
    const next = prev + payout;

    if (next > maxWin) {
      return {
        ok: false,
        reason: 'Превышен лимит выигрыша за час.',
      };
    }

    await redis.set(key, String(next), 'EX', 60 * 60);

    return { ok: true };
  } catch {
    return { ok: true }; // Limits disabled when Redis unavailable
  }
}

