/**
 * Выгрузка мероприятий в Excel. Один файл на день — данные накапливаются, на следующий день новый файл.
 */

import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const EXPORTS_DIR = path.join(process.cwd(), 'data', 'exports');

function getDateKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function getDailyFilePath(serverId: string): string {
  const dir = path.join(EXPORTS_DIR, serverId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, `мероприятия_${getDateKey()}.xlsx`);
}

const HEADERS = [
  'ID',
  'Название',
  'Тип',
  'Дата завершения',
  'Участник',
  'User ID',
  'Броня',
  'Оружие',
  'Прайм тайм',
  'Взнос',
  'Всего в фонде',
  'Расходы',
  'Проигрышные ставки',
  'Сгоревшие ставки',
  'Комиссия',
  'К выплате',
  'Доход бизнеса',
];

export type EventExportRow = {
  id: number;
  title: string;
  eventType: string;
  completedAt: Date | null;
  participants: { userId: string; name: string | null; armorType: string | null; weaponType: string | null; primeTime: string | null; paidAmount: number }[];
  entryFee: number | null;
  totalPool: number;
  totalExpenses: number;
  losingBetsTotal?: number;
  burnedBetsTotal?: number;
  commission?: number;
  totalPayout?: number;
  businessIncome?: number;
};

/** Добавить мероприятие в дневной файл (создаёт или дополняет). */
export function appendEventToDailyFile(serverId: string, ev: EventExportRow): string | null {
  try {
    const filePath = getDailyFilePath(serverId);
    const totalPool = ev.totalPool;
    const rows: Record<string, string | number>[] = [];

    const losingBets = ev.losingBetsTotal ?? 0;
    const burnedBets = ev.burnedBetsTotal ?? 0;
    const commission = ev.commission ?? 0;
    const totalPayout = ev.totalPayout ?? 0;
    const businessIncome = ev.businessIncome ?? 0;

    for (const p of ev.participants) {
      rows.push({
        ID: ev.id,
        'Название': ev.title,
        'Тип': ev.eventType,
        'Дата завершения': ev.completedAt
          ? ev.completedAt.toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' })
          : '—',
        'Участник': p.name?.trim() || '—',
        'User ID': p.userId,
        'Броня': p.armorType?.trim() || '—',
        'Оружие': p.weaponType?.trim() || '—',
        'Прайм тайм': p.primeTime?.trim() || '—',
        'Взнос': p.paidAmount,
        'Всего в фонде': totalPool,
        'Расходы': ev.totalExpenses,
        'Проигрышные ставки': losingBets,
        'Сгоревшие ставки': burnedBets,
        'Комиссия': commission,
        'К выплате': totalPayout,
        'Доход бизнеса': businessIncome,
      });
    }

    if (rows.length === 0) {
      const losingBets = ev.losingBetsTotal ?? 0;
      const burnedBets = ev.burnedBetsTotal ?? 0;
      const commission = ev.commission ?? 0;
      const totalPayout = ev.totalPayout ?? 0;
      const businessIncome = ev.businessIncome ?? 0;
      rows.push({
        ID: ev.id,
        'Название': ev.title,
        'Тип': ev.eventType,
        'Дата завершения': ev.completedAt
          ? ev.completedAt.toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' })
          : '—',
        'Участник': '—',
        'User ID': '—',
        'Броня': '—',
        'Оружие': '—',
        'Прайм тайм': '—',
        'Взнос': ev.entryFee != null ? Number(ev.entryFee) : 0,
        'Всего в фонде': totalPool,
        'Расходы': ev.totalExpenses,
        'Проигрышные ставки': losingBets,
        'Сгоревшие ставки': burnedBets,
        'Комиссия': commission,
        'К выплате': totalPayout,
        'Доход бизнеса': businessIncome,
      });
    }

    let wb: XLSX.WorkBook;
    let sheet: XLSX.WorkSheet;
    let origin: string | undefined;

    if (fs.existsSync(filePath)) {
      wb = XLSX.readFile(filePath);
      const sheetName = wb.SheetNames[0] ?? 'Мероприятия';
      sheet = wb.Sheets[sheetName];
      XLSX.utils.sheet_add_aoa(sheet, [HEADERS], { origin: 'A1' });
      const range = XLSX.utils.decode_range(sheet['!ref'] ?? 'A1');
      origin = XLSX.utils.encode_cell({ r: range.e.r + 1, c: 0 });
    } else {
      wb = XLSX.utils.book_new();
      const data = [HEADERS, ...rows.map((r) => HEADERS.map((h) => r[h] ?? ''))];
      sheet = XLSX.utils.aoa_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, sheet, 'Мероприятия');
      XLSX.writeFile(wb, filePath);
      return filePath;
    }

    XLSX.utils.sheet_add_json(sheet, rows, {
      header: HEADERS,
      skipHeader: true,
      origin,
    });

    XLSX.writeFile(wb, filePath);
    return filePath;
  } catch (err) {
    console.error('[ExcelExport] appendEventToDailyFile error:', err);
    return null;
  }
}

/** Получить путь к дневному файлу (для отправки). Файл создаётся при первом append. */
export function getDailyExportFilePath(serverId: string): string | null {
  const filePath = getDailyFilePath(serverId);
  return fs.existsSync(filePath) ? filePath : null;
}
