import { ModalSubmitInteraction, MessageFlags } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile } from '../services/economy';
import { redis } from '../db/redis';
import { startDicePvP } from './dicePvP';

export async function handleDiceStakeModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild || !interaction.channel) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const raw = await redis.get(`diceChallenge:${interaction.guild.id}:${interaction.user.id}`);
  if (!raw) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Вызов истёк. Используйте снова \`/dice opponent:@user\`.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const { opponentId } = JSON.parse(raw) as { opponentId: string };
  await redis.del(`diceChallenge:${interaction.guild.id}:${interaction.user.id}`);

  const stakeRaw = interaction.fields.getTextInputValue('stake');
  const stake = Number.parseInt(stakeRaw, 10);
  if (Number.isNaN(stake) || stake <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная ставка.`, flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(interaction.guild.id);
  if (stake < config.minBet || stake > config.maxBet) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Ставка от ${config.minBet} до ${config.maxBet}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const myProfile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  const oppProfile = await getOrCreateProfile(interaction.guild.id, opponentId);
  if (myProfile.balance < BigInt(stake)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${myProfile.balance}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  return startDicePvP(interaction, opponentId, stake);
}
