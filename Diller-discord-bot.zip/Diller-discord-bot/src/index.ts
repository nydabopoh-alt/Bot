import './startup-log';
import { client } from './bot';
import { ENV } from './config/env';
import { setLogClient } from './services/logs';

async function main() {
  console.log('Starting...');
  setLogClient(client);
  console.log('Logging in to Discord...');
  await client.login(ENV.BOT_TOKEN);
  console.log('Bot logged in.');

  const { startEventScheduler } = await import('./services/events');
  startEventScheduler(client);

  const { startRatingScheduler } = await import('./commands/top');
  startRatingScheduler(client);

  const { refreshAllActiveLobbies } = await import('./games/lobbyTables');
  const REFRESH_MS = 60 * 1000;
  setInterval(() => refreshAllActiveLobbies(client), REFRESH_MS);
  // Первое обновление списка столов — через 3 с после старта (не ждать минуту)
  setTimeout(() => refreshAllActiveLobbies(client), 3000);
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});

