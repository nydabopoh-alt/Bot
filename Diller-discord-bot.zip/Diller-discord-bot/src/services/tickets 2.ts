import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type Client,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type TextChannel,
  MessageFlags,
} from 'discord.js';
import { getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile } from './economy';
import { UI_CONFIG } from '../config/ui';

/** Отправить в канал панель с кнопками «Вывести» и «Пополнить» */
export async function sendStakesPanelToChannel(
  client: Client,
  serverId: string,
  channelId: string,
): Promise<void> {
  const channel = await client.channels.fetch(channelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle('🎟️ Ставки и баланс')
    .setDescription(
      'Здесь можно запросить **вывод** средств или узнать о **пополнении** баланса.\n\n' +
        '• **Вывести** — оставить заявку на вывод септимов (админ обработает в канале выдачи).\n' +
        '• **Пополнить** — информация о пополнении баланса.',
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('tickets:withdraw')
      .setLabel('Вывести')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tickets:deposit')
      .setLabel('Пополнить')
      .setStyle(ButtonStyle.Secondary),
  );

  await channel.send({ embeds: [embed], components: [row] }).catch(() => {});
}

/** Кнопка «Вывести» — модалка с суммой, затем заявка в канал выдачи */
export async function handleTicketsWithdraw(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  if (profile.balance < 1) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} На балансе нет средств для вывода.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const modal = new ModalBuilder()
    .setCustomId('tickets:withdrawModal')
    .setTitle('Заявка на вывод');

  const amountInput = new TextInputBuilder()
    .setCustomId('amount')
    .setLabel(`Сумма вывода (макс. ${profile.balance} септимов)`)
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('100')
    .setRequired(true);

  const commentInput = new TextInputBuilder()
    .setCustomId('comment')
    .setLabel('Комментарий (необязательно)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setPlaceholder('Реквизиты, примечание...');

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(amountInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(commentInput),
  );
  return interaction.showModal(modal);
}

/** Обработка модалки «Вывести» — отправка заявки в канал выдачи */
export async function handleTicketsWithdrawModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const amountRaw = interaction.fields.getTextInputValue('amount')?.trim() ?? '';
  const comment = interaction.fields.getTextInputValue('comment')?.trim() ?? '';
  const amount = parseInt(amountRaw, 10);

  if (Number.isNaN(amount) || amount < 1) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  if (profile.balance < amount) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance} септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const config = await getServerConfig(interaction.guild.id);
  const accountingChannelId = (config as { accountingChannelId?: string | null })?.accountingChannelId ?? null;
  if (accountingChannelId) {
    const ch = await interaction.guild.channels.fetch(accountingChannelId).catch(() => null) as TextChannel | null;
    if (ch?.isTextBased()) {
      const embed = new EmbedBuilder()
        .setTitle('Заявка на вывод')
        .setDescription(
          `Пользователь <@${interaction.user.id}> запросил вывод **${amount}** септимов.\n` +
            `Текущий баланс: **${profile.balance}** септимов.\n` +
            (comment ? `Комментарий: ${comment}` : ''),
        )
        .setColor(UI_CONFIG.COLORS.PRIMARY)
        .setTimestamp();
      await ch.send({ embeds: [embed] }).catch(() => {});
    }
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка на вывод **${amount}** септимов отправлена в канал выдачи. Админ обработает её вручную.`,
    flags: MessageFlags.Ephemeral,
  });
}

/** Кнопка «Пополнить» — подсказка */
export async function handleTicketsDeposit(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  return interaction.reply({
    content:
      `${UI_CONFIG.EMOJI.INFO} **Пополнение баланса**\n\n` +
      `Ваш текущий баланс: **${profile.balance}** септимов.\n\n` +
      `Для пополнения обратитесь к администратору или модератору сервера.`,
    flags: MessageFlags.Ephemeral,
  });
}

/** Выбор в меню ставок (заглушка) */
export async function handleTicketsStakesSelect(interaction: StringSelectMenuInteraction) {
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.INFO} Используйте кнопки **Вывести** или **Пополнить** выше.`,
    flags: MessageFlags.Ephemeral,
  });
}
