/**
 * Запуск игр из лобби стола: кнопка «Играть» — игра начинается сразу.
 * Дуэль: 2 играют, остальные в очереди; нечётное — случайный играет с лишним.
 * Кости, Покер, 21: все играют по кругу.
 */

import type { ThreadChannel } from 'discord.js';
import type { LobbyTable } from './lobbyTables';
import { ensureServerConfig } from '../config/serverConfigService';
import { startBlindFromLobby } from './blind';
import { startDiceFromLobby } from './dicePvP';
import { startDicePokerFromLobby } from './dicePoker';
import { startDuelFromLobby } from './duel';
import { startInterventionFromLobby } from './intervention';

export async function startGameFromLobby(
  thread: ThreadChannel,
  lobby: LobbyTable,
  stake: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const config = await ensureServerConfig(serverId);
  if (!config) return { ok: false, error: 'Бот не настроен.' };

  if (lobby.memberIds.length < 2) {
    return { ok: false, error: 'Нужно минимум 2 игрока.' };
  }

  const minBet = config.minBet ?? 10;
  const maxBet = config.maxBet ?? 10000;
  if (stake < minBet || stake > maxBet) {
    return { ok: false, error: `Ставка: ${minBet}–${maxBet} септимов.` };
  }

  switch (lobby.gameType) {
    case 'blind':
      return startBlindFromLobby(thread, lobby, stake);
    case 'dicepoker':
      return startDicePokerFromLobby(thread, lobby, stake);
    case 'dice':
      return startDiceFromLobby(thread, lobby, stake);
    case 'duel':
      return startDuelFromLobby(thread, lobby, stake);
    case 'intervention':
      return startInterventionFromLobby(thread, lobby, stake);
    default:
      return { ok: false, error: 'Неизвестная игра.' };
  }
}
