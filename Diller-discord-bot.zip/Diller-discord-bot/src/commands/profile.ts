import { ChatInputCommandInteraction, EmbedBuilder, MessageFlags } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { t } from '../locale';
import { getOrCreateProfile, getBattleWinsCount, getArenaFightWinsCount, getUserGameStats } from '../services/economy';

const ACCENT_COLOR = 0x5D100A; // тёмно-красный Норы, как в концепте

export async function handleProfile(interaction: ChatInputCommandInteraction) {
  const serverId = interaction.guild!.id;
  const userId = interaction.user.id;

  const [profile, battleWins, arenaWins, gameStats] = await Promise.all([
    getOrCreateProfile(serverId, userId),
    getBattleWinsCount(serverId, userId),
    getArenaFightWinsCount(serverId, userId),
    getUserGameStats(serverId, userId),
  ]);

  const divider = (label: string) =>
    `\`\`\`ㅤㅤㅤㅤ●‗‗‗‗‗‗‗‗‗‗‗‗‗‗‗‗│${label}│‗‗‗‗‗‗‗‗‗‗‗‗‗‗‗‗●ㅤㅤㅤㅤㅤㅤ\`\`\``;

  const gameStatsLines = gameStats.totalGames > 0
    ? [
        `> **${t.profile.gamesPlayed}:** \`${gameStats.totalGames}\``,
        `> **${t.profile.winsLosses}:** \`${gameStats.wins}\` / \`${gameStats.losses}\``,
        `> **${t.profile.winrate}:** \`${gameStats.winrate}%\``,
      ]
    : [`> *${t.profile.noGamesYet}*`];

  const description = [
    `*${t.profile.intro}*`,
    '',
    divider(t.profile.wallet),
    `> **${t.profile.inPocket}:** \`${profile.balance}\` ${t.septims}`,
    `> **Ушло в столы:** \`${profile.totalLost}\` — ${t.profile.lost}`,
    `> **Забрал с опилок:** \`${profile.totalWon}\` — ${t.profile.won}`,
    '',
    divider(t.profile.games),
    ...gameStatsLines,
    '',
    divider(t.profile.fights),
    `> **${t.profile.defeatedOpponents}:** \`${battleWins}\` (азартные игры)`,
    `> **${t.profile.arenaWins}:** \`${arenaWins}\` (белый флаг, командный, похоронный)`,
    '',
    `*${t.profile.whoIs}: <@${userId}>*`,
    '',
    `ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ*${t.profile.fortune}*ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ`,
  ].join('\n');

  const embed = new EmbedBuilder()
    .setTitle(`🐀 ${t.profile.title}`)
    .setDescription(description)
    .setColor(ACCENT_COLOR)
    .setFooter({ text: t.profile.footer });

  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}
