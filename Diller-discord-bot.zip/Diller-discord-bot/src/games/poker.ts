import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  ModalSubmitInteraction,
  TextInputBuilder,
  TextInputStyle,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { checkBetPerMinuteLimit, checkWinPerHourLimit } from '../services/limits';
import { diceStr } from './dice';

const RULES_TEXT =
  '**Правила:**\n' +
  '• Сначала кидаете **вы** — 2 кубика.\n' +
  '• Потом кидает **дилер** — 3 кубика.\n' +
  '• У кого **сумма больше**, тот выиграл. Равная сумма — **ничья**, ставка возвращается.';

export function buildPokerStartEmbed() {
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.POKER} Покер (2 vs 3 кости)`)
    .setDescription(
      RULES_TEXT +
        '\n\n**Выигрыш:** ставка × 2 (с учётом комиссии и VIP).\n\nУкажите ставку в команде `/poker ставка:100` или нажмите **Играть** и введите сумму в форму.',
    )
    .setColor(UI_CONFIG.COLORS.POKER);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('poker:bet').setLabel('Играть').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row] };
}

export function showPokerBetModal(interaction: import('discord.js').ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId('poker:betModal')
    .setTitle('Покер — ставка');

  const input = new TextInputBuilder()
    .setCustomId('stake')
    .setLabel('Ставка (септимы)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
  return interaction.showModal(modal);
}

async function runPokerGame(
  interaction: ChatInputCommandInteraction | ModalSubmitInteraction,
  betAmount: number,
) {
  const guild = interaction.guild;
  if (!guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const serverId = guild.id;
  const userId = interaction.user.id;

  const config = await ensureServerConfig(serverId);
  const profile = await getOrCreateProfile(serverId, userId);

  if (betAmount < config.minBet || betAmount > config.maxBet) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Ставка должна быть от ${config.minBet} до ${config.maxBet}.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (profile.balance < BigInt(betAmount)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const limitCheck = await checkBetPerMinuteLimit(serverId, userId);
  if (!limitCheck.ok) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} ${limitCheck.reason}`, flags: MessageFlags.Ephemeral });
  }

  await adjustBalance({ serverId, userId, delta: -betAmount, reason: 'poker_bet' });

  const player1 = crypto.randomInt(1, 7);
  const player2 = crypto.randomInt(1, 7);
  const playerSum = player1 + player2;

  const dealer1 = crypto.randomInt(1, 7);
  const dealer2 = crypto.randomInt(1, 7);
  const dealer3 = crypto.randomInt(1, 7);
  const dealerSum = dealer1 + dealer2 + dealer3;

  const seed = crypto.randomUUID();
  const member = interaction.member as { roles?: { cache?: { map: (fn: (r: { id: string }) => string) => string[] } } };
  const memberRoleIds: string[] = member?.roles?.cache?.map((r: { id: string }) => r.id) ?? [];

  let embed: EmbedBuilder;
  let outcome: 'win' | 'lose' | 'draw';
  let payoutAmount = 0;

  if (playerSum > dealerSum) {
    const vipMul = await getVipMultiplier(serverId, memberRoleIds);
    const rawPayout = betAmount * 2;
    payoutAmount = calculatePayout(rawPayout, vipMul, config?.casinoCommission ?? 0);
    const { creditAdminCommissionFromPayout } = await import('../services/economy');
    await creditAdminCommissionFromPayout(serverId, rawPayout, config?.casinoCommission ?? 0);
    const winLimit = await checkWinPerHourLimit(serverId, userId, payoutAmount);
    if (!winLimit.ok) payoutAmount = 0;
    if (payoutAmount > 0) {
      await adjustBalance({ serverId, userId, delta: payoutAmount, reason: 'poker_win' });
    }
    outcome = 'win';
    const newBalance = (await getOrCreateProfile(serverId, userId)).balance;
    embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.POKER} Покер — победа!`)
      .setDescription(
        `**Вы:** ${diceStr(player1)} ${diceStr(player2)} → **${playerSum}**\n` +
          `**Дилер:** ${diceStr(dealer1)} ${diceStr(dealer2)} ${diceStr(dealer3)} → **${dealerSum}**\n\n` +
          `${UI_CONFIG.EMOJI.WIN} Выигрыш: **${payoutAmount}** ${UI_CONFIG.EMOJI.COIN}\nБаланс: **${newBalance}**`,
      )
      .setColor(UI_CONFIG.COLORS.WIN);
  } else if (playerSum < dealerSum) {
    outcome = 'lose';
    const newBalance = (await getOrCreateProfile(serverId, userId)).balance;
    embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.POKER} Покер — проигрыш`)
      .setDescription(
        `**Вы:** ${diceStr(player1)} ${diceStr(player2)} → **${playerSum}**\n` +
          `**Дилер:** ${diceStr(dealer1)} ${diceStr(dealer2)} ${diceStr(dealer3)} → **${dealerSum}**\n\n` +
          `${UI_CONFIG.EMOJI.LOSS} Дилер выиграл. Баланс: **${newBalance}**`,
      )
      .setColor(UI_CONFIG.COLORS.LOSS);
  } else {
    await adjustBalance({ serverId, userId, delta: betAmount, reason: 'poker_draw_refund' });
    outcome = 'draw';
    payoutAmount = betAmount;
    const newBalance = (await getOrCreateProfile(serverId, userId)).balance;
    embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.POKER} Покер — ничья`)
      .setDescription(
        `**Вы:** ${diceStr(player1)} ${diceStr(player2)} → **${playerSum}**\n` +
          `**Дилер:** ${diceStr(dealer1)} ${diceStr(dealer2)} ${diceStr(dealer3)} → **${dealerSum}**\n\n` +
          `Суммы равны — ставка возвращена. Баланс: **${newBalance}**`,
      )
      .setColor(UI_CONFIG.COLORS.DRAW);
  }

  await logBet({
    serverId,
    userId,
    gameType: 'poker',
    betAmount,
    payoutAmount,
    outcome,
    seed,
  });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('poker:bet').setLabel('Ещё раз').setStyle(ButtonStyle.Primary),
  );

  return interaction.reply({ embeds: [embed], components: [row] });
}

export async function handlePokerRoot(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const stakeOpt = interaction.options.getInteger('ставка');
  if (stakeOpt != null && stakeOpt > 0) {
    return runPokerGame(interaction, stakeOpt);
  }

  const { embeds, components } = buildPokerStartEmbed();
  return interaction.reply({ embeds, components });
}

export async function handlePokerBetModal(interaction: ModalSubmitInteraction) {
  const raw = interaction.fields.getTextInputValue('stake').trim();
  const betAmount = parseInt(raw, 10);

  if (Number.isNaN(betAmount) || betAmount <= 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Введите корректную сумму ставки.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  return runPokerGame(interaction, betAmount);
}
