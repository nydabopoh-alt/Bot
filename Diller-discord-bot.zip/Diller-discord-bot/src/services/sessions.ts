import { redis } from '../db/redis';

const SESSION_TTL = 600; // 10 минут

export async function setSession<T>(key: string, data: T): Promise<void> {
  await redis.set(`session:${key}`, JSON.stringify(data), 'EX', SESSION_TTL);
}

export async function getSession<T>(key: string): Promise<T | null> {
  const raw = await redis.get(`session:${key}`);
  if (!raw) return null;
  return JSON.parse(raw) as T;
}

export async function deleteSession(key: string): Promise<void> {
  await redis.del(`session:${key}`);
}
