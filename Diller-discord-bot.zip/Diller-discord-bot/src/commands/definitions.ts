import { SlashCommandBuilder } from 'discord.js';

export const commands = {
  settings: new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Настройки игрового бота (только админы)'),
  help: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Справка по игровому боту'),
  balance: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Показать ваш баланс'),
  profile: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('Профиль игрока'),
  daily: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Ежедневный бонус'),
  shop: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Магазин'),
  dice: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Кости PvP: 3 кости, по одному броску. Комбо бьёт не-комбо; оба комбо или оба не комбо — ничья')
    .addUserOption((opt) =>
      opt.setName('opponent').setDescription('Противник').setRequired(true),
    )
    .addIntegerOption((opt) =>
      opt.setName('ставка').setDescription('Ставка с каждого (септимы)').setRequired(false),
    ),
  blind: new SlashCommandBuilder()
    .setName('blind')
    .setDescription('Покер'),
  duel: new SlashCommandBuilder()
    .setName('duel')
    .setDescription('Дуэль 1 на 1')
    .addUserOption((opt) =>
      opt.setName('opponent').setDescription('Противник').setRequired(true),
    ),
  tug: new SlashCommandBuilder()
    .setName('tug')
    .setDescription('Перетягивание каната (ивент, только админ)')
    .addIntegerOption((opt) =>
      opt
        .setName('ставка')
        .setDescription('Ставка с каждого участника — выбирает админ при запуске')
        .setRequired(true)
        .addChoices(
          { name: '50', value: 50 },
          { name: '100', value: 100 },
          { name: '350', value: 350 },
          { name: '500', value: 500 },
          { name: '1000', value: 1000 },
        ),
    ),
  intervention: new SlashCommandBuilder()
    .setName('intervention')
    .setDescription('Интервенция 21.5 — 2 игрока, по очереди тянете карту, оба пас — определяем победителя')
    .addUserOption((opt) =>
      opt.setName('opponent').setDescription('Противник').setRequired(true),
    )
    .addIntegerOption((opt) =>
      opt.setName('ставка').setDescription('Ставка с каждого (септимы)').setRequired(false),
    ),
  poker: new SlashCommandBuilder()
    .setName('poker')
    .setDescription('Покер: вы 2 кубика, дилер 3 кубика — у кого сумма больше, тот выиграл')
    .addIntegerOption((opt) =>
      opt.setName('ставка').setDescription('Ставка (септимы)').setRequired(false),
    ),
  table: new SlashCommandBuilder()
    .setName('table')
    .setDescription('Игровые столы: выберите игру — создаётся приватная ветка (админ видит все)')
    .addSubcommand((sub) =>
      sub.setName('panel').setDescription('Опубликовать панель с кнопками игр в канале (только админ, только канал игр)'),
    )
    .addSubcommand((sub) =>
      sub.setName('create').setDescription('Выбрать игру и создать стол (приватная ветка для участников)'),
    )
    .addSubcommand((sub) =>
      sub.setName('create-public').setDescription('Создать публичный стол для турнира (только админ)'),
    )
    .addSubcommand((sub) =>
      sub.setName('join').setDescription('Войти в стол по ID').addStringOption((o) =>
        o.setName('id').setDescription('ID стола (например из списка)').setRequired(true),
      ),
    )
    .addSubcommand((sub) =>
      sub.setName('leave').setDescription('Покинуть стол'),
    )
    .addSubcommand((sub) =>
      sub.setName('list').setDescription('Список активных столов'),
    ),
  stats: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Правила и статистика выигрышей по каждой игре'),
  currency: new SlashCommandBuilder()
    .setName('currency')
    .setDescription('Управление валютой (только админы)')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Добавить валюту пользователю')
        .addUserOption((opt) =>
          opt.setName('user').setDescription('Пользователь').setRequired(true),
        )
        .addIntegerOption((opt) =>
          opt.setName('amount').setDescription('Сумма септимов').setRequired(true).setMinValue(1),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Убрать валюту у пользователя')
        .addUserOption((opt) =>
          opt.setName('user').setDescription('Пользователь').setRequired(true),
        )
        .addIntegerOption((opt) =>
          opt.setName('amount').setDescription('Сумма септимов').setRequired(true).setMinValue(1),
        ),
    ),
  event: new SlashCommandBuilder()
    .setName('event')
    .setDescription('Мероприятия и рассылки')
    .addSubcommand((sub) =>
      sub.setName('create').setDescription('Создать мероприятие (модераторы)'),
    )
    .addSubcommand((sub) =>
      sub.setName('list').setDescription('Список предстоящих мероприятий'),
    )
    .addSubcommand((sub) =>
      sub
        .setName('cancel')
        .setDescription('Отменить мероприятие (модераторы)')
        .addIntegerOption((opt) =>
          opt.setName('id').setDescription('ID мероприятия').setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('announce')
        .setDescription('Отправить анонс мероприятия вручную (модераторы)')
        .addIntegerOption((opt) =>
          opt.setName('id').setDescription('ID мероприятия').setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub.setName('broadcast').setDescription('Рассылка шаблона в канал объявлений (модераторы)'),
    ),
};

export type CommandName = keyof typeof commands;

export function getSlashCommandData() {
  return Object.values(commands).map((c) => c.toJSON());
}
