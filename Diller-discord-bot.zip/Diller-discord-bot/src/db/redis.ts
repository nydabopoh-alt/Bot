import Redis from 'ioredis';
import { ENV } from '../config/env';

export const redis = new Redis(ENV.REDIS_URL, { lazyConnect: true });

let lastErrorLog = 0;
redis.on('error', (err) => {
  const now = Date.now();
  if (now - lastErrorLog < 30000) return; // Throttle to once per 30s
  lastErrorLog = now;
  const msg =
    (err as Error & { cause?: Error }).cause?.message ??
    (err as Error).message ??
    String(err);
  console.error('[Redis] Connection error:', msg || 'Unable to connect. Is Redis running?');
});

