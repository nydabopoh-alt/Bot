import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
  StringSelectMenuBuilder,
  ModalSubmitInteraction,
  MessageFlags,
  ChannelType,
  PermissionFlagsBits,
  type ButtonInteraction,
  type StringSelectMenuInteraction,
  type GuildMember,
  type TextChannel,
  type ThreadChannel,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG, getGameCommands } from '../config/ui';
import { getServerConfig, isChannelAllowedForGames } from '../config/serverConfigService';
import { redis } from '../db/redis';

const TABLE_TTL = 86400; // 24 ч
const GAME_OPTIONS: { value: string; label: string; emoji: string }[] = [
  { value: 'dice', label: 'Кости', emoji: '🎲' },
  { value: 'blind', label: 'Покер', emoji: '🃏' },
  { value: 'dicepoker', label: 'Покер на кубиках', emoji: '🎲' },
  { value: 'duel', label: 'Дуэль', emoji: '⚔️' },
  { value: 'tug', label: 'Перетягивание каната', emoji: '🪢' },
  { value: 'intervention', label: 'Интервенция 21.5', emoji: '🃏' },
];

export interface TableSession {
  serverId: string;
  channelId: string;
  threadId: string;
  tableId: string;
  gameType: string;
  creatorId: string;
  participants: string[];
  isPublic: boolean;
  lobbyMessageId?: string;
}

function tableKey(serverId: string, tableId: string) {
  return `table:${serverId}:${tableId}`;
}

/** Добавляет в приватный тред всех админов сервера (владелец + Administrator), чтобы они видели ветку. */
async function addAdminsToPrivateThread(guild: import('discord.js').Guild, thread: ThreadChannel): Promise<void> {
  try {
    const members = await guild.members.fetch();
    for (const [, member] of members) {
      if (member.user.bot) continue;
      const isOwner = guild.ownerId === member.id;
      const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);
      if (isOwner || isAdmin) {
        await thread.members.add(member.id).catch(() => {});
      }
    }
  } catch (_) {
    // ignore
  }
}

export async function getTable(serverId: string, tableId: string): Promise<TableSession | null> {
  const raw = await redis.get(tableKey(serverId, tableId));
  if (!raw) return null;
  return JSON.parse(raw) as TableSession;
}

async function setTable(t: TableSession): Promise<void> {
  await redis.set(tableKey(t.serverId, t.tableId), JSON.stringify(t), 'EX', TABLE_TTL);
}

async function deleteTable(serverId: string, tableId: string): Promise<void> {
  await redis.del(tableKey(serverId, tableId));
}

async function listTables(serverId: string): Promise<TableSession[]> {
  const keys = await redis.keys(`table:${serverId}:*`);
  const out: TableSession[] = [];
  for (const k of keys) {
    const raw = await redis.get(k);
    if (raw) out.push(JSON.parse(raw) as TableSession);
  }
  return out;
}

function gameLabel(gameType: string): string {
  return GAME_OPTIONS.find((g) => g.value === gameType)?.label ?? gameType;
}

/** Панель с кнопками игр: каждая кнопка создаёт приватный стол, отдельно — публичный стол (админ). */
async function sendTablePanel(interaction: ChatInputCommandInteraction) {
  const config = await getServerConfig(interaction.guild!.id);
  const enabled = config?.enabledGames ?? [];
  const enabledKeys = new Set(enabled.filter((g: { enabled: boolean }) => g.enabled).map((g: { gameKey: string }) => g.gameKey));
  const options = GAME_OPTIONS.filter((o) => enabledKeys.has(o.value));
  if (options.length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} В настройках не включена ни одна игра. \`/settings\` → Игры.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TABLE} Игровые столы`)
    .setDescription(
      '**Нажмите игру** — создаётся **приватная ветка**. Видят только участники и админ.\n' +
        '**Публичный стол (турнир)** — только для админа, видят все игроки.',
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  const row1 = new ActionRowBuilder<ButtonBuilder>();
  for (const o of options.slice(0, 5)) {
    row1.addComponents(
      new ButtonBuilder()
        .setCustomId(`table:createPrivate:${o.value}`)
        .setLabel(o.label)
        .setStyle(ButtonStyle.Primary),
    );
  }
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('table:createPublic')
      .setLabel('Публичный стол (турнир)')
      .setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Панель опубликована.`,
    flags: MessageFlags.Ephemeral,
  });
  await (interaction.channel as TextChannel).send({
    embeds: [embed],
    components: [row1, row2],
  }).catch(() => null);
}

export async function handleTableRoot(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Столы доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const config = await getServerConfig(interaction.guild.id);
  if (config) {
    const ch = interaction.channel;
    const effectiveChannelId = ch?.isThread?.() ? (ch as { parentId: string }).parentId : interaction.channelId;
    if (!isChannelAllowedForGames(config, effectiveChannelId)) {
      const mode = (config as { channelAccessMode?: string }).channelAccessMode ?? 'none';
      const hint = mode === 'whitelist'
        ? 'Команды столов доступны только в разрешённых каналах (см. /settings → Доступ).'
        : `Команды столов доступны только в канале игр <#${config.gamesChannelId}> или его ветках.`;
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} ${hint}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  const sub = interaction.options.getSubcommand();

  if (sub === 'panel') {
    const member = interaction.member as GuildMember;
    const isAdmin =
      member.permissions.has(PermissionFlagsBits.Administrator) ||
      interaction.guild.ownerId === interaction.user.id;
    if (!isAdmin) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Панель может опубликовать только админ.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return sendTablePanel(interaction);
  }
  if (sub === 'create') {
    return showTableGameSelect(interaction, false);
  }
  if (sub === 'create-public') {
    const member = interaction.member as GuildMember;
    const isAdmin =
      member.permissions.has(PermissionFlagsBits.Administrator) ||
      interaction.guild.ownerId === interaction.user.id;
    if (!isAdmin) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Публичный стол может создать только админ (для турниров).`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return showTableGameSelect(interaction, true);
  }
  if (sub === 'list') {
    const tables = await listTables(interaction.guild.id);
    if (tables.length === 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.INFO} Нет активных столов. Создайте стол: \`/table create\`.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    const lines = tables.map(
      (t) =>
        `• **#${t.tableId}** — ${gameLabel(t.gameType)} (${t.participants.length} чел.) ${t.isPublic ? '— публичный' : '— приватный'}`,
    );
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.TABLE} Активные столы`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.PRIMARY);
    return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  }
  if (sub === 'join') {
    const tableId = interaction.options.getString('id', true).trim();
    const t = await getTable(interaction.guild.id, tableId);
    if (!t) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Стол #${tableId} не найден или закрыт.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return doTableJoin(interaction, t);
  }
  if (sub === 'leave') {
    const tables = await listTables(interaction.guild.id);
    const myTables = tables.filter((t) => t.participants.includes(interaction.user.id));
    if (myTables.length === 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.INFO} Вы не участвуете ни в одном столе.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    const t = myTables[0];
    return doTableLeave(interaction, t);
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.ERROR} Неизвестная подкоманда.`,
    flags: MessageFlags.Ephemeral,
  });
}

function buildTableGameSelectOptions(enabledGames: { gameKey: string; enabled: boolean }[], isPublic: boolean) {
  const enabledKeys = new Set(enabledGames.filter((g) => g.enabled).map((g) => g.gameKey));
  return GAME_OPTIONS.filter((o) => enabledKeys.has(o.value)).map((o) => ({
    label: o.label,
    value: o.value,
    description: isPublic ? 'Публичный стол (турнир)' : 'Приватная ветка',
  }));
}

async function showTableGameSelect(interaction: ChatInputCommandInteraction, isPublic: boolean) {
  const enabled = (await getServerConfig(interaction.guild!.id))?.enabledGames ?? [];
  const options = buildTableGameSelectOptions(enabled, isPublic);
  if (options.length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} В настройках сервера не включена ни одна игра. Включите игры в \`/settings\` → Игры.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(isPublic ? 'table:createPublicSelect' : 'table:createSelect')
      .setPlaceholder('Выберите игру')
      .setMinValues(1)
      .setMaxValues(1)
      .addOptions(options),
  );
  return interaction.reply({
    content: isPublic
      ? `${UI_CONFIG.EMOJI.TABLE} Выберите игру для **публичного** стола (видят все, для турниров).`
      : `${UI_CONFIG.EMOJI.TABLE} Выберите игру — создаётся **приватная ветка**. Только участники и админ видят переписку.`,
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

/** Показать выбор игры для публичного стола (ответ на кнопку «Публичный стол»). */
async function showTableGameSelectForButton(interaction: ButtonInteraction) {
  const enabled = (await getServerConfig(interaction.guild!.id))?.enabledGames ?? [];
  const options = buildTableGameSelectOptions(enabled, true);
  if (options.length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} В настройках не включена ни одна игра.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('table:createPublicSelect')
      .setPlaceholder('Выберите игру для турнира')
      .setMinValues(1)
      .setMaxValues(1)
      .addOptions(options),
  );
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.TABLE} Выберите игру для **публичного** стола (видят все).`,
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

/** Создаёт стол (приватный или публичный тред) и отвечает на interaction (update для select, reply для button). */
async function createTableAndRespond(
  interaction: StringSelectMenuInteraction | ButtonInteraction,
  gameType: string,
  isPublic: boolean,
) {
  if (!interaction.guild || !interaction.channel) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const channel = interaction.channel as TextChannel;
  const serverId = interaction.guild.id;
  const userId = interaction.user.id;
  const tableId = crypto.randomInt(1000, 9999).toString();

  const threadType = isPublic ? ChannelType.PublicThread : ChannelType.PrivateThread;
  const threadName = `🪑 ${gameLabel(gameType)} — #${tableId}`;

  const created = await channel.threads
    .create({
      name: threadName.slice(0, 100),
      type: threadType,
      reason: isPublic ? 'Публичный стол (турнир)' : 'Приватный стол',
    })
    .catch(() => null);

  if (!created) {
    const msg = `${UI_CONFIG.EMOJI.ERROR} Не удалось создать ветку. Проверьте права бота и приватные ветки в канале.`;
    if (interaction.isStringSelectMenu()) return interaction.editReply({ content: msg, components: [] }).catch(() => {});
    return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
  }

  const table: TableSession = {
    serverId,
    channelId: channel.id,
    threadId: created.id,
    tableId,
    gameType,
    creatorId: userId,
    participants: [userId],
    isPublic,
  };

  await setTable(table);

  const thread = created as ThreadChannel;
  if (threadType === ChannelType.PrivateThread) {
    await thread.members.add(userId).catch(() => {});
    await addAdminsToPrivateThread(interaction.guild, thread);
  }

  const commands = getGameCommands(gameType);
  await thread
    .send({
      content: `Стол **#${tableId}** создан. Игра началась! Используйте в этом треде: ${commands}. Участники заходят по кнопке в канале.`,
    })
    .catch(() => null);

  const lobbyEmbed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TABLE} Стол #${tableId} — ${gameLabel(gameType)}`)
    .setDescription(
      (isPublic ? '**Публичный стол** (турнир). Видят все.\n\n' : '**Приватная ветка.** Видят только админы сервера и участники, нажавшие «Войти».\n\n') +
        `Участников: **${table.participants.length}**\n` +
        `Тред: <#${created.id}>`,
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`table:join:${tableId}`).setLabel('Войти').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`table:leave:${tableId}`).setLabel('Выйти').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`table:start:${tableId}`).setLabel('Старт').setStyle(ButtonStyle.Primary),
  );

  const lobbyMsg = await channel.send({ embeds: [lobbyEmbed], components: [row] }).catch(() => null);
  if (lobbyMsg) {
    table.lobbyMessageId = lobbyMsg.id;
    await setTable(table);
  }

  const successMsg = `${UI_CONFIG.EMOJI.SUCCESS} Стол **#${tableId}** создан. Тред: <#${created.id}>. Кнопки ниже в канале.`;
  if (interaction.isStringSelectMenu()) {
    return interaction.editReply({ content: successMsg, components: [] }).catch(() => {});
  }
  return interaction.reply({ content: successMsg, flags: MessageFlags.Ephemeral });
}

export async function handleTableGameSelect(interaction: StringSelectMenuInteraction, isPublic: boolean) {
  const gameType = interaction.values[0];
  await interaction.deferUpdate();
  return createTableAndRespond(interaction, gameType, isPublic);
}

async function doTableJoin(
  interaction: ChatInputCommandInteraction | ButtonInteraction,
  t: TableSession,
): Promise<void> {
  const userId = interaction.user.id;
  if (t.participants.includes(userId)) {
    const payload = { content: `${UI_CONFIG.EMOJI.INFO} Вы уже в столе. Тред: <#${t.threadId}>`, flags: MessageFlags.Ephemeral };
    if (interaction.isButton()) {
      return interaction.reply(payload);
    }
    return interaction.reply(payload);
  }

  t.participants.push(userId);
  await setTable(t);

  const thread = await interaction.guild!.channels.fetch(t.threadId).catch(() => null) as ThreadChannel | null;
  if (thread && !t.isPublic) {
    await thread.members.add(userId).catch(() => {});
  }

  const payload = {
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы вошли в стол #${t.tableId}. Переходите в тред: <#${t.threadId}>`,
    flags: MessageFlags.Ephemeral,
  };
  if (interaction.isButton()) {
    return interaction.reply(payload);
  }
  return interaction.reply(payload);
}

async function doTableLeave(
  interaction: ChatInputCommandInteraction | ButtonInteraction,
  t: TableSession,
): Promise<void> {
  const userId = interaction.user.id;
  if (!t.participants.includes(userId)) {
    const payload = { content: `${UI_CONFIG.EMOJI.INFO} Вы не в этом столе.`, flags: MessageFlags.Ephemeral };
    if (interaction.isButton()) return interaction.reply(payload);
    return interaction.reply(payload);
  }

  t.participants = t.participants.filter((id) => id !== userId);
  if (t.participants.length === 0) {
    await deleteTable(t.serverId, t.tableId);
  } else {
    await setTable(t);
  }

  const thread = await interaction.guild!.channels.fetch(t.threadId).catch(() => null) as ThreadChannel | null;
  if (thread && !t.isPublic) {
    await thread.members.remove(userId).catch(() => {});
  }

  const payload = {
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы вышли из стола #${t.tableId}.`,
    flags: MessageFlags.Ephemeral,
  };
  if (interaction.isButton()) return interaction.reply(payload);
  return interaction.reply(payload);
}

export async function handleTableButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const { customId } = interaction;
  if (!customId.startsWith('table:')) return;

  const parts = customId.split(':');

  if (parts[1] === 'createPrivate' && parts[2]) {
    const gameType = parts[2];
    const config = await getServerConfig(interaction.guild.id);
    const enabled = config?.enabledGames ?? [];
    const enabledKeys = new Set(enabled.filter((g: { enabled: boolean }) => g.enabled).map((g: { gameKey: string }) => g.gameKey));
    if (!enabledKeys.has(gameType)) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Игра отключена в настройках.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (gameType === 'dice') {
      return interaction.reply({
        content:
          `${UI_CONFIG.EMOJI.DICE} **Кости PvP** — 3 кости, по одному броску каждому. Комбо бьёт не-комбо; оба комбо или оба не комбо — ничья.\n\n` +
          `Вызовите оппонента: \`/dice opponent:@игрок\` или \`/dice opponent:@игрок ставка:100\`.\n` +
          `Игра начнётся в **приватной ветке** (видят только вы, оппонент и админ).`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (gameType === 'dicepoker') {
      return interaction.reply({
        content:
          `${UI_CONFIG.EMOJI.TABLE} **Покер на кубиках** — через кнопку **«Создать стол»** в канале игр.\n\n` +
          `Там: выберите игру → количество мест (2–6) → **банк стола** → создаётся ветка. Игроки заходят по списку «Активные столы» и нажимают **Играть**.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return createTableAndRespond(interaction, gameType, false);
  }

  if (parts[1] === 'createPublic') {
    const member = interaction.member as GuildMember;
    const isAdmin =
      member.permissions.has(PermissionFlagsBits.Administrator) ||
      interaction.guild.ownerId === interaction.user.id;
    if (!isAdmin) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Публичный стол может создать только админ.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return showTableGameSelectForButton(interaction);
  }

  if (parts.length < 3) return;
  const action = parts[1];
  const tableId = parts[2];

  const t = await getTable(interaction.guild.id, tableId);
  if (!t) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Стол #${tableId} не найден или закрыт.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (action === 'join') {
    return doTableJoin(interaction, t);
  }
  if (action === 'leave') {
    return doTableLeave(interaction, t);
  }
  if (action === 'start') {
    const isCreator = t.creatorId === interaction.user.id;
    const member = interaction.member as GuildMember;
    const isAdmin =
      member.permissions.has(PermissionFlagsBits.Administrator) ||
      interaction.guild.ownerId === interaction.user.id;
    if (!isCreator && !isAdmin) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Запуск только у создателя стола или админа.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    const thread = await interaction.guild.channels.fetch(t.threadId).catch(() => null) as ThreadChannel | null;
    if (thread) {
      const commands = getGameCommands(t.gameType);
      await thread.send({
        content: `${UI_CONFIG.EMOJI.TABLE} Стол запущен. Игра началась! Используйте в этом треде: ${commands}.`,
      }).catch(() => {});
    }
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.SUCCESS} Старт объявлен в треде <#${t.threadId}>.`,
      flags: MessageFlags.Ephemeral,
    });
  }
}

// Устаревшая модалка — оставляем для совместимости, перенаправляем на новый поток
export async function handleTableCreateModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Столы доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.INFO} Используйте \`/table create\` и выберите игру в меню — создастся приватная ветка.`,
    flags: MessageFlags.Ephemeral,
  });
}
