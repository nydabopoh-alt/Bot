/**
 * Кости PvP: 3 кости, по одному броску каждому.
 * Комбо (456, 123, трипс, пара+6) бьёт не-комбо. Оба комбо или оба не комбо — ничья.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  ChannelType,
  PermissionFlagsBits,
  type ButtonInteraction,
  type GuildMember,
  type TextChannel,
  type ThreadChannel,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { redis } from '../db/redis';
import { evaluateCeelo, isCeeloCombo, diceStr, type CeeloResult } from './dice';

const DICE_PVP_TTL = 1800; // 30 мин

function ceeloResultLabel(r: CeeloResult): string {
  if (r.type === 'instant_win' || r.type === 'instant_123') return `Комбо: ${r.label}`;
  if (r.type === 'instant_loss') return 'Проигрыш';
  if (r.type === 'point') return `Очко: ${r.point}`;
  return 'Переброс';
}

export interface DicePvPSession {
  serverId: string;
  threadId: string;
  channelId: string;
  player1Id: string;
  player2Id: string;
  stake: number;
  phase: 'accept' | 'p1_roll' | 'p2_roll' | 'done';
  roll1?: { dice: [number, number, number]; result: CeeloResult };
  roll2?: { dice: [number, number, number]; result: CeeloResult };
  player1RoleIds?: string[];
  player2RoleIds?: string[];
}

function dicePvPKey(serverId: string, threadId: string) {
  return `dicePvP:${serverId}:${threadId}`;
}

export async function getDicePvPSession(serverId: string, threadId: string): Promise<DicePvPSession | null> {
  const raw = await redis.get(dicePvPKey(serverId, threadId));
  if (!raw) return null;
  return JSON.parse(raw) as DicePvPSession;
}

async function setDicePvPSession(s: DicePvPSession): Promise<void> {
  await redis.set(dicePvPKey(s.serverId, s.threadId), JSON.stringify(s), 'EX', DICE_PVP_TTL);
}

async function deleteDicePvPSession(serverId: string, threadId: string): Promise<void> {
  await redis.del(dicePvPKey(serverId, threadId));
}

async function addAdminsToThread(guild: import('discord.js').Guild, thread: ThreadChannel): Promise<void> {
  try {
    const members = await guild.members.fetch();
    for (const [, member] of members) {
      if (member.user.bot) continue;
      if (guild.ownerId === member.id || member.permissions.has(PermissionFlagsBits.Administrator)) {
        await thread.members.add(member.id).catch(() => {});
      }
    }
  } catch (_) {}
}

/** Родительский текстовый канал (для создания ветки). Если уже в ветке — null, ветку не создаём. */
function getTextChannelForThreads(channel: import('discord.js').Channel | null): TextChannel | null {
  if (!channel) return null;
  if (channel.isThread?.()) return null; // игра пойдёт в текущей ветке
  if ('threads' in channel) return channel as TextChannel;
  return null;
}

/** Запуск вызова: если уже в ветке стола — игра в ней; иначе создаём новую ветку. Пост с кнопкой Принять. */
export async function startDicePvP(
  interaction: { guild: import('discord.js').Guild; channel: import('discord.js').Channel | null; user: { id: string }; reply: (o: any) => Promise<any> },
  opponentId: string,
  stake: number,
) {
  const serverId = interaction.guild.id;
  const challengerId = interaction.user.id;
  let thread: ThreadChannel;
  let channelId: string;
  const inExistingThread = interaction.channel?.isThread?.();

  if (inExistingThread) {
    // Игра в текущей ветке (стол) — лишних веток не создаём
    thread = interaction.channel as ThreadChannel;
    channelId = (thread.parent as TextChannel)?.id ?? thread.id;
    await thread.members.add(challengerId).catch(() => {});
    await thread.members.add(opponentId).catch(() => {});
  } else {
    const channel = getTextChannelForThreads(interaction.channel);
    if (!channel?.threads) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Вызовите кости в канале игр или в ветке стола.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    const newThread = await channel.threads
      .create({
        name: `🎲 Кости — ${interaction.user.username} vs оппонент`,
        type: ChannelType.PrivateThread,
        reason: 'Кости PvP',
      })
      .catch(() => null);
    if (!newThread) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Не удалось создать ветку. Включите приватные ветки в канале.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    thread = newThread;
    channelId = channel.id;
    await thread.members.add(challengerId).catch(() => {});
    await thread.members.add(opponentId).catch(() => {});
    await addAdminsToThread(interaction.guild, thread);
  }

  const session: DicePvPSession = {
    serverId,
    threadId: thread.id,
    channelId,
    player1Id: challengerId,
    player2Id: opponentId,
    stake,
    phase: 'accept',
  };
  await setDicePvPSession(session);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — вызов`)
    .setDescription(
      `<@${challengerId}> вызывает <@${opponentId}> на кости!\n\n` +
        `**Ставка:** ${stake} септимов с каждого.\n` +
        `**Правила:** 3 кости, по одному броску каждому. Комбо (456, 123, трипс, пара+6) бьёт не-комбо. Оба комбо или оба не комбо — ничья.\n\n` +
        `<@${opponentId}>, нажми **Принять** чтобы играть.`,
    )
    .setColor(UI_CONFIG.COLORS.DICE);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dice:accept').setLabel('Принять').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dice:decline').setLabel('Отказаться').setStyle(ButtonStyle.Danger),
  );

  await thread.send({ embeds: [embed], components: [row] });

  return interaction.reply({
    content: inExistingThread
      ? `${UI_CONFIG.EMOJI.SUCCESS} Вызов отправлен в этой ветке. Ожидайте ответа оппонента.`
      : `${UI_CONFIG.EMOJI.SUCCESS} Создана ветка <#${thread.id}>. Ожидайте ответа оппонента.`,
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleDicePvPAccept(interaction: ButtonInteraction) {
  if (!interaction.guild || !interaction.channel) return;
  const session = await getDicePvPSession(interaction.guild.id, interaction.channel.id);
  if (!session || session.phase !== 'accept') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нет активного вызова.`, flags: MessageFlags.Ephemeral });
  }
  if (interaction.user.id !== session.player2Id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только оппонент может принять.`, flags: MessageFlags.Ephemeral });
  }

  const config = await getServerConfig(session.serverId);
  const p1Profile = await getOrCreateProfile(session.serverId, session.player1Id);
  const p2Profile = await getOrCreateProfile(session.serverId, session.player2Id);
  if (p2Profile.balance < BigInt(session.stake)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Нужно ${session.stake}, баланс: ${p2Profile.balance}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await adjustBalance({ serverId: session.serverId, userId: session.player1Id, delta: -session.stake, reason: 'dice_pvp_bet' });
  await adjustBalance({ serverId: session.serverId, userId: session.player2Id, delta: -session.stake, reason: 'dice_pvp_bet' });

  const p1Member = await interaction.guild.members.fetch(session.player1Id).catch(() => null);
  const p2Member = await interaction.guild.members.fetch(session.player2Id).catch(() => null);
  session.player1RoleIds = p1Member?.roles.cache.map((r) => r.id) ?? [];
  session.player2RoleIds = p2Member?.roles.cache.map((r) => r.id) ?? [];
  session.phase = 'p1_roll';
  await setDicePvPSession(session);

  await interaction.update({ embeds: [], components: [] });
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Игра началась`)
    .setDescription(`Ставка **${session.stake}** с каждого. <@${session.player1Id}>, нажми **Кинуть** — один бросок 3 костей.`)
    .setColor(UI_CONFIG.COLORS.DICE);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dice:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
  );
  await interaction.channel.send({ embeds: [embed], components: [row] });
}

export async function handleDicePvPDecline(interaction: ButtonInteraction) {
  if (!interaction.guild || !interaction.channel) return;
  const session = await getDicePvPSession(interaction.guild.id, interaction.channel.id);
  if (!session || session.phase !== 'accept') return;
  if (interaction.user.id !== session.player2Id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только оппонент может отказаться.`, flags: MessageFlags.Ephemeral });
  }
  await deleteDicePvPSession(session.serverId, session.threadId);
  await interaction.update({
    embeds: [new EmbedBuilder().setTitle('Кости').setDescription(`<@${session.player2Id}> отказался. Вызов отменён.`).setColor(UI_CONFIG.COLORS.LOSS)],
    components: [],
  });
}

export async function handleDicePvPRoll(interaction: ButtonInteraction) {
  if (!interaction.guild || !interaction.channel) return;
  const session = await getDicePvPSession(interaction.guild.id, interaction.channel.id);
  if (!session) return;

  const isP1 = interaction.user.id === session.player1Id;
  const isP2 = interaction.user.id === session.player2Id;
  if (session.phase === 'p1_roll' && !isP1) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход соперника.`, flags: MessageFlags.Ephemeral });
  }
  if (session.phase === 'p2_roll' && !isP2) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход соперника.`, flags: MessageFlags.Ephemeral });
  }

  const dice: [number, number, number] = [
    crypto.randomInt(1, 7),
    crypto.randomInt(1, 7),
    crypto.randomInt(1, 7),
  ];
  const result = evaluateCeelo(dice[0], dice[1], dice[2]);
  const diceStrFormatted = `${diceStr(dice[0])} ${diceStr(dice[1])} ${diceStr(dice[2])}`;

  if (session.phase === 'p1_roll') {
    session.roll1 = { dice, result };
    session.phase = 'p2_roll';
    await setDicePvPSession(session);
    await interaction.update({ embeds: [], components: [] });
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} <@${session.player1Id}> — бросок`)
      .setDescription(`**${diceStrFormatted}** → ${ceeloResultLabel(result)}\n\n<@${session.player2Id}>, нажми **Кинуть** для своего броска.`)
      .setColor(UI_CONFIG.COLORS.DICE);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
    );
    return interaction.channel.send({ embeds: [embed], components: [row] });
  }

  session.roll2 = { dice, result };
  session.phase = 'done';
  await setDicePvPSession(session);
  await interaction.update({ embeds: [], components: [] });
  return finishDicePvP(interaction, session);
}

async function finishDicePvP(interaction: ButtonInteraction, session: DicePvPSession) {
  const r1 = session.roll1!.result;
  const r2 = session.roll2!.result;
  const combo1 = isCeeloCombo(r1);
  const combo2 = isCeeloCombo(r2);
  const config = await getServerConfig(session.serverId);
  const pot = session.stake * 2;

  let winnerId: string | null = null;
  if (combo1 && !combo2) winnerId = session.player1Id;
  else if (combo2 && !combo1) winnerId = session.player2Id;
  // оба комбо или оба не комбо — ничья

  const line1 = `<@${session.player1Id}>: **${session.roll1!.dice.map(diceStr).join(' ')}** → ${ceeloResultLabel(r1)}`;
  const line2 = `<@${session.player2Id}>: **${session.roll2!.dice.map(diceStr).join(' ')}** → ${ceeloResultLabel(r2)}`;

  if (winnerId) {
    const roleIds = winnerId === session.player1Id ? session.player1RoleIds ?? [] : session.player2RoleIds ?? [];
    const vipMul = await getVipMultiplier(session.serverId, roleIds);
    const payout = Math.floor(calculatePayout(pot, vipMul, config?.casinoCommission ?? 0));
    const { creditAdminCommissionFromPayout } = await import('../services/economy');
    await creditAdminCommissionFromPayout(session.serverId, pot, config?.casinoCommission ?? 0);
    await adjustBalance({ serverId: session.serverId, userId: winnerId, delta: payout, reason: 'dice_pvp_win' });
    const loserId = winnerId === session.player1Id ? session.player2Id : session.player1Id;
    await logBet({ serverId: session.serverId, userId: winnerId, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: payout, outcome: 'win', seed: '' });
    await logBet({ serverId: session.serverId, userId: loserId, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: 0, outcome: 'lose', seed: '' });

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — результат`)
      .setDescription(`${line1}\n${line2}\n\n${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> — **${payout}** септимов!`)
      .setColor(UI_CONFIG.COLORS.WIN);
    await interaction.channel!.send({ embeds: [embed] });
  } else {
    await adjustBalance({ serverId: session.serverId, userId: session.player1Id, delta: session.stake, reason: 'dice_pvp_draw' });
    await adjustBalance({ serverId: session.serverId, userId: session.player2Id, delta: session.stake, reason: 'dice_pvp_draw' });
    await logBet({ serverId: session.serverId, userId: session.player1Id, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: session.stake, outcome: 'draw', seed: '' });
    await logBet({ serverId: session.serverId, userId: session.player2Id, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: session.stake, outcome: 'draw', seed: '' });

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — ничья`)
      .setDescription(`${line1}\n${line2}\n\nОба комбо или оба не комбо — ставки возвращены.`)
      .setColor(UI_CONFIG.COLORS.DRAW);
    await interaction.channel!.send({ embeds: [embed] });
  }

  await deleteDicePvPSession(session.serverId, session.threadId);
}

export async function handleDicePvPCategory(interaction: import('discord.js').StringSelectMenuInteraction) {
  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.INFO} Теперь кости — один бросок 3 костей каждому (комбо бьёт не-комбо, иначе ничья).`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

/** Запуск Костей из лобби: 2 игрока — 1v1; >2 — все по кругу, каждый кидает, лучший выигрывает. */
export async function startDiceFromLobby(
  thread: ThreadChannel,
  lobby: { serverId: string; memberIds: string[] },
  minBet: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const memberIds = [...lobby.memberIds];

  const profiles = await Promise.all(memberIds.map((id) => getOrCreateProfile(serverId, id)));
  const insufficient = memberIds.filter((_, i) => profiles[i].balance < BigInt(minBet));
  if (insufficient.length > 0) {
    return { ok: false, error: `Недостаточно средств у: ${insufficient.map((id) => `<@${id}>`).join(', ')}. Нужно ${minBet}.` };
  }

  if (memberIds.length === 2) {
    const [p1, p2] = memberIds;
    await adjustBalance({ serverId, userId: p1, delta: -minBet, reason: 'dice_pvp_bet' });
    await adjustBalance({ serverId, userId: p2, delta: -minBet, reason: 'dice_pvp_bet' });
    const p1Member = await thread.guild?.members.fetch(p1).catch(() => null);
    const p2Member = await thread.guild?.members.fetch(p2).catch(() => null);
    const session: DicePvPSession = {
      serverId,
      threadId: thread.id,
      channelId: (thread.parent as TextChannel)?.id ?? thread.id,
      player1Id: p1,
      player2Id: p2,
      stake: minBet,
      phase: 'p1_roll',
      player1RoleIds: p1Member?.roles.cache.map((r) => r.id) ?? [],
      player2RoleIds: p2Member?.roles.cache.map((r) => r.id) ?? [],
    };
    await setDicePvPSession(session);
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Игра началась`)
      .setDescription(`Ставка **${minBet}** с каждого. <@${p1}>, нажми **Кинуть** — один бросок 3 костей.`)
      .setColor(UI_CONFIG.COLORS.DICE);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('dice:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
    );
    await thread.send({ embeds: [embed], components: [row] });
    return { ok: true };
  }

  return startDiceMultiFromLobby(thread, lobby, minBet);
}

/** Мультиплеер кости: все кидают по кругу, лучший выигрывает. */
async function startDiceMultiFromLobby(
  thread: ThreadChannel,
  lobby: { serverId: string; memberIds: string[] },
  minBet: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const key = `diceMulti:${serverId}:${thread.id}`;
  const session = {
    playerIds: [...lobby.memberIds],
    currentIndex: 0,
    rolls: [] as { playerId: string; dice: [number, number, number]; result: ReturnType<typeof evaluateCeelo> }[],
    stake: minBet,
    phase: 'rolling' as const,
  };
  await redis.set(key, JSON.stringify(session), 'EX', DICE_PVP_TTL);

  for (const id of lobby.memberIds) {
    await adjustBalance({ serverId, userId: id, delta: -minBet, reason: 'dice_multi_bet' });
  }

  const currentId = session.playerIds[session.currentIndex];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — по кругу`)
    .setDescription(
      `Ставка **${minBet}** с каждого. Все кидают по очереди.\n\n` +
        `Ход: <@${currentId}> — нажми **Кинуть**.`,
    )
    .setColor(UI_CONFIG.COLORS.DICE);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('diceMulti:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
  );
  await thread.send({ embeds: [embed], components: [row] });
  return { ok: true };
}

export interface DiceMultiSession {
  playerIds: string[];
  currentIndex: number;
  rolls: { playerId: string; dice: [number, number, number]; result: CeeloResult }[];
  stake: number;
  phase: 'rolling' | 'done';
}

export async function handleDiceMultiRoll(interaction: ButtonInteraction) {
  if (!interaction.guild || !interaction.channel) return;
  const key = `diceMulti:${interaction.guild.id}:${interaction.channel.id}`;
  const raw = await redis.get(key);
  if (!raw) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия истекла.`, flags: MessageFlags.Ephemeral });
  }
  const session: DiceMultiSession = JSON.parse(raw);
  if (session.phase !== 'rolling') return;

  const currentId = session.playerIds[session.currentIndex];
  if (interaction.user.id !== currentId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход <@${currentId}>.`, flags: MessageFlags.Ephemeral });
  }

  const dice: [number, number, number] = [
    crypto.randomInt(1, 7),
    crypto.randomInt(1, 7),
    crypto.randomInt(1, 7),
  ];
  const result = evaluateCeelo(dice[0], dice[1], dice[2]);
  session.rolls.push({ playerId: currentId, dice, result });
  session.currentIndex++;

  if (session.currentIndex >= session.playerIds.length) {
    session.phase = 'done';
    await redis.del(key);

    const config = await getServerConfig(interaction.guild.id);
    const pot = session.stake * session.playerIds.length;
    const sorted = [...session.rolls].sort((a, b) => {
      const loss1 = a.result.type === 'instant_loss';
      const loss2 = b.result.type === 'instant_loss';
      if (loss1 && !loss2) return 1;
      if (!loss1 && loss2) return -1;
      if (loss1 && loss2) return 0;
      const c1 = isCeeloCombo(a.result);
      const c2 = isCeeloCombo(b.result);
      if (c1 && !c2) return -1;
      if (!c1 && c2) return 1;
      if (c1 && c2) {
        const m1 = (a.result as { multiplier?: number }).multiplier ?? 1;
        const m2 = (b.result as { multiplier?: number }).multiplier ?? 1;
        return m2 - m1;
      }
      const p1 = a.result.type === 'point' ? a.result.point : -1;
      const p2 = b.result.type === 'point' ? b.result.point : -1;
      return p2 - p1;
    });
    const winnerId = sorted[0].playerId;
    const winnerMember = interaction.guild.members.cache.get(winnerId);
    const vipMul = await getVipMultiplier(interaction.guild.id, winnerMember?.roles.cache.map((r) => r.id) ?? []);
    const payout = Math.floor(calculatePayout(pot, vipMul, config?.casinoCommission ?? 0));
    const { creditAdminCommissionFromPayout } = await import('../services/economy');
    await creditAdminCommissionFromPayout(interaction.guild.id, pot, config?.casinoCommission ?? 0);
    await adjustBalance({ serverId: interaction.guild.id, userId: winnerId, delta: payout, reason: 'dice_multi_win' });
    await logBet({ serverId: interaction.guild.id, userId: winnerId, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: payout, outcome: 'win', seed: '' });
    for (const r of session.rolls) {
      if (r.playerId !== winnerId) {
        await logBet({ serverId: interaction.guild.id, userId: r.playerId, gameType: 'dice_pvp', betAmount: session.stake, payoutAmount: 0, outcome: 'lose', seed: '' });
      }
    }

    const lines = session.rolls.map((r) => {
      const ds = `${diceStr(r.dice[0])} ${diceStr(r.dice[1])} ${diceStr(r.dice[2])}`;
      return `<@${r.playerId}>: **${ds}** → ${ceeloResultLabel(r.result)}`;
    });
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DICE} Кости — результат`)
      .setDescription(lines.join('\n') + `\n\n${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> — **${payout}** септимов!`)
      .setColor(UI_CONFIG.COLORS.WIN);
    await interaction.update({ embeds: [], components: [] });
    const ch = interaction.channel as import('discord.js').TextChannel;
    return ch.send({ embeds: [embed] });
  }

  await redis.set(key, JSON.stringify(session), 'EX', DICE_PVP_TTL);
  const nextId = session.playerIds[session.currentIndex];
  const lastRoll = session.rolls[session.rolls.length - 1];
  const ds = `${diceStr(lastRoll.dice[0])} ${diceStr(lastRoll.dice[1])} ${diceStr(lastRoll.dice[2])}`;

  await interaction.update({ embeds: [], components: [] });
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DICE} <@${currentId}> — бросок`)
    .setDescription(`**${ds}** → ${ceeloResultLabel(lastRoll.result)}\n\nХод: <@${nextId}> — нажми **Кинуть**.`)
    .setColor(UI_CONFIG.COLORS.DICE);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('diceMulti:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
  );
  await (interaction.channel as import('discord.js').TextChannel).send({ embeds: [embed], components: [row] });
}
