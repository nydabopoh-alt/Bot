/**
 * Локализация бота. Все строки вынесены сюда.
 * Использование: import { t } from '../locale'; t.profile.title
 */
import { ru } from './ru';

export const t = ru;
export type { Locale } from './ru';
