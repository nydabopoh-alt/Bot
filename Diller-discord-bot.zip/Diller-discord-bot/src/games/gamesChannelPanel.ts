/**
 * Панель игр в канале: кнопки Кости / Покер / Дуэль / Интервенция.
 * По нажатию — модалка «с кем играть» (для костей и дуэли) или сразу старт.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  type Guild,
  type User,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig, isChannelAllowedForGames } from '../config/serverConfigService';
import type { GuildMember } from 'discord.js';
import type { StringSelectMenuInteraction } from 'discord.js';
import { buildBlindStartEmbed } from './blind';
import { buildDuelChallengeEmbed } from './duel';
import { buildInterventionChallengeEmbed } from './intervention';
import { startDicePvP } from './dicePvP';
import { redis } from '../db/redis';
import { getOrCreateProfile } from '../services/economy';

const DICE_CHALLENGE_TTL = 120;

/** Из текста (упоминание <@id> или ID) получить пользователя на сервере */
export async function resolveOpponentFromText(guild: Guild, text: string): Promise<User | null> {
  const trimmed = (text || '').trim();
  const mentionMatch = trimmed.match(/<@!?(\d{17,19})>/);
  const id = mentionMatch ? mentionMatch[1] : (trimmed.match(/\d{17,19}/)?.[0] ?? null);
  if (!id) return null;
  const member = await guild.members.fetch(id).catch(() => null);
  return member?.user ?? null;
}

/** Проверка: канал игр, роль игрока, игра включена. Возвращает config или null. */
async function ensureGamesChannelAccess(
  interaction: ButtonInteraction | ModalSubmitInteraction,
  gameKey: 'dice' | 'blind' | 'duel' | 'intervention',
): Promise<{ config: Awaited<ReturnType<typeof getServerConfig>> } | null> {
  if (!interaction.guild) {
    await interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral }).catch(() => {});
    return null;
  }
  const config = await getServerConfig(interaction.guild.id);
  if (!config) {
    await interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Бот не настроен. Используйте \`/settings\`.`, flags: MessageFlags.Ephemeral }).catch(() => {});
    return null;
  }
  const ch = interaction.channel;
  const effectiveChannelId = (ch?.isThread?.() ? (ch as { parentId?: string }).parentId : null) ?? interaction.channelId;
  if (!isChannelAllowedForGames(config, effectiveChannelId ?? '')) {
    const mode = (config as { channelAccessMode?: string }).channelAccessMode ?? 'none';
    const hint = mode === 'whitelist'
      ? 'Игровые кнопки доступны только в разрешённых каналах (см. /settings → Доступ).'
      : `Игровые кнопки работают только в ветках канала <#${config.gamesChannelId}>.`;
    await interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} ${hint}`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
    return null;
  }
  const inGamesThread = ch?.isThread?.() && (ch as { parentId: string }).parentId === config.gamesChannelId;
  const requireThread = ((config as { channelAccessMode?: string }).channelAccessMode ?? 'none') !== 'whitelist' && config.gamesChannelId;
  if (requireThread && !inGamesThread) {
    await interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Игровые кнопки работают только в ветках канала <#${config.gamesChannelId}>.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
    return null;
  }
  const member = interaction.member as GuildMember | null;
  const playerRole = config.roles?.find((r: { type: string }) => r.type === 'PLAYER');
  if (playerRole && member && !member.roles.cache.has(playerRole.roleId)) {
    await interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Для игры нужна роль <@&${playerRole.roleId}>.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
    return null;
  }
  const enabled = config.enabledGames?.find((g: { gameKey: string; enabled: boolean }) => g.gameKey === gameKey && g.enabled);
  if (!enabled) {
    await interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Эта игра отключена в настройках.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
    return null;
  }
  return { config };
}

export async function handleGamesChannelButton(interaction: ButtonInteraction) {
  const parts = interaction.customId.split(':');
  const action = parts[1];

  if (action === 'leaveTable') {
    const threadId = parts[2];
    if (!threadId || !interaction.guild) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Не найдена ветка.`, flags: MessageFlags.Ephemeral });
    await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
    const { getLobby, deleteLobby, saveLobby, updateActiveLobbiesEmbed, updateThreadName } = await import('./lobbyTables');
    const lobby = await getLobby(interaction.guild.id, threadId);
    if (!lobby) return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Стол не найден.` }).catch(() => {});
    const idx = lobby.memberIds.indexOf(interaction.user.id);
    if (idx === -1) return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Вас нет за этим столом.` }).catch(() => {});
    lobby.memberIds.splice(idx, 1);
    const thread = await interaction.guild.channels.fetch(threadId).catch(() => null) as import('discord.js').ThreadChannel | null;
    if (thread) {
      await thread.members.remove(interaction.user.id).catch(() => {});
      if (lobby.memberIds.length === 0) {
        await deleteLobby(lobby.serverId, lobby.threadId);
        await thread.setArchived(true).catch(() => {});
        await interaction.editReply({ content: `${UI_CONFIG.EMOJI.SUCCESS} Вы покинули стол. Стол удалён (пустой).` });
        // Сразу убрать закрытый стол из виджета «Активные столы»
        await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
      } else {
        await saveLobby(lobby);
        await interaction.editReply({ content: `${UI_CONFIG.EMOJI.SUCCESS} Вы покинули стол.` });
        updateThreadName(thread, lobby).catch(() => {});
        await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
      }
    } else {
      await deleteLobby(lobby.serverId, lobby.threadId);
      await interaction.editReply({ content: `${UI_CONFIG.EMOJI.SUCCESS} Вы покинули стол.` });
      await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
    }
    return;
  }

  if (action === 'startTable') {
    const threadId = parts[2];
    if (!threadId || !interaction.guild) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Не найдена ветка.`, flags: MessageFlags.Ephemeral });
    const { getLobby, saveLobby, updateActiveLobbiesEmbed, updateThreadName, updateLobbyEmbedWhenStarted } = await import('./lobbyTables');
    const lobby = await getLobby(interaction.guild.id, threadId);
    if (!lobby) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Стол не найден.`, flags: MessageFlags.Ephemeral });
    if (lobby.hostId !== interaction.user.id) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только создатель ветки может запустить игру.`, flags: MessageFlags.Ephemeral });
    }
    if (lobby.phase === 'playing') {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.INFO} Игра уже идёт.`, flags: MessageFlags.Ephemeral });
    }
    if (lobby.memberIds.length < 2) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нужно минимум 2 игрока для старта.`, flags: MessageFlags.Ephemeral });
    }

    if ((lobby.gameType === 'blind' || lobby.gameType === 'dicepoker') && lobby.stake != null) {
      const thread = await interaction.guild.channels.fetch(threadId).catch(() => null) as import('discord.js').ThreadChannel | null;
      if (!thread) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ветка не найдена.`, flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
      const { startGameFromLobby } = await import('./lobbyGameStarter');
      const result = await startGameFromLobby(thread, lobby, lobby.stake);
      if (!result.ok) {
        return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} ${result.error}` }).catch(() => {});
      }
      lobby.phase = 'playing';
      await saveLobby(lobby);
      await interaction.editReply({
        content: `${UI_CONFIG.EMOJI.SUCCESS} Игра началась! Банк **${lobby.stake}** септимов — ставки из фишек. Всё в этой ветке.`,
      }).catch(() => {});
      updateThreadName(thread, lobby).catch(() => {});
      await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
      return;
    }

    const { ensureServerConfig } = await import('../config/serverConfigService');
    const config = await ensureServerConfig(interaction.guild.id);
    const minBet = config?.minBet ?? 10;
    const maxBet = config?.maxBet ?? 10000;

    const modal = new ModalBuilder()
      .setCustomId(`gamesChannel:startTableStake:${threadId}`)
      .setTitle('Банк стола');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('stake')
          .setLabel(`Взнос с каждого (${minBet}–${maxBet} септимов)`)
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('5000')
          .setRequired(true),
      ),
    );
    return interaction.showModal(modal);
  }

  const game = action as 'dice' | 'blind' | 'duel' | 'intervention';
  const access = await ensureGamesChannelAccess(interaction, game);
  if (!access) return;

  if (game === 'dice') {
    const modal = new ModalBuilder()
      .setCustomId('gamesChannel:diceModal')
      .setTitle('Кости — с кем играть?');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('opponent')
          .setLabel('Игрок (@упоминание или ID)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('@ник или ID пользователя')
          .setRequired(true),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('stake')
          .setLabel('Ставка с каждого (необязательно)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Оставьте пустым — введёте в следующей форме')
          .setRequired(false),
      ),
    );
    return interaction.showModal(modal);
  }

  if (game === 'duel') {
    const modal = new ModalBuilder()
      .setCustomId('gamesChannel:duelModal')
      .setTitle('Дуэль — с кем играть?');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('opponent')
          .setLabel('Игрок (@упоминание или ID)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('@ник или ID пользователя')
          .setRequired(true),
      ),
    );
    return interaction.showModal(modal);
  }

  if (game === 'blind') {
    const { embeds, components } = buildBlindStartEmbed();
    return interaction.reply({ embeds, components });
  }

  if (game === 'intervention') {
    const modal = new ModalBuilder()
      .setCustomId('gamesChannel:interventionModal')
      .setTitle('Интервенция 21.5 — с кем играть?');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('opponent')
          .setLabel('Игрок (@упоминание или ID)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('@ник или ID пользователя')
          .setRequired(true),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('stake')
          .setLabel('Ставка с каждого (необязательно)')
          .setStyle(TextInputStyle.Short)
          .setRequired(false),
      ),
    );
    return interaction.showModal(modal);
  }

  return interaction.reply({ content: `${UI_CONFIG.EMOJI.WARNING} Неизвестная игра.`, flags: MessageFlags.Ephemeral }).catch(() => {});
}

export async function handleGamesChannelDiceModal(interaction: ModalSubmitInteraction) {
  const access = await ensureGamesChannelAccess(interaction, 'dice');
  if (!access) return;

  const opponentRaw = interaction.fields.getTextInputValue('opponent').trim();
  const stakeRaw = interaction.fields.getTextInputValue('stake')?.trim() ?? '';

  const opponent = await resolveOpponentFromText(interaction.guild!, opponentRaw);
  if (!opponent) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не найден игрок. Укажите @упоминание или ID.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (opponent.id === interaction.user.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нельзя играть с самим собой.`, flags: MessageFlags.Ephemeral });
  }
  if (opponent.bot) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Оппонент должен быть человеком.`, flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(interaction.guild!.id);
  const myProfile = await getOrCreateProfile(interaction.guild!.id, interaction.user.id);

  const stake = stakeRaw ? Number.parseInt(stakeRaw, 10) : null;
  if (stakeRaw && (Number.isNaN(stake!) || stake! <= 0)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная ставка.`, flags: MessageFlags.Ephemeral });
  }
  if (stake != null && stake > 0) {
    if (stake < config.minBet || stake > config.maxBet) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Ставка от ${config.minBet} до ${config.maxBet}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (myProfile.balance < BigInt(stake)) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${myProfile.balance}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return startDicePvP(interaction, opponent.id, stake);
  }

  await redis.set(
    `diceChallenge:${interaction.guild!.id}:${interaction.user.id}`,
    JSON.stringify({ opponentId: opponent.id }),
    'EX',
    DICE_CHALLENGE_TTL,
  );
  const modal = new ModalBuilder()
    .setCustomId('dice:stakeModal')
    .setTitle('Кости PvP — ставка');
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('stake')
        .setLabel('Ставка с каждого (септимы)')
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleGamesChannelDuelModal(interaction: ModalSubmitInteraction) {
  const access = await ensureGamesChannelAccess(interaction, 'duel');
  if (!access) return;

  const opponentRaw = interaction.fields.getTextInputValue('opponent').trim();
  const opponent = await resolveOpponentFromText(interaction.guild!, opponentRaw);
  if (!opponent) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не найден игрок. Укажите @упоминание или ID.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (opponent.id === interaction.user.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нельзя играть с самим собой.`, flags: MessageFlags.Ephemeral });
  }
  if (opponent.bot) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Оппонент должен быть человеком.`, flags: MessageFlags.Ephemeral });
  }

  const { embeds, components } = buildDuelChallengeEmbed(interaction.user.id, opponent.id);
  return interaction.reply({ embeds, components });
}

export async function handleGamesChannelInterventionModal(interaction: ModalSubmitInteraction) {
  const access = await ensureGamesChannelAccess(interaction, 'intervention');
  if (!access) return;

  const opponentRaw = interaction.fields.getTextInputValue('opponent').trim();
  const opponent = await resolveOpponentFromText(interaction.guild!, opponentRaw);
  if (!opponent) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не найден игрок. Укажите @упоминание или ID.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (opponent.id === interaction.user.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нельзя играть с самим собой.`, flags: MessageFlags.Ephemeral });
  }
  if (opponent.bot) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Оппонент должен быть человеком.`, flags: MessageFlags.Ephemeral });
  }

  const stakeRaw = interaction.fields.getTextInputValue('stake')?.trim() ?? '';
  const stakeOpt = stakeRaw ? Number.parseInt(stakeRaw, 10) : undefined;
  const { embeds, components } = buildInterventionChallengeEmbed(interaction.user.id, opponent.id, stakeOpt);
  return interaction.reply({ embeds, components });
}

const TABLE_GAME_TYPES = ['dice', 'dicepoker', 'blind', 'duel', 'intervention'] as const;
type TableGameType = (typeof TABLE_GAME_TYPES)[number];

async function checkCreateTableAccess(interaction: ModalSubmitInteraction | StringSelectMenuInteraction): Promise<string | null> {
  if (!interaction.guild) return `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`;
  const member = interaction.member as GuildMember | null;
  const isAdmin =
    (member?.permissions?.has(PermissionFlagsBits.Administrator) ?? false) ||
    interaction.guild.ownerId === interaction.user.id;
  if (!isAdmin) return `${UI_CONFIG.EMOJI.ERROR} Создать стол могут только админы.`;
  const config = await getServerConfig(interaction.guild.id);
  if (config) {
    const ch = interaction.channel;
    const effectiveChannelId = (ch?.isThread?.() ? (ch as { parentId?: string }).parentId : null) ?? interaction.channelId;
    if (!isChannelAllowedForGames(config, effectiveChannelId ?? '')) {
      const mode = (config as { channelAccessMode?: string }).channelAccessMode ?? 'none';
      return mode === 'whitelist'
        ? `${UI_CONFIG.EMOJI.ERROR} Создать стол можно только в разрешённых каналах (см. /settings → Доступ).`
        : `${UI_CONFIG.EMOJI.ERROR} Создать стол можно только в канале игр <#${config.gamesChannelId}> или его ветках.`;
    }
  }
  return null;
}

export async function handleGamesChannelCreateTableGameSelect(interaction: StringSelectMenuInteraction) {
  await interaction.deferUpdate().catch(() => {});

  const err = await checkCreateTableAccess(interaction);
  if (err) return interaction.editReply({ content: err, components: [] }).catch(() => {});

  const gameType = interaction.values[0] as TableGameType;
  if (!TABLE_GAME_TYPES.includes(gameType)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Неизвестная игра.`, components: [] }).catch(() => {});
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId(`gamesChannel:createTableSeats:${gameType}`)
    .setPlaceholder('Мест за столом (2–6)')
    .addOptions(
      { label: '2 места', value: '2' },
      { label: '3 места', value: '3' },
      { label: '4 места', value: '4' },
      { label: '5 мест', value: '5' },
      { label: '6 мест', value: '6' },
    );
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
  return interaction.editReply({
    content: '**Создать стол** — выберите количество мест:',
    components: [row],
  }).catch(() => {});
}

export async function handleGamesChannelCreateTableSeatsSelect(interaction: StringSelectMenuInteraction) {
  await interaction.deferUpdate().catch(() => {});

  const err = await checkCreateTableAccess(interaction);
  if (err) return interaction.editReply({ content: err, components: [] }).catch(() => {});

  const match = interaction.customId.match(/gamesChannel:createTableSeats:(dicepoker|dice|blind|duel|intervention)/);
  const gameType = (match?.[1] ?? 'dice') as TableGameType;
  const seats = Number.parseInt(interaction.values[0] ?? '4', 10);
  if (Number.isNaN(seats) || seats < 2 || seats > 6) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Мест за столом: от 2 до 6.`, components: [] }).catch(() => {});
  }

  if (gameType === 'blind' || gameType === 'dicepoker') {
    const config = await getServerConfig(interaction.guild!.id);
    const minBet = config?.minBet ?? 10;
    const maxBet = config?.maxBet ?? 10000;
    const defaults = [500, 1000, 2000, 5000, 10000, 20000];
    const stakes = defaults.filter((s) => s >= minBet && s <= maxBet);
    if (stakes.length === 0) stakes.push(minBet, Math.min(maxBet, minBet * 2));
    const label = gameType === 'blind' ? 'Покер' : 'Покер на кубиках';
    const stakePlaceholder = gameType === 'dicepoker' ? 'Банк стола (макс. ставка = банк)' : 'Банк стола (лимит ставки ×2)';
    const stakeOptions = gameType === 'dicepoker'
      ? stakes.slice(0, 25).map((s) => ({ label: `${s} септимов (макс. ${s})`, value: String(s) }))
      : stakes.slice(0, 25).map((s) => ({ label: `${s} септимов (лимит ${s * 2})`, value: String(s) }));
    const stakeHint = gameType === 'dicepoker' ? 'Макс. ставка = банк стола.' : 'Лимит ставки в игре: ×2 от банка.';
    const select = new StringSelectMenuBuilder()
      .setCustomId(`gamesChannel:createTableStakeSelect:${gameType}:${seats}`)
      .setPlaceholder(stakePlaceholder)
      .addOptions(stakeOptions);
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
    return interaction.editReply({
      content: `**${label}** — выберите банк стола. ${stakeHint}`,
      components: [row],
    }).catch(() => {});
  }
  const ch = interaction.channel as import('discord.js').TextChannel | import('discord.js').ThreadChannel;
  const channel = (ch.isThread?.() ? (ch as { parent?: import('discord.js').TextChannel }).parent : ch) as import('discord.js').TextChannel;
  if (!channel?.threads) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось определить канал для создания стола.`,
      components: [],
    }).catch(() => {});
  }
  const { createTable, updateActiveLobbiesEmbed } = await import('./lobbyTables');
  const result = await createTable(channel, interaction.user.id, interaction.user.username, gameType, seats);
  if (!result) {
    return interaction.followUp({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось создать ветку. Включите приватные ветки в канале.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  await interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Стол создан: <#${result.thread.id}>. Заходите по списку «Активные столы» ниже.`,
    flags: MessageFlags.Ephemeral,
  });
  await updateActiveLobbiesEmbed(interaction.client, interaction.guild!.id).catch(() => {});
}

export async function handleGamesChannelCreateTableStakeSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});

  const match = interaction.customId.match(/gamesChannel:createTableStakeSelect:(blind|dicepoker):(\d+)/);
  const gameType = (match?.[1] ?? 'blind') as 'blind' | 'dicepoker';
  const seats = match ? Number.parseInt(match[2], 10) : 4;
  if (Number.isNaN(seats) || seats < 2 || seats > 6) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректное число мест.` }).catch(() => {});
  }
  const stake = Number.parseInt(interaction.values[0] ?? '0', 10);
  if (Number.isNaN(stake) || stake <= 0) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма.` }).catch(() => {});
  }
  const config = await getServerConfig(interaction.guild.id);
  const minBet = config?.minBet ?? 10;
  const maxBet = config?.maxBet ?? 10000;
  if (stake < minBet || stake > maxBet) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Взнос: от ${minBet} до ${maxBet} септимов.`,
    }).catch(() => {});
  }

  const ch = interaction.channel as import('discord.js').TextChannel | import('discord.js').ThreadChannel;
  const channel = (ch.isThread?.() ? (ch as { parent?: import('discord.js').TextChannel }).parent : ch) as import('discord.js').TextChannel;
  if (!channel?.threads) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось определить канал для создания стола.`,
    }).catch(() => {});
  }
  const { createTable, updateActiveLobbiesEmbed } = await import('./lobbyTables');
  const result = await createTable(channel, interaction.user.id, interaction.user.username, gameType, seats, stake);
  if (!result) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось создать ветку. Включите приватные ветки в канале.`,
    }).catch(() => {});
  }
  const stakeMsg = gameType === 'dicepoker'
    ? `Банк: **${stake}** септимов (макс. ставка ${stake}).`
    : `Банк: **${stake}** септимов (лимит ×2 = ${stake * 2}).`;
  await interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Стол создан: <#${result.thread.id}>. ${stakeMsg} Заходите по списку «Активные столы» ниже.`,
  }).catch(() => {});
  await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
}

export async function handleGamesChannelJoinTable(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const threadId = interaction.values[0];
  if (!threadId) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Выберите стол.`, flags: MessageFlags.Ephemeral });
  await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
  const { getLobby, saveLobby, updateActiveLobbiesEmbed, updateThreadName } = await import('./lobbyTables');
  const lobby = await getLobby(interaction.guild.id, threadId);
  if (!lobby) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Стол не найден или уже закрыт.` }).catch(() => {});
  }
  if (lobby.memberIds.includes(interaction.user.id)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Вы уже за этим столом.` }).catch(() => {});
  }
  if (lobby.memberIds.length >= lobby.seats) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} За столом нет свободных мест.` }).catch(() => {});
  }
  const thread = await interaction.guild.channels.fetch(threadId).catch(() => null) as import('discord.js').ThreadChannel | null;
  if (!thread) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Ветка не найдена.` }).catch(() => {});
  }
  lobby.memberIds.push(interaction.user.id);
  await saveLobby(lobby);
  await thread.members.add(interaction.user.id).catch(() => {});
  await interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы вошли в стол <#${threadId}>.`,
  }).catch(() => {});
  updateThreadName(thread, lobby).catch(() => {});
  await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
}

export async function handleGamesChannelCreateTableStakeModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const match = interaction.customId.match(/gamesChannel:createTableStakeModal:blind:(\d+)/);
  const seats = match ? Number.parseInt(match[1], 10) : 4;
  if (Number.isNaN(seats) || seats < 2 || seats > 6) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректное число мест.`, flags: MessageFlags.Ephemeral });
  }

  const stakeRaw = interaction.fields.getTextInputValue('stake');
  const stake = Number.parseInt(stakeRaw, 10);
  if (Number.isNaN(stake) || stake <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма.`, flags: MessageFlags.Ephemeral });
  }

  const config = await getServerConfig(interaction.guild.id);
  const minBet = config?.minBet ?? 10;
  const maxBet = config?.maxBet ?? 10000;
  if (stake < minBet || stake > maxBet) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Взнос: от ${minBet} до ${maxBet} септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});

  const ch = interaction.channel as import('discord.js').TextChannel | import('discord.js').ThreadChannel;
  const channel = (ch.isThread?.() ? (ch as { parent?: import('discord.js').TextChannel }).parent : ch) as import('discord.js').TextChannel;
  if (!channel?.threads) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось определить канал для создания стола.`,
    }).catch(() => {});
  }
  const { createTable, updateActiveLobbiesEmbed } = await import('./lobbyTables');
  const result = await createTable(channel, interaction.user.id, interaction.user.username, 'blind', seats, stake);
  if (!result) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось создать ветку. Включите приватные ветки в канале.`,
    }).catch(() => {});
  }
  await interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Стол создан: <#${result.thread.id}>. Банк: **${stake}** септимов (лимит ×2 = ${stake * 2}). Заходите по списку «Активные столы» ниже.`,
  }).catch(() => {});
  await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
}

export async function handleGamesChannelStartTableStakeModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const match = interaction.customId.match(/gamesChannel:startTableStake:(.+)/);
  const threadId = match?.[1];
  if (!threadId) return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });

  const stakeRaw = interaction.fields.getTextInputValue('stake');
  const stake = Number.parseInt(stakeRaw, 10);
  if (Number.isNaN(stake) || stake <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма.`, flags: MessageFlags.Ephemeral });
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});

  const { getLobby, saveLobby, updateActiveLobbiesEmbed, updateThreadName, updateLobbyEmbedWhenStarted } = await import('./lobbyTables');
  const lobby = await getLobby(interaction.guild.id, threadId);
  if (!lobby) return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Стол не найден.` }).catch(() => {});
  if (lobby.hostId !== interaction.user.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Только создатель ветки может запустить игру.` }).catch(() => {});
  }
  if (lobby.phase === 'playing') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Игра уже идёт.` }).catch(() => {});
  }

  const thread = await interaction.guild.channels.fetch(threadId).catch(() => null) as import('discord.js').ThreadChannel | null;
  if (!thread) return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Ветка не найдена.` }).catch(() => {});

  const { startGameFromLobby } = await import('./lobbyGameStarter');
  const result = await startGameFromLobby(thread, lobby, stake);

  if (!result.ok) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} ${result.error}` }).catch(() => {});
  }

  lobby.phase = 'playing';
  await saveLobby(lobby);
  await interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Игра началась! Стол на **${stake}** септимов — ставки идут из фишек, не из кошелька. Всё в этой ветке.`,
  }).catch(() => {});
  updateThreadName(thread, lobby).catch(() => {});
  updateLobbyEmbedWhenStarted(thread, lobby).catch(() => {});
  await updateActiveLobbiesEmbed(interaction.client, interaction.guild.id).catch(() => {});
}
