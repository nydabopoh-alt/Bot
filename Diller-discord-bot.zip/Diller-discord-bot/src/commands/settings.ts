import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextChannel,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import {
  ensureServerConfig,
  getServerConfig,
  updateEnabledGames,
  updateServerChannels,
  updateServerEconomy,
  updateServerRoles,
  updateServerLimits,
  updateServerRatingEmbed,
  updateChannelAccessMode,
  setChannelAccessRules,
  getChannelAccessRuleIds,
} from '../config/serverConfigService';

// ─── Slash command handler ───

export async function handleSettingsRoot(interaction: ChatInputCommandInteraction) {
  const member = await interaction.guild!.members.fetch(interaction.user.id);
  const isAdmin =
    member.permissions.has(PermissionFlagsBits.Administrator) ||
    interaction.guild!.ownerId === interaction.user.id;

  if (!isAdmin) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступ к \`/settings\` есть только у админов и владельца сервера.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await ensureServerConfig(interaction.guild!.id);
  const config = await getServerConfig(interaction.guild!.id);

  // Подсказки о ненастроенных каналах
  const missingChannels: string[] = [];
  if (!config?.logChannelId) missingChannels.push('Канал логов');
  if (!config?.announceChannelId) missingChannels.push('Канал объявлений');
  if (!config?.ratingChannelId) missingChannels.push('Канал рейтинга');
  if (!config?.gamesChannelId) missingChannels.push('Канал игр');
  if (!(config as { ticketsChannelId?: string | null })?.ticketsChannelId) missingChannels.push('🎟️ Канал ставки (тикеты)');
  if (!(config as { accountingChannelId?: string | null })?.accountingChannelId) missingChannels.push('⚖️ Канал выдачи (бухгалтерия)');

  let description = 'Используйте кнопки ниже, чтобы настроить каналы, роли, экономику и игры.';

  if (missingChannels.length > 0) {
    description += `\n\n${UI_CONFIG.EMOJI.WARNING} **Не настроены:** ${missingChannels.join(', ')}.\n` +
      `Нажмите **Каналы**, чтобы указать их. Без этих каналов некоторые функции (логи, объявления побед) не работают.`;
  }

  const embed = new EmbedBuilder()
    .setTitle('Настройки игрового бота')
    .setDescription(description)
    .setColor(missingChannels.length > 0 ? UI_CONFIG.COLORS.WARNING : UI_CONFIG.COLORS.PRIMARY);

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('settings:channels')
      .setLabel('Каналы')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('settings:roles')
      .setLabel('Роли')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('settings:economy')
      .setLabel('Экономика')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('settings:games')
      .setLabel('Игры')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings:save')
      .setLabel('Сохранить')
      .setStyle(ButtonStyle.Success),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('settings:access')
      .setLabel('Доступ')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings:clean')
      .setLabel('Очистить канал')
      .setStyle(ButtonStyle.Danger),
  );

  return interaction.reply({
    embeds: [embed],
    components: [row1, row2],
    flags: MessageFlags.Ephemeral,
  });
}

// ─── Button handler ───

const AUTO_RATING_LABELS: Record<string, string> = {
  none: 'выключено',
  minute: 'каждую минуту',
  hour: 'каждый час',
  day: 'раз в день (12:00 UTC)',
  hourly: 'каждый час',
  daily: 'раз в день',
  weekly: 'раз в неделю',
};

export async function handleSettingsButton(interaction: ButtonInteraction) {
  const { customId } = interaction;

  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  // Каналы: подменю — все настройки каналов
  if (customId === 'settings:channels') {
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId('settings:channelsMain')
        .setLabel('Основные каналы')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('settings:channelsTickets')
        .setLabel('🎟️ Ставки / ⚖️ Выдача / Игры')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('settings:channelsAdminArena')
        .setLabel('Админ / Арена')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('settings:ratingEmbed')
        .setLabel('Авто-обновление рейтинга')
        .setStyle(ButtonStyle.Secondary),
    );
    return interaction.reply({
      content: 'Выберите раздел каналов: основные, ставки/выдача/игры, админ/арена или авто-обновление рейтинга.',
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }

  // Экономика: подменю — балансы/ставки или лимиты
  if (customId === 'settings:economy') {
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId('settings:economyMain')
        .setLabel('Балансы и ставки')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('settings:limits')
        .setLabel('Лимиты')
        .setStyle(ButtonStyle.Danger),
    );
    return interaction.reply({
      content: 'Выберите: экономика (стартовый баланс, бонусы, мин/макс ставка, комиссия) или лимиты (ставок в минуту, выигрыш в час, порог крупной победы).',
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId === 'settings:economyMain') {
    // Открыть модалку экономики (как раньше settings:economy)
    const modal = new ModalBuilder()
      .setCustomId('settings:economyModal')
      .setTitle('Экономика');

    const startBalance = new TextInputBuilder()
      .setCustomId('startBalance')
      .setLabel('Стартовый баланс (число)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const dailyBonus = new TextInputBuilder()
      .setCustomId('dailyBonus')
      .setLabel('Ежедневный бонус (число)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const minBet = new TextInputBuilder()
      .setCustomId('minBet')
      .setLabel('Мин. ставка')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const maxBet = new TextInputBuilder()
      .setCustomId('maxBet')
      .setLabel('Макс. ставка')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const commission = new TextInputBuilder()
      .setCustomId('casinoCommission')
      .setLabel('Комиссия с выигрыша (0.02 = 2%)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('0.02');

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(startBalance),
      new ActionRowBuilder<TextInputBuilder>().addComponents(dailyBonus),
      new ActionRowBuilder<TextInputBuilder>().addComponents(minBet),
      new ActionRowBuilder<TextInputBuilder>().addComponents(maxBet),
      new ActionRowBuilder<TextInputBuilder>().addComponents(commission),
    );

    return interaction.showModal(modal);
  }

  if (customId === 'settings:channelsMain') {
    const modal = new ModalBuilder()
      .setCustomId('settings:channelsModal')
      .setTitle('Настройки каналов');

    const logInput = new TextInputBuilder()
      .setCustomId('logChannelId')
      .setLabel('Канал логов (ID или #упоминание)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const ratingInput = new TextInputBuilder()
      .setCustomId('ratingChannelId')
      .setLabel('Канал рейтинга (ID или #упоминание)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const announceInput = new TextInputBuilder()
      .setCustomId('announceChannelId')
      .setLabel('Канал объявлений (ID или #упоминание)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const eventVoiceInput = new TextInputBuilder()
      .setCustomId('eventVoiceChannelId')
      .setLabel('Голосовой канал мероприятий (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const eventsChannelInput = new TextInputBuilder()
      .setCustomId('eventsChannelId')
      .setLabel('Канал событий — покер/канат (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('Сюда дублируется анонс турниров покера и перетягивания');

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(logInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(ratingInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(announceInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(eventVoiceInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(eventsChannelInput),
    );

    return interaction.showModal(modal);
  }

  if (customId === 'settings:ratingEmbed') {
    const config = await getServerConfig(interaction.guild!.id);
    const current = (config as { autoRatingInterval?: string | null })?.autoRatingInterval ?? 'none';
    const select = new StringSelectMenuBuilder()
      .setCustomId('settings:ratingIntervalSelect')
      .setPlaceholder('Как часто обновлять рейтинг')
      .addOptions(
        { label: 'Выкл', value: 'none', description: 'Без автообновления' },
        { label: 'Каждую минуту', value: 'minute', description: 'Обновление раз в минуту' },
        { label: 'Каждый час', value: 'hour', description: 'Обновление раз в час' },
        { label: 'Раз в день', value: 'day', description: 'Обновление раз в день (12:00 UTC)' },
      );
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
    return interaction.reply({
      content: `Авто-обновление рейтинга в канале. Текущий режим: **${AUTO_RATING_LABELS[current] ?? current}**. Выберите интервал:`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId === 'settings:channelsAdminArena') {
    const config = await getServerConfig(interaction.guild!.id);
    const adminUserIdCurrent = (config as { adminUserId?: string | null })?.adminUserId ?? '';

    const modal = new ModalBuilder()
      .setCustomId('settings:channelsAdminArenaModal')
      .setTitle('Канал админа и арена');

    const adminInput = new TextInputBuilder()
      .setCustomId('adminChannelId')
      .setLabel('Канал админа (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const arenaInput = new TextInputBuilder()
      .setCustomId('arenaChannelId')
      .setLabel('Канал арены (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const adminUserInput = new TextInputBuilder()
      .setCustomId('adminUserId')
      .setLabel('ID админа: бизнес-счёт (10% + комиссия игр)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Discord ID пользователя или @упоминание')
      .setRequired(false)
      .setValue(adminUserIdCurrent);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(adminInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(arenaInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(adminUserInput),
    );
    return interaction.showModal(modal);
  }

  if (customId === 'settings:channelsTickets') {
    const modal = new ModalBuilder()
      .setCustomId('settings:channelsTicketsModal')
      .setTitle('Каналы: ставки и выдача');

    const ticketsInput = new TextInputBuilder()
      .setCustomId('ticketsChannelId')
      .setLabel('🎟️ Канал ставки (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Игроки: баланс, переводы, кнопки Вывести/Пополнить')
      .setRequired(false);

    const accountingInput = new TextInputBuilder()
      .setCustomId('accountingChannelId')
      .setLabel('⚖️ Канал выдачи — бухгалтерия (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Админский канал: тикеты и учёт')
      .setRequired(false);

    const gamesInput = new TextInputBuilder()
      .setCustomId('gamesChannelId')
      .setLabel('🪑 Канал игр (ID или #)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Эмбед со списком игр будет отправлен в этот канал')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(ticketsInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(accountingInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(gamesInput),
    );
    return interaction.showModal(modal);
  }

  if (customId === 'settings:roles') {
    const modal = new ModalBuilder()
      .setCustomId('settings:rolesModal')
      .setTitle('Роли');

    const playerRole = new TextInputBuilder()
      .setCustomId('playerRoleId')
      .setLabel('Роль игрока (ID или @роль)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const modRole = new TextInputBuilder()
      .setCustomId('moderatorRoleId')
      .setLabel('Роль модератора (ID или @роль)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const vipRole = new TextInputBuilder()
      .setCustomId('vipRoleId')
      .setLabel('VIP роль (ID или @роль)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(playerRole),
      new ActionRowBuilder<TextInputBuilder>().addComponents(modRole),
      new ActionRowBuilder<TextInputBuilder>().addComponents(vipRole),
    );

    return interaction.showModal(modal);
  }

  if (customId === 'settings:games') {
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('settings:gamesSelect')
        .setPlaceholder('Выберите доступные игры')
        .setMinValues(0)
        .setMaxValues(7)
        .addOptions(
          { label: 'Кости', value: 'dice' },
          { label: 'Покер', value: 'blind' },
          { label: 'Покер на кубиках', value: 'dicepoker' },
          { label: 'Дуэль', value: 'duel' },
          { label: 'Перетягивание каната', value: 'tug' },
          { label: 'Интервенция 21.5', value: 'intervention' },
          { label: 'Покер (2 vs 3 кости)', value: 'poker' },
          { label: 'Столы', value: 'table' },
        ),
    );

    return interaction.reply({
      content: 'Выберите, какие игры будут доступны на сервере.',
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId === 'settings:limits') {
    const modal = new ModalBuilder()
      .setCustomId('settings:limitsModal')
      .setTitle('Лимиты и пороги');

    const betPerMin = new TextInputBuilder()
      .setCustomId('betPerMinute')
      .setLabel('Макс. ставок в минуту (0 = без лимита)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('Например: 5');

    const winPerHour = new TextInputBuilder()
      .setCustomId('winPerHour')
      .setLabel('Макс. выигрыш в час (0 = без лимита)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('Например: 10000');

    const bigWin = new TextInputBuilder()
      .setCustomId('bigWinThreshold')
      .setLabel('Порог крупной победы (для объявлений)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('Например: 500');

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(betPerMin),
      new ActionRowBuilder<TextInputBuilder>().addComponents(winPerHour),
      new ActionRowBuilder<TextInputBuilder>().addComponents(bigWin),
    );

    return interaction.showModal(modal);
  }

  if (customId === 'settings:save') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.SUCCESS} Настройки сохранены.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId === 'settings:access') {
    const config = await getServerConfig(interaction.guild!.id);
    const mode = (config as { channelAccessMode?: string | null })?.channelAccessMode ?? 'none';
    const channelIds = await getChannelAccessRuleIds(interaction.guild!.id);
    const channelIdsStr = channelIds.join(', ');

    const modal = new ModalBuilder()
      .setCustomId('settings:accessModal')
      .setTitle('Доступ к игровым командам');

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('accessMode')
          .setLabel('Режим: none / whitelist / blacklist')
          .setStyle(TextInputStyle.Short)
          .setRequired(false)
          .setPlaceholder('none = только канал игр; whitelist = только указанные каналы; blacklist = везде кроме указанных')
          .setValue(mode),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('channelIds')
          .setLabel('ID каналов через запятую (для whitelist/blacklist)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setPlaceholder('123456789, 987654321')
          .setValue(channelIdsStr),
      ),
    );
    return interaction.showModal(modal);
  }
}

// ─── Select menu handlers ───

export async function handleSettingsRatingIntervalSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  const value = interaction.values[0];
  if (!value) return;

  const valid = ['none', 'minute', 'hour', 'day'];
  const autoRatingInterval = valid.includes(value) ? value : 'none';

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  await updateServerRatingEmbed(interaction.guild.id, { autoRatingInterval });
  await refreshRatingMessage(interaction.guild.id, interaction.client);

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Авто-обновление рейтинга: **${AUTO_RATING_LABELS[autoRatingInterval]}**.`,
  });
}

export async function handleSettingsSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const selected = interaction.values;
  await updateEnabledGames(interaction.guild.id, selected);

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Список доступных игр обновлён.`,
  });
}

// ─── Modal handlers ───

function extractId(input: string | undefined | null): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (!trimmed) return null;
  const match = trimmed.match(/\d{5,}/);
  return match ? match[0] : null;
}

export async function handleSettingsChannelsAdminArenaModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const adminRaw = interaction.fields.getTextInputValue('adminChannelId')?.trim() ?? '';
  const arenaRaw = interaction.fields.getTextInputValue('arenaChannelId')?.trim() ?? '';
  const adminUserRaw = interaction.fields.getTextInputValue('adminUserId')?.trim() ?? '';
  const adminId = extractId(adminRaw);
  const arenaId = extractId(arenaRaw);
  const adminUserId = adminUserRaw ? (extractId(adminUserRaw) || adminUserRaw) : null;

  const data: { adminChannelId?: string | null; arenaChannelId?: string | null; adminUserId?: string | null } = {};
  if (adminRaw.length > 0) data.adminChannelId = adminId;
  if (arenaRaw.length > 0) data.arenaChannelId = arenaId;
  data.adminUserId = adminUserId;

  if (Object.keys(data).length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Каналы не изменены.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  await updateServerChannels(interaction.guild.id, data);

  if (data.adminChannelId) {
    const ch = await interaction.guild.channels.fetch(data.adminChannelId).catch(() => null) as TextChannel | null;
    if (ch?.send) {
      const { buildAdminPanelPayload } = await import('../services/events');
      const { embeds, components } = buildAdminPanelPayload();
      await ch.send({ embeds, components }).catch(() => {});
    }
  }

  let msg = `${UI_CONFIG.EMOJI.SUCCESS} Каналы админа и арены обновлены.`;
  if (data.adminChannelId) msg += ' В канал админа отправлено меню [Создать событие].';
  if (data.adminUserId) msg += ' Бизнес-счёт привязан к указанному админу.';

  return interaction.editReply({ content: msg });
}

function parseRatingImages(raw: string): (string | null)[] {
  const lines = raw.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const out: (string | null)[] = [null, null, null, null, null];
  for (let i = 0; i < 5 && i < lines.length; i++) {
    if (lines[i].startsWith('http')) out[i] = lines[i];
  }
  return out;
}

export async function handleSettingsCommandsModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const titleRaw = interaction.fields.getTextInputValue('ratingEmbedTitle')?.trim() ?? '';
  const descRaw = interaction.fields.getTextInputValue('ratingEmbedDescription')?.trim() ?? '';
  const imagesRaw = interaction.fields.getTextInputValue('ratingImages')?.trim() ?? '';
  const hourlyRaw = interaction.fields.getTextInputValue('ratingHourly')?.trim().toLowerCase() ?? '';
  const [img1, img2, img3, img4, img5] = parseRatingImages(imagesRaw);
  const autoRatingInterval = hourlyRaw === 'yes' || hourlyRaw === 'да' ? 'hourly' : 'none';

  await updateServerRatingEmbed(interaction.guild.id, {
    ratingEmbedTitle: titleRaw || null,
    ratingEmbedDescription: descRaw || null,
    ratingImage1: img1,
    ratingImage2: img2,
    ratingImage3: img3,
    ratingImage4: img4,
    ratingImage5: img5,
    autoRatingInterval,
  });

  const config = await getServerConfig(interaction.guild.id);
  const ratingChannelId = config?.ratingChannelId ?? null;
  if (ratingChannelId) {
    await refreshRatingMessage(interaction.guild.id, interaction.client);
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Эмбед рейтинга сохранён.${ratingChannelId ? ' Сообщение в канал рейтинга отправлено или обновлено.' : ' Укажите канал рейтинга в **Каналы**.'}${autoRatingInterval === 'hourly' ? ' Рейтинг будет обновляться каждый час.' : ''}`,
  });
}

async function refreshRatingMessage(serverId: string, client: import('discord.js').Client) {
  const config = await getServerConfig(serverId);
  const channelId = config?.ratingChannelId ?? null;
  const messageId = (config as { ratingMessageId?: string | null })?.ratingMessageId ?? null;
  if (!channelId) return;
  const { updateRatingMessage, sendRatingMessage } = await import('./top');
  if (messageId) {
    await updateRatingMessage(client, serverId);
  } else {
    const newId = await sendRatingMessage(client, serverId, channelId);
    if (newId) await updateServerRatingEmbed(serverId, { ratingMessageId: newId });
  }
}

export async function handleSettingsChannelsModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const logChannelRaw = interaction.fields.getTextInputValue('logChannelId');
  const ratingChannelRaw = interaction.fields.getTextInputValue('ratingChannelId');
  const announceChannelRaw = interaction.fields.getTextInputValue('announceChannelId');
  const eventVoiceChannelRaw = interaction.fields.getTextInputValue('eventVoiceChannelId');
  let eventsChannelRaw = '';
  try {
    eventsChannelRaw = interaction.fields.getTextInputValue('eventsChannelId') ?? '';
  } catch {
    // Старая модалка без поля «Канал событий»
  }

  const data: any = {};
  const logId = extractId(logChannelRaw);
  const ratingId = extractId(ratingChannelRaw);
  const announceId = extractId(announceChannelRaw);
  const eventVoiceId = extractId(eventVoiceChannelRaw);
  const eventsId = extractId(eventsChannelRaw);

  if (logChannelRaw.trim().length > 0) data.logChannelId = logId;
  if (ratingChannelRaw.trim().length > 0) data.ratingChannelId = ratingId;
  if (announceChannelRaw.trim().length > 0) data.announceChannelId = announceId;
  if (eventVoiceChannelRaw?.trim().length) data.eventVoiceChannelId = eventVoiceId;
  if (eventsChannelRaw?.trim().length) data.eventsChannelId = eventsId;

  if (Object.keys(data).length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Каналы не изменены (все поля пустые).`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  await updateServerChannels(interaction.guild.id, data);

  if (data.ratingChannelId) {
    await refreshRatingMessage(interaction.guild.id, interaction.client);
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Каналы обновлены.${data.ratingChannelId ? ' Рейтинг отправлен в канал.' : ''}`,
  });
}

export async function handleSettingsChannelsTicketsModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const ticketsRaw = interaction.fields.getTextInputValue('ticketsChannelId');
  const accountingRaw = interaction.fields.getTextInputValue('accountingChannelId');
  const gamesRaw = interaction.fields.getTextInputValue('gamesChannelId');
  const ticketsId = extractId(ticketsRaw);
  const accountingId = extractId(accountingRaw);
  const gamesId = extractId(gamesRaw);

  const data: { ticketsChannelId?: string | null; accountingChannelId?: string | null; gamesChannelId?: string | null } = {};
  if (ticketsRaw.trim().length > 0) data.ticketsChannelId = ticketsId;
  if (accountingRaw.trim().length > 0) data.accountingChannelId = accountingId;
  if (gamesRaw.trim().length > 0) data.gamesChannelId = gamesId;

  if (Object.keys(data).length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Каналы ставки/выдача/игр не изменены.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  await updateServerChannels(interaction.guild.id, data);

  if (data.ticketsChannelId) {
    const { sendStakesPanelToChannel } = await import('../services/tickets');
    await sendStakesPanelToChannel(interaction.client, interaction.guild.id, data.ticketsChannelId).catch(() => {});
  }

  if (data.gamesChannelId) {
    const ch = await interaction.guild.channels.fetch(data.gamesChannelId).catch(() => null) as TextChannel | null;
    if (ch?.send) {
      const { setActiveLobbiesMessageId, updateActiveLobbiesEmbed } = await import('../games/lobbyTables');
      const GAMES_CHANNEL_IMAGE =
        'https://cdn.discordapp.com/attachments/1471462038998880430/1473375465157820660/52693f45-9a2e-4e65-a7c9-c454bb92b322.jpg';
      const embed1 = new EmbedBuilder()
        .setTitle(`${UI_CONFIG.EMOJI.TABLE} Игровой канал`)
        .setDescription(
          'Создайте стол (лобби-ветку): выберите игру и количество мест (2–6). В списке ниже отображаются **активные столы** — можно зайти в любой. Игру запускает **хозяин** стола, когда наберётся минимум 2 игрока. Пустые столы удаляются. Админы имеют доступ ко всем веткам.\n\n**Перетягивание каната** — ивент, запускает админ через `/tug`.',
        )
        .setColor(UI_CONFIG.COLORS.PRIMARY)
        .setImage(GAMES_CHANNEL_IMAGE);
      const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId('gamesChannel:createTable').setLabel('————————————Создать стол —————————————').setStyle(ButtonStyle.Primary),
      );
      await ch.send({ embeds: [embed1], components: [row1] }).catch(() => {});

      const embed2 = new EmbedBuilder()
        .setTitle(`${UI_CONFIG.EMOJI.TABLE} Активные столы`)
        .setDescription('*Нет активных столов. Создайте стол кнопкой выше.*')
        .setColor(UI_CONFIG.COLORS.PRIMARY);
      const msg2 = await ch.send({ embeds: [embed2] }).catch(() => null);
      if (msg2) {
        await setActiveLobbiesMessageId(interaction.guild.id, ch.id, msg2.id);
      }

      const { buildRulesOverviewEmbedForChannel, buildGameSelect } = await import('../commands/stats');
      const embed3 = buildRulesOverviewEmbedForChannel();
      const row3 = buildGameSelect();
      await ch.send({ embeds: [embed3], components: [row3] }).catch(() => {});
    }
  }

  const parts = [`${UI_CONFIG.EMOJI.SUCCESS} Каналы **ставки** и **выдача** обновлены.`];
  if (data.ticketsChannelId) parts.push(' Панель отправлена в канал ставки.');
  if (data.gamesChannelId) parts.push(' Эмбед с играми отправлен в канал игр.');

  return interaction.editReply({
    content: parts.join(''),
  });
}

export async function handleSettingsEconomyModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const startBalanceRaw = interaction.fields.getTextInputValue('startBalance');
  const dailyBonusRaw = interaction.fields.getTextInputValue('dailyBonus');
  const minBetRaw = interaction.fields.getTextInputValue('minBet');
  const maxBetRaw = interaction.fields.getTextInputValue('maxBet');
  const commissionRaw = interaction.fields.getTextInputValue('casinoCommission');

  const data: any = {};

  function parseIntField(raw: string, field: string) {
    if (!raw.trim()) return;
    const num = Number.parseInt(raw, 10);
    if (Number.isNaN(num) || num < 0) {
      throw new Error(`Поле "${field}" должно быть неотрицательным числом.`);
    }
    (data as any)[field] = num;
  }

  function parseFloatField(raw: string, field: string) {
    if (!raw.trim()) return;
    const num = Number.parseFloat(raw);
    if (Number.isNaN(num) || num < 0) {
      throw new Error(`Поле "${field}" должно быть неотрицательным числом.`);
    }
    if (field === 'casinoCommission' && (num < 0 || num > 1)) {
      throw new Error('Комиссия с выигрыша: число от 0 до 1 (например 0.02 = 2%).');
    }
    (data as any)[field] = num;
  }

  try {
    parseIntField(startBalanceRaw, 'startBalance');
    parseIntField(dailyBonusRaw, 'dailyBonus');
    parseIntField(minBetRaw, 'minBet');
    parseIntField(maxBetRaw, 'maxBet');
    parseFloatField(commissionRaw, 'casinoCommission');
  } catch (e: any) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} ${e.message}`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (Object.keys(data).length === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Экономика не изменена (все поля пустые).`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await updateServerEconomy(interaction.guild.id, data);

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Параметры экономики обновлены.`,
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleSettingsLimitsModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const betPerMinRaw = interaction.fields.getTextInputValue('betPerMinute');
  const winPerHourRaw = interaction.fields.getTextInputValue('winPerHour');
  const bigWinRaw = interaction.fields.getTextInputValue('bigWinThreshold');

  const limits: { betPerMinute?: number | null; winPerHour?: number | null } = {};
  let bigWinThreshold: number | undefined;

  if (betPerMinRaw.trim()) {
    const num = Number.parseInt(betPerMinRaw, 10);
    if (Number.isNaN(num) || num < 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Ставок в минуту должно быть неотрицательным числом.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    limits.betPerMinute = num === 0 ? null : num;
  }

  if (winPerHourRaw.trim()) {
    const num = Number.parseInt(winPerHourRaw, 10);
    if (Number.isNaN(num) || num < 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Выигрыш в час должен быть неотрицательным числом.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    limits.winPerHour = num === 0 ? null : num;
  }

  if (bigWinRaw.trim()) {
    const num = Number.parseInt(bigWinRaw, 10);
    if (Number.isNaN(num) || num < 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} Порог крупной победы должен быть неотрицательным числом.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    bigWinThreshold = num;
  }

  const hasLimits = Object.keys(limits).length > 0;
  const hasBigWin = bigWinThreshold !== undefined;

  if (!hasLimits && !hasBigWin) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Настройки не изменены (все поля пустые).`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (hasLimits) {
    await updateServerLimits(interaction.guild.id, limits);
  }
  if (hasBigWin) {
    await updateServerEconomy(interaction.guild.id, { bigWinThreshold });
  }

  const parts: string[] = [];
  if (limits.betPerMinute !== undefined) {
    parts.push(`Ставок/мин: **${limits.betPerMinute ?? 'без лимита'}**`);
  }
  if (limits.winPerHour !== undefined) {
    parts.push(`Выигрыш/час: **${limits.winPerHour ?? 'без лимита'}**`);
  }
  if (hasBigWin) {
    parts.push(`Порог крупной победы: **${bigWinThreshold}**`);
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Настройки обновлены.\n${parts.join('\n')}`,
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleSettingsAccessModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const modeRaw = interaction.fields.getTextInputValue('accessMode')?.trim().toLowerCase() ?? 'none';
  const channelIdsRaw = interaction.fields.getTextInputValue('channelIds')?.trim() ?? '';
  const validModes = ['none', 'whitelist', 'blacklist'];
  const accessMode = validModes.includes(modeRaw) ? modeRaw : 'none';

  const channelIds = channelIdsRaw
    .split(/[\s,;]+/)
    .map((s) => s.replace(/\D/g, ''))
    .filter((id) => id.length >= 5);

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  await updateChannelAccessMode(interaction.guild.id, accessMode);
  await setChannelAccessRules(interaction.guild.id, channelIds);

  const modeLabels: Record<string, string> = {
    none: 'только канал игр',
    whitelist: `whitelist: ${channelIds.length} каналов`,
    blacklist: `blacklist: ${channelIds.length} каналов`,
  };

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Доступ к игровым командам обновлён: **${modeLabels[accessMode]}**.`,
  });
}

export async function handleSettingsRolesModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Настройки доступны только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const playerRaw = interaction.fields.getTextInputValue('playerRoleId');
  const modRaw = interaction.fields.getTextInputValue('moderatorRoleId');
  const vipRaw = interaction.fields.getTextInputValue('vipRoleId');

  const playerId = extractId(playerRaw);
  const modId = extractId(modRaw);
  const vipId = extractId(vipRaw);

  await updateServerRoles(interaction.guild.id, {
    playerRoleId: playerRaw.trim().length > 0 ? playerId : undefined,
    moderatorRoleId: modRaw.trim().length > 0 ? modId : undefined,
    vipRoleId: vipRaw.trim().length > 0 ? vipId : undefined,
  });

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Роли обновлены.`,
    flags: MessageFlags.Ephemeral,
  });
}
