import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { checkBetPerMinuteLimit, checkWinPerHourLimit } from '../services/limits';
import { setSession, getSession, deleteSession } from '../services/sessions';

// Колода: 6,7,8,9,J,Q,K,A
const DECK_CARDS = ['6', '7', '8', '9', 'J', 'Q', 'K', 'A'] as const;

function cardValue(card: string): number {
  if (['6', '7', '8', '9'].includes(card)) return Number.parseInt(card, 10);
  if (['J', 'Q', 'K'].includes(card)) return 0.5;
  return 0; // Ace handled separately
}

function isAce(card: string): boolean {
  return card === 'A';
}

interface InterventionSession {
  betAmount: number;
  seed: string;
  cards: string[];
  total: number;
  hasAceChoice: boolean;
  pendingAceCard: boolean;
  memberRoleIds: string[];
}

function drawCard(): string {
  return DECK_CARDS[crypto.randomInt(0, DECK_CARDS.length)];
}

// ─── Интервенция PvP (2 игрока, по очереди карта, оба пас — победитель или сгорание) ───

const DECK_PVP: string[] = (() => {
  const out: string[] = [];
  for (let i = 0; i < 4; i++) {
    for (const c of DECK_CARDS) out.push(c);
  }
  return out;
})();

function createShuffledPvPDeck(): string[] {
  const deck = [...DECK_PVP];
  for (let i = deck.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function interventionPvPKey(serverId: string, p1: string, p2: string): string {
  const [a, b] = [p1, p2].sort();
  return `interventionPvP:${serverId}:${a}:${b}`;
}

export interface InterventionPvPSession {
  player1Id: string;
  player2Id: string;
  stake: number;
  deck: string[];
  p1Cards: string[];
  p2Cards: string[];
  p1Total: number;
  p2Total: number;
  p1Stood: boolean;
  p2Stood: boolean;
  p1Bust: boolean;
  p2Bust: boolean;
  currentTurn: '1' | '2';
  phase: 'playing' | 'done';
  aceChoice: '1' | '2' | null; // кто выбирает туз
  seed: string;
}

export function buildInterventionChallengeEmbed(challengerId: string, opponentId: string, suggestedStake?: number) {
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5 — вызов`)
    .setDescription(
      `<@${challengerId}> вызывает <@${opponentId}> на Интервенцию 21.5!\n\n` +
        '**Правила:** по очереди тянете карту (Ещё / Пас). Игра заканчивается, когда **оба** сделали Пас. Ближе к 21.5 — победа и банк. Если оба перебрали — ставки **сгорают**.\n\n' +
        (suggestedStake ? `Предложенная ставка: **${suggestedStake}** с каждого.\n\n` : '') +
        `<@${opponentId}>, принять или отказаться?`,
    )
    .setColor(UI_CONFIG.COLORS.INTERVENTION);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`interventionPvP:accept:${challengerId}:${opponentId}`)
      .setLabel('Принять')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`interventionPvP:decline:${challengerId}:${opponentId}`)
      .setLabel('Отказаться')
      .setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [row] };
}

export function showInterventionBetModal(interaction: any) {
  const modal = new ModalBuilder()
    .setCustomId('intervention:betModal')
    .setTitle('Интервенция 21.5 — ставка');

  const input = new TextInputBuilder()
    .setCustomId('bet_amount')
    .setLabel('Сколько септимов на кон?')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(input),
  );

  return interaction.showModal(modal);
}

export async function handleInterventionBetModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const serverId = interaction.guild.id;
  const userId = interaction.user.id;
  const betRaw = interaction.fields.getTextInputValue('bet_amount');
  const betAmount = Number.parseInt(betRaw, 10);

  if (Number.isNaN(betAmount) || betAmount <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная сумма ставки.`, flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(serverId);
  const profile = await getOrCreateProfile(serverId, userId);

  if (betAmount < config.minBet || betAmount > config.maxBet) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ставка: ${config.minBet}–${config.maxBet}.`, flags: MessageFlags.Ephemeral });
  }
  if (profile.balance < BigInt(betAmount)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance}.`, flags: MessageFlags.Ephemeral });
  }

  const limitCheck = await checkBetPerMinuteLimit(serverId, userId);
  if (!limitCheck.ok) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} ${limitCheck.reason}`, flags: MessageFlags.Ephemeral });
  }

  await adjustBalance({ serverId, userId, delta: -betAmount, reason: 'intervention_bet' });

  const seed = crypto.randomUUID();
  const card = drawCard();
  let total = 0;
  const cards: string[] = [];
  let hasAceChoice = false;
  let pendingAceCard = false;

  if (isAce(card)) {
    hasAceChoice = true;
    pendingAceCard = true;
    cards.push(card);
  } else {
    total = cardValue(card);
    cards.push(card);
  }

  const member = interaction.member as any;
  const memberRoleIds: string[] = member?.roles?.cache?.map((r: any) => r.id) ?? [];
  const sessionKey = `intervention:${serverId}:${userId}`;
  await setSession<InterventionSession>(sessionKey, {
    betAmount, seed, cards, total, hasAceChoice, pendingAceCard, memberRoleIds,
  });

  return renderInterventionState(interaction, serverId, userId, false);
}

async function renderInterventionState(
  interaction: any,
  serverId: string,
  userId: string,
  isUpdate: boolean,
) {
  const sessionKey = `intervention:${serverId}:${userId}`;
  const session = await getSession<InterventionSession>(sessionKey);
  if (!session) {
    return isUpdate
      ? interaction.update({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия истекла.`, embeds: [], components: [] })
      : interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия истекла.`, flags: MessageFlags.Ephemeral });
  }

  const cardsStr = session.cards.map(c => `\`${c}\``).join(' ');
  const lines: string[] = [];
  lines.push(`Карты: ${cardsStr}`);

  if (session.pendingAceCard) {
    lines.push(`\nВытянут **Туз** — выбери значение:`);

    const embed = new EmbedBuilder()
      .setTitle('🃏 Интервенция 21.5')
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.INTERVENTION);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('intervention:ace1').setLabel('Туз = 1').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('intervention:ace11').setLabel('Туз = 11').setStyle(ButtonStyle.Primary),
    );

    const data = { embeds: [embed], components: [row] };
    return isUpdate ? interaction.update(data) : interaction.reply({ ...data, flags: MessageFlags.Ephemeral });
  }

  lines.push(`Сумма: **${session.total}**`);
  lines.push(`Ставка: **${session.betAmount}** септимов`);

  const embed = new EmbedBuilder()
    .setTitle('🃏 Интервенция 21.5')
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('intervention:hit').setLabel('Ещё карту').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('intervention:stand').setLabel('Хватит').setStyle(ButtonStyle.Danger),
  );

  const data = { embeds: [embed], components: [row] };
  return isUpdate ? interaction.update(data) : interaction.reply({ ...data, flags: MessageFlags.Ephemeral });
}

export async function handleInterventionButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const serverId = interaction.guild.id;
  const userId = interaction.user.id;
  const { customId } = interaction;

  if (customId === 'intervention:bet') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Интервенция 21.5 только с другим игроком: \`/intervention opponent:@игрок\` или кнопка в канале игр.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId.startsWith('interventionPvP:')) {
    return handleInterventionPvPButton(interaction, serverId, customId);
  }

  const sessionKey = `intervention:${serverId}:${userId}`;
  const session = await getSession<InterventionSession>(sessionKey);

  if (!session) {
    return interaction.update({
      content: `${UI_CONFIG.EMOJI.ERROR} Сессия завершена.`,
      embeds: [],
      components: [],
    });
  }

  if (customId === 'intervention:ace1' || customId === 'intervention:ace11') {
    const aceVal = customId === 'intervention:ace1' ? 1 : 11;
    session.total += aceVal;
    session.pendingAceCard = false;
    session.hasAceChoice = false;
    await setSession(sessionKey, session);

    if (session.total > 21.5) {
      return finishIntervention(interaction, serverId, userId, session, 'bust');
    }
    return renderInterventionState(interaction, serverId, userId, true);
  }

  if (customId === 'intervention:hit') {
    const card = drawCard();
    session.cards.push(card);

    if (isAce(card)) {
      session.pendingAceCard = true;
      session.hasAceChoice = true;
      await setSession(sessionKey, session);
      return renderInterventionState(interaction, serverId, userId, true);
    }

    session.total += cardValue(card);
    await setSession(sessionKey, session);

    if (session.total > 21.5) {
      return finishIntervention(interaction, serverId, userId, session, 'bust');
    }

    return renderInterventionState(interaction, serverId, userId, true);
  }

  if (customId === 'intervention:stand') {
    if (session.total < 17) {
      return finishIntervention(interaction, serverId, userId, session, 'under');
    }
    return finishIntervention(interaction, serverId, userId, session, 'stand');
  }
}

async function finishIntervention(
  interaction: ButtonInteraction,
  serverId: string,
  userId: string,
  session: InterventionSession,
  reason: 'bust' | 'under' | 'stand',
) {
  const sessionKey = `intervention:${serverId}:${userId}`;
  await deleteSession(sessionKey);

  const cardsStr = session.cards.map(c => `\`${c}\``).join(' ');
  const lines: string[] = [];
  lines.push(`Карты: ${cardsStr}`);
  lines.push(`Сумма: **${session.total}**`);
  lines.push(`Ставка: **${session.betAmount}**`);

  let payout = 0;
  let outcome = 'lose';

  if (reason === 'bust') {
    lines.push(`\n${UI_CONFIG.EMOJI.LOSS} Перебор — ставка ушла в Флягу.`);
  } else if (reason === 'under') {
    lines.push(`\n${UI_CONFIG.EMOJI.LOSS} Меньше 17 — проигрыш.`);
  } else {
    const vipMul = await getVipMultiplier(serverId, session.memberRoleIds);
    const config = await getServerConfig(serverId);
    if (session.total === 21.5) {
      const raw5 = session.betAmount * 5;
      payout = calculatePayout(raw5, vipMul, config?.casinoCommission);
      const { creditAdminCommissionFromPayout } = await import('../services/economy');
      await creditAdminCommissionFromPayout(serverId, raw5, config?.casinoCommission);
      outcome = 'win';
      lines.push(`\n${UI_CONFIG.EMOJI.WIN} Ровно 21.5! Выигрыш x5 = **${payout}** септимов!`);
    } else if (session.total === 21) {
      const raw2 = session.betAmount * 2;
      payout = calculatePayout(raw2, vipMul, config?.casinoCommission);
      const { creditAdminCommissionFromPayout } = await import('../services/economy');
      await creditAdminCommissionFromPayout(serverId, raw2, config?.casinoCommission);
      outcome = 'win';
      lines.push(`\n${UI_CONFIG.EMOJI.WIN} 21! Выигрыш x2 = **${payout}** септимов!`);
    } else if (session.total >= 17 && session.total < 21) {
      const raw15 = session.betAmount * 1.5;
      payout = calculatePayout(raw15, vipMul, config?.casinoCommission);
      const { creditAdminCommissionFromPayout } = await import('../services/economy');
      await creditAdminCommissionFromPayout(serverId, raw15, config?.casinoCommission);
      outcome = 'win';
      lines.push(`\n${UI_CONFIG.EMOJI.WIN} Выигрыш x1.5 = **${payout}** септимов!`);
    }
  }

  if (payout > 0) {
    const winLimit = await checkWinPerHourLimit(serverId, userId, payout);
    if (!winLimit.ok) payout = 0;
  }

  if (payout > 0) {
    await adjustBalance({ serverId, userId, delta: payout, reason: 'intervention_payout' });
  }

  await logBet({
    serverId, userId, gameType: 'intervention',
    betAmount: session.betAmount, payoutAmount: payout, outcome, seed: session.seed,
  });

  const profile = await getOrCreateProfile(serverId, userId);
  lines.push(`\nБаланс: **${profile.balance}**`);

  const embed = new EmbedBuilder()
    .setTitle('🃏 Интервенция 21.5 — Результат')
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('intervention:bet')
      .setLabel('Ещё разок')
      .setStyle(ButtonStyle.Success),
  );

  return interaction.update({ embeds: [embed], components: [row] });
}

async function handleInterventionPvPButton(
  interaction: ButtonInteraction,
  serverId: string,
  customId: string,
) {
  const parts = customId.split(':');
  const action = parts[1];
  const challengerId = parts[2];
  const opponentId = parts[3];

  if (action === 'decline') {
    if (interaction.user.id !== opponentId) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только вызванный может ответить.`, flags: MessageFlags.Ephemeral });
    }
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция — отказ`)
      .setDescription(`<@${opponentId}> не принял вызов.`)
      .setColor(UI_CONFIG.COLORS.INTERVENTION);
    return interaction.update({ embeds: [embed], components: [] });
  }

  if (action === 'accept') {
    if (interaction.user.id !== opponentId) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только вызванный может принять.`, flags: MessageFlags.Ephemeral });
    }
    const modal = new ModalBuilder()
      .setCustomId(`interventionPvP:betModal:${challengerId}:${opponentId}`)
      .setTitle('Интервенция 21.5 — ставка с каждого');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('stake')
          .setLabel('Ставка (септимы)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true),
      ),
    );
    return interaction.showModal(modal);
  }

  const key = interventionPvPKey(serverId, challengerId, opponentId);
  const session = await getSession<InterventionPvPSession>(key);
  if (!session || session.phase !== 'playing') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия не найдена или игра завершена.`, flags: MessageFlags.Ephemeral });
  }

  const p1 = session.player1Id;
  const p2 = session.player2Id;
  const currentId = session.currentTurn === '1' ? p1 : p2;
  if (interaction.user.id !== currentId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход <@${currentId}>.`, flags: MessageFlags.Ephemeral });
  }

  if (session.aceChoice) {
    if (action !== 'ace1' && action !== 'ace11') {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Выбери значение туза: 1 или 11.`, flags: MessageFlags.Ephemeral });
    }
    const aceVal = action === 'ace11' ? 11 : 1;
    const who = session.aceChoice;
    if (who === '1') session.p1Total += aceVal;
    else session.p2Total += aceVal;
    session.aceChoice = null;
    await setSession(key, session);
    if (who === '1' && session.p1Total > 21.5) session.p1Bust = true;
    if (who === '2' && session.p2Total > 21.5) session.p2Bust = true;
    if ((who === '1' && session.p1Bust) || (who === '2' && session.p2Bust)) {
      session.currentTurn = who === '1' ? '2' : '1';
      await setSession(key, session);
      const bothDone = (session.p1Stood || session.p1Bust) && (session.p2Stood || session.p2Bust);
      if (bothDone) return finishInterventionPvP(interaction, key, session);
    }
    return renderInterventionPvPState(interaction, key, session);
  }

  if (action === 'stand') {
    if (session.currentTurn === '1') session.p1Stood = true;
    else session.p2Stood = true;
    session.currentTurn = session.currentTurn === '1' ? '2' : '1';
    await setSession(key, session);
    const bothDone = (session.p1Stood || session.p1Bust) && (session.p2Stood || session.p2Bust);
    if (bothDone) return finishInterventionPvP(interaction, key, session);
    return renderInterventionPvPState(interaction, key, session);
  }

  if (action === 'hit') {
    if (session.deck.length === 0) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Колода пуста.`, flags: MessageFlags.Ephemeral });
    }
    const card = session.deck.pop()!;
    if (session.currentTurn === '1') {
      session.p1Cards.push(card);
      if (isAce(card)) {
        session.aceChoice = '1';
        await setSession(key, session);
        return renderInterventionPvPAceChoice(interaction, key, session, '1');
      }
      session.p1Total += cardValue(card);
      if (session.p1Total > 21.5) session.p1Bust = true;
    } else {
      session.p2Cards.push(card);
      if (isAce(card)) {
        session.aceChoice = '2';
        await setSession(key, session);
        return renderInterventionPvPAceChoice(interaction, key, session, '2');
      }
      session.p2Total += cardValue(card);
      if (session.p2Total > 21.5) session.p2Bust = true;
    }
    await setSession(key, session);
    const curBust = session.currentTurn === '1' ? session.p1Bust : session.p2Bust;
    if (curBust) {
      session.currentTurn = session.currentTurn === '1' ? '2' : '1';
      await setSession(key, session);
      const bothDone = (session.p1Stood || session.p1Bust) && (session.p2Stood || session.p2Bust);
      if (bothDone) return finishInterventionPvP(interaction, key, session);
    }
    return renderInterventionPvPState(interaction, key, session);
  }

  return interaction.reply({ content: `${UI_CONFIG.EMOJI.WARNING} Неизвестное действие.`, flags: MessageFlags.Ephemeral });
}

function renderInterventionPvPAceChoice(
  interaction: ButtonInteraction,
  key: string,
  session: InterventionPvPSession,
  who: '1' | '2',
) {
  const p1 = session.player1Id;
  const p2 = session.player2Id;
  const lines: string[] = [
    `Банк: **${session.stake * 2}** септимов`,
    `<@${p1}>: ${session.p1Cards.map(c => `\`${c}\``).join(' ')} → **${session.p1Total}**${session.p1Stood ? ' (пас)' : ''}${session.p1Bust ? ' (перебор)' : ''}`,
    `<@${p2}>: ${session.p2Cards.map(c => `\`${c}\``).join(' ')} → **${session.p2Total}**${session.p2Stood ? ' (пас)' : ''}${session.p2Bust ? ' (перебор)' : ''}`,
    '',
    `<@${who === '1' ? p1 : p2}>, выпал **Туз**. Выбери значение:`,
  ];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`interventionPvP:ace1:${p1}:${p2}`).setLabel('Туз = 1').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`interventionPvP:ace11:${p1}:${p2}`).setLabel('Туз = 11').setStyle(ButtonStyle.Primary),
  );
  return interaction.update({ embeds: [embed], components: [row] });
}

function renderInterventionPvPState(
  interaction: ButtonInteraction,
  key: string,
  session: InterventionPvPSession,
) {
  const p1 = session.player1Id;
  const p2 = session.player2Id;
  const currentId = session.currentTurn === '1' ? p1 : p2;
  const lines: string[] = [
    `Банк: **${session.stake * 2}** септимов`,
    `<@${p1}>: ${session.p1Cards.map(c => `\`${c}\``).join(' ')} → **${session.p1Total}**${session.p1Stood ? ' (пас)' : ''}${session.p1Bust ? ' (перебор)' : ''}`,
    `<@${p2}>: ${session.p2Cards.map(c => `\`${c}\``).join(' ')} → **${session.p2Total}**${session.p2Stood ? ' (пас)' : ''}${session.p2Bust ? ' (перебор)' : ''}`,
    '',
    `Ход: <@${currentId}> — Ещё карту или Пас?`,
  ];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`interventionPvP:hit:${p1}:${p2}`).setLabel('Ещё карту').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`interventionPvP:stand:${p1}:${p2}`).setLabel('Пас').setStyle(ButtonStyle.Danger),
  );
  return interaction.update({ embeds: [embed], components: [row] });
}

async function finishInterventionPvP(
  interaction: ButtonInteraction,
  key: string,
  session: InterventionPvPSession,
) {
  const p1 = session.player1Id;
  const p2 = session.player2Id;
  const serverId = interaction.guild!.id;
  await deleteSession(key);

  const pot = session.stake * 2;
  let winnerId: string | null = null;
  if (session.p1Bust && session.p2Bust) {
    winnerId = null;
  } else if (session.p1Bust) {
    winnerId = p2;
  } else if (session.p2Bust) {
    winnerId = p1;
  } else {
    const t1 = session.p1Total;
    const t2 = session.p2Total;
    if (t1 > 21.5 && t2 > 21.5) winnerId = null;
    else if (t1 > 21.5) winnerId = p2;
    else if (t2 > 21.5) winnerId = p1;
    else if (t1 > t2) winnerId = p1;
    else if (t2 > t1) winnerId = p2;
    else winnerId = null;
  }

  const lines: string[] = [
    `<@${p1}>: ${session.p1Cards.map(c => `\`${c}\``).join(' ')} → **${session.p1Total}**${session.p1Bust ? ' (перебор)' : ''}`,
    `<@${p2}>: ${session.p2Cards.map(c => `\`${c}\``).join(' ')} → **${session.p2Total}**${session.p2Bust ? ' (перебор)' : ''}`,
    '',
  ];

  if (winnerId) {
    await adjustBalance({ serverId, userId: winnerId, delta: pot, reason: 'intervention_pvp_win' });
    await logBet({ serverId, userId: winnerId, gameType: 'intervention', betAmount: session.stake, payoutAmount: pot, outcome: 'win', seed: session.seed });
    const loserId = winnerId === p1 ? p2 : p1;
    await logBet({ serverId, userId: loserId, gameType: 'intervention', betAmount: session.stake, payoutAmount: 0, outcome: 'lose', seed: session.seed });
    lines.push(`${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> забирает **${pot}** септимов!`);
  } else {
    lines.push(`${UI_CONFIG.EMOJI.LOSS} Оба перебрали или ничья — ставки **сгорают**.`);
  }

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5 — итог`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);
  return interaction.update({ embeds: [embed], components: [] });
}

export async function handleInterventionPvPBetModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  const parts = interaction.customId.split(':');
  const challengerId = parts[2];
  const opponentId = parts[3];
  if (interaction.user.id !== opponentId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только принявший вызов вводит ставку.`, flags: MessageFlags.Ephemeral });
  }

  const stakeRaw = interaction.fields.getTextInputValue('stake');
  const stake = Number.parseInt(stakeRaw, 10);
  if (Number.isNaN(stake) || stake <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная ставка.`, flags: MessageFlags.Ephemeral });
  }
  const serverId = interaction.guild.id;
  const config = await ensureServerConfig(serverId);
  if (stake < config.minBet || stake > config.maxBet) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ставка: ${config.minBet}–${config.maxBet}.`, flags: MessageFlags.Ephemeral });
  }
  const prof1 = await getOrCreateProfile(serverId, challengerId);
  const prof2 = await getOrCreateProfile(serverId, opponentId);
  if (prof1.balance < BigInt(stake) || prof2.balance < BigInt(stake)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} У кого-то недостаточно средств.`, flags: MessageFlags.Ephemeral });
  }

  await adjustBalance({ serverId, userId: challengerId, delta: -stake, reason: 'intervention_pvp_bet' });
  await adjustBalance({ serverId, userId: opponentId, delta: -stake, reason: 'intervention_pvp_bet' });

  const deck = createShuffledPvPDeck();
  const session: InterventionPvPSession = {
    player1Id: challengerId,
    player2Id: opponentId,
    stake,
    deck,
    p1Cards: [],
    p2Cards: [],
    p1Total: 0,
    p2Total: 0,
    p1Stood: false,
    p2Stood: false,
    p1Bust: false,
    p2Bust: false,
    currentTurn: '1',
    phase: 'playing',
    aceChoice: null,
    seed: crypto.randomUUID(),
  };
  const key = interventionPvPKey(serverId, challengerId, opponentId);
  await setSession(key, session);

  const lines: string[] = [
    `Банк: **${stake * 2}** септимов`,
    `<@${challengerId}>: (нет карт) → **0**`,
    `<@${opponentId}>: (нет карт) → **0**`,
    '',
    `Ход: <@${challengerId}> — Ещё карту или Пас?`,
  ];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`interventionPvP:hit:${challengerId}:${opponentId}`).setLabel('Ещё карту').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`interventionPvP:stand:${challengerId}:${opponentId}`).setLabel('Пас').setStyle(ButtonStyle.Danger),
  );
  return interaction.reply({ embeds: [embed], components: [row] });
}

/** Запуск Интервенции 21.5 из лобби: 2 игрока — 1v1; >2 — все по кругу (каждый тянет, сравниваем). */
export async function startInterventionFromLobby(
  thread: import('discord.js').ThreadChannel,
  lobby: { serverId: string; memberIds: string[] },
  minBet: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const [p1, p2] = lobby.memberIds;

  if (lobby.memberIds.length !== 2) {
    return { ok: false, error: 'Интервенция 21.5 пока только для 2 игроков.' };
  }

  const prof1 = await getOrCreateProfile(serverId, p1);
  const prof2 = await getOrCreateProfile(serverId, p2);
  if (prof1.balance < BigInt(minBet) || prof2.balance < BigInt(minBet)) {
    return { ok: false, error: `Недостаточно средств. Нужно ${minBet} септимов с каждого.` };
  }

  await adjustBalance({ serverId, userId: p1, delta: -minBet, reason: 'intervention_pvp_bet' });
  await adjustBalance({ serverId, userId: p2, delta: -minBet, reason: 'intervention_pvp_bet' });

  const deck = createShuffledPvPDeck();
  const session: InterventionPvPSession = {
    player1Id: p1,
    player2Id: p2,
    stake: minBet,
    deck,
    p1Cards: [],
    p2Cards: [],
    p1Total: 0,
    p2Total: 0,
    p1Stood: false,
    p2Stood: false,
    p1Bust: false,
    p2Bust: false,
    currentTurn: '1',
    phase: 'playing',
    aceChoice: null,
    seed: crypto.randomUUID(),
  };
  const key = interventionPvPKey(serverId, p1, p2);
  await setSession(key, session);

  const lines: string[] = [
    `Банк: **${minBet * 2}** септимов`,
    `<@${p1}>: (нет карт) → **0**`,
    `<@${p2}>: (нет карт) → **0**`,
    '',
    `Ход: <@${p1}> — Ещё карту или Пас?`,
  ];
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.INTERVENTION} Интервенция 21.5`)
    .setDescription(lines.join('\n'))
    .setColor(UI_CONFIG.COLORS.INTERVENTION);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`interventionPvP:hit:${p1}:${p2}`).setLabel('Ещё карту').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`interventionPvP:stand:${p1}:${p2}`).setLabel('Пас').setStyle(ButtonStyle.Danger),
  );
  await thread.send({ embeds: [embed], components: [row] });
  return { ok: true };
}
