import { ActivityType, Client, Events, GatewayIntentBits } from 'discord.js';
import { onInteractionCreate } from './events/interactionCreate';

// Re-export definitions for deploy script and other consumers
export { commands, getSlashCommandData } from './commands/definitions';
export type { CommandName } from './commands/definitions';

const ROTATING_STATUSES = [
  { type: ActivityType.Streaming, name: 'Снимает в Крысиной Норе', url: 'https://www.twitch.tv/directory' },
  { type: ActivityType.Playing, name: 'Играет в кости на скуму' },
  { type: ActivityType.Watching, name: 'Смотрит за ставками в Яме' },
] as const;

const STATUS_INTERVAL_MS = 10 * 1000;

export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
  ],
});

client.once(Events.ClientReady, (c) => {
  process.stderr.write(`[bot] Ready as ${c.user.tag}\n`);

  let idx = 0;
  const setNext = () => {
    const s = ROTATING_STATUSES[idx % ROTATING_STATUSES.length];
    c.user.setActivity(s.name, { type: s.type, ...('url' in s ? { url: s.url } : {}) });
    idx++;
  };

  setNext();
  setInterval(setNext, STATUS_INTERVAL_MS);
});

client.on(Events.InteractionCreate, onInteractionCreate);

// При упоминании бота — подсказка про /help (только от пользователей, не от ботов)
// Ветки с играми: обновить lastMessage при любом сообщении (3 мин без сообщений → архив)
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  if (message.mentions.has(client.user!.id)) {
    return message.reply({
      content: 'Чтобы узнать все команды Норы — пиши `/help`.',
    });
  }

  if (message.channel?.isThread?.() && message.guild?.id) {
    const { getLobby, setLobbyLastMessage } = await import('./games/lobbyTables');
    const lobby = await getLobby(message.guild.id, message.channel.id);
    if (lobby) {
      await setLobbyLastMessage(message.guild.id, message.channel.id);
    }
  }
});
