import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
} from 'discord.js';
import { prisma } from '../db/client';
import { UI_CONFIG } from '../config/ui';
import { getOrCreateProfile, adjustBalance } from './economy';

const DEFAULT_ITEMS = [
  {
    key: 'duel_card_pack',
    name: 'Набор карт для дуэли',
    description: 'Расширяет вашу колоду дуэли дополнительными картами',
    price: 500,
    category: 'cards',
    emoji: '🃏',
  },
  {
    key: 'lucky_charm',
    name: 'Талисман удачи',
    description: 'Повышает шанс на благоприятный исход на 1 игру',
    price: 300,
    category: 'booster',
    emoji: '🍀',
  },
  {
    key: 'double_daily',
    name: 'Двойной ежедневный бонус',
    description: 'Следующий /daily даст x2 монет',
    price: 200,
    category: 'booster',
    emoji: '💎',
  },
  {
    key: 'reroll_token',
    name: 'Жетон переброса',
    description: 'Дополнительный переброс в игре /dice',
    price: 150,
    category: 'booster',
    emoji: '🔄',
  },
  {
    key: 'shield',
    name: 'Щит',
    description: 'Защищает от одного проигрыша - ставка возвращается',
    price: 750,
    category: 'booster',
    emoji: '🛡️',
  },
  {
    key: 'vip_pass_day',
    name: 'VIP-пропуск (1 день)',
    description: 'Даёт VIP-множитель x1.25 на 24 часа',
    price: 1000,
    category: 'premium',
    emoji: '⭐',
  },
];

async function ensureShopItems(serverId: string) {
  const existing = await prisma.shopItem.findMany({ where: { serverId } });
  if (existing.length > 0) return existing;

  for (const item of DEFAULT_ITEMS) {
    await prisma.shopItem.upsert({
      where: { serverId_key: { serverId, key: item.key } },
      update: {},
      create: { ...item, serverId },
    });
  }

  return prisma.shopItem.findMany({ where: { serverId, enabled: true } });
}

export async function handleShop(interaction: ChatInputCommandInteraction) {
  const serverId = interaction.guildId;
  if (!serverId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Команда доступна только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const items = await ensureShopItems(serverId);
  const profile = await getOrCreateProfile(serverId, interaction.user.id);

  const enabledItems = items.filter((i) => i.enabled);

  if (enabledItems.length === 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.SHOP} Магазин пуст.`, flags: MessageFlags.Ephemeral });
  }

  const lines = enabledItems.map(
    (item, idx) =>
      `${item.emoji} **${item.name}** - ${item.price} ${UI_CONFIG.EMOJI.COIN}\n` +
      `  _${item.description}_`,
  );

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.SHOP} Магазин`)
    .setDescription(
      `Ваш баланс: **${profile.balance}** ${UI_CONFIG.EMOJI.COIN}\n\n` +
        lines.join('\n\n'),
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setFooter({ text: 'Нажмите кнопку, чтобы купить предмет' });

  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  let currentRow = new ActionRowBuilder<ButtonBuilder>();

  for (const item of enabledItems) {
    if (currentRow.components.length >= 5) {
      rows.push(currentRow);
      currentRow = new ActionRowBuilder<ButtonBuilder>();
    }
    currentRow.addComponents(
      new ButtonBuilder()
        .setCustomId(`shop:buy:${item.key}`)
        .setLabel(`${item.emoji} ${item.name} (${item.price})`)
        .setStyle(ButtonStyle.Primary)
        .setDisabled(profile.balance < BigInt(item.price)),
    );
  }
  if (currentRow.components.length > 0) rows.push(currentRow);

  return interaction.reply({ embeds: [embed], components: rows, flags: MessageFlags.Ephemeral });
}

export async function handleShopButton(interaction: ButtonInteraction) {
  const serverId = interaction.guildId;
  if (!serverId) return;

  const parts = interaction.customId.split(':');
  const itemKey = parts[2];
  if (!itemKey) return;

  const item = await prisma.shopItem.findUnique({
    where: { serverId_key: { serverId, key: itemKey } },
  });

  if (!item || !item.enabled) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Предмет не найден.`, flags: MessageFlags.Ephemeral });
  }

  const profile = await getOrCreateProfile(serverId, interaction.user.id);

  if (profile.balance < BigInt(item.price)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Нужно **${item.price}**, у вас **${profile.balance}**.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await adjustBalance({
    serverId,
    userId: interaction.user.id,
    delta: -item.price,
    reason: `shop_buy_${itemKey}`,
  });

  const existingUserItem = await prisma.userItem.findUnique({
    where: {
      userId_serverId_itemKey: {
        userId: interaction.user.id,
        serverId,
        itemKey,
      },
    },
  });

  if (existingUserItem) {
    await prisma.userItem.update({
      where: { id: existingUserItem.id },
      data: { quantity: existingUserItem.quantity + 1 },
    });
  } else {
    await prisma.userItem.create({
      data: {
        userId: interaction.user.id,
        serverId,
        itemKey,
        quantity: 1,
      },
    });
  }

  const updatedProfile = await getOrCreateProfile(serverId, interaction.user.id);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.SUCCESS} Покупка совершена!`)
    .setDescription(
      `${item.emoji} **${item.name}**\n\n` +
        `Списано: **${item.price}** ${UI_CONFIG.EMOJI.COIN}\n` +
        `Остаток: **${updatedProfile.balance}** ${UI_CONFIG.EMOJI.COIN}`,
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}
