// Первый импорт — пишем в файл и в stderr, чтобы точно увидеть старт
import fs from 'node:fs';
import path from 'node:path';
const logPath = path.join(process.cwd(), '.bot-startup.log');
try {
  fs.appendFileSync(logPath, `[${new Date().toISOString()}] Node started, loading modules...\n`);
} catch (_) {}
process.stderr.write('[boot] Node started, loading modules...\n');

process.on('uncaughtException', (err) => {
  try {
    fs.appendFileSync(logPath, `[${new Date().toISOString()}] uncaughtException: ${err.message}\n${err.stack}\n`);
  } catch (_) {}
});
process.on('unhandledRejection', (reason) => {
  try {
    fs.appendFileSync(logPath, `[${new Date().toISOString()}] unhandledRejection: ${String(reason)}\n`);
  } catch (_) {}
});
