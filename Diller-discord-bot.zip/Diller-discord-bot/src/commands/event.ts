import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextInputBuilder,
  TextInputStyle,
  type GuildMember,
  MessageFlags,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { getServerConfig } from '../config/serverConfigService';
import {
  EVENT_TYPES,
  BROADCAST_TEMPLATES,
  ARENA_EVENT_TYPES,
  createEvent,
  getUpcomingEvents,
  getEventById,
  getEventWithParticipants,
  cancelEvent,
  forceAnnounceEvent,
  broadcastTemplate,
  buildEventAnnouncementEmbed,
  buildEventListEmbed,
  sendArenaAnnounce,
  addEventParticipant,
  removeEventParticipant,
  getEventParticipants,
  getEventTeamNames,
  sendOrUpdateAdminManagement,
  updateAdminManagementOnly,
  sendAdminSignUpNotification,
  updateArenaAnnounce,
  postEventStartedToAdminThread,
  deleteArenaBetMessage,
  buildArenaStartedEmbed,
  initBracketState,
  advanceBracket,
  getCurrentPair,
  getFightNumber,
  postFightResultToArena,
  sendPayoutLogToAccounting,
  runSettlementForEvent,
  type BracketState,
} from '../services/events';
import { prisma } from '../db/client';
import { redis } from '../db/redis';
import { getLogClient } from '../services/logs';

const ARENA_DRAFT_TTL = 300;
import { getOrCreateProfile, adjustBalance } from '../services/economy';

// ─── /event (корневая команда) ───

export async function handleEventRoot(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const sub = interaction.options.getSubcommand();

  switch (sub) {
    case 'create':
      return showEventCreateModal(interaction);
    case 'list':
      return handleEventList(interaction);
    case 'cancel':
      return handleEventCancel(interaction);
    case 'announce':
      return handleEventAnnounce(interaction);
    case 'broadcast':
      return handleBroadcastSelect(interaction);
    default:
      return interaction.reply({ content: 'Неизвестная подкоманда.', flags: MessageFlags.Ephemeral });
  }
}

// ─── /event create - показать модалку ───

async function showEventCreateModal(interaction: ChatInputCommandInteraction) {
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const modal = new ModalBuilder()
    .setCustomId('event:createModal')
    .setTitle('Создать мероприятие');

  const titleInput = new TextInputBuilder()
    .setCustomId('event_title')
    .setLabel('Название')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ночь костей, Турнир дуэлей...')
    .setMaxLength(100)
    .setRequired(true);

  const descInput = new TextInputBuilder()
    .setCustomId('event_description')
    .setLabel('Описание')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Подробности мероприятия...')
    .setMaxLength(1000)
    .setRequired(true);

  const dateInput = new TextInputBuilder()
    .setCustomId('event_date')
    .setLabel('Дата и время (ДД.ММ.ГГГГ ЧЧ:ММ, МСК)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('25.02.2026 20:00')
    .setRequired(true);

  const prizeInput = new TextInputBuilder()
    .setCustomId('event_prize')
    .setLabel('Приз (необязательно)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('1000 монет, VIP-роль...')
    .setRequired(false);

  const typeInput = new TextInputBuilder()
    .setCustomId('event_type')
    .setLabel('Тип события')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('dice_night / blind_tourney / duel_tourney / fight / custom')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(titleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(descInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(dateInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(prizeInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(typeInput),
  );

  return interaction.showModal(modal);
}

// ─── Обработка модалки создания ───

export async function handleEventCreateModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const serverId = interaction.guild.id;
  const userId = interaction.user.id;

  const title = interaction.fields.getTextInputValue('event_title');
  const description = interaction.fields.getTextInputValue('event_description');
  const dateRaw = interaction.fields.getTextInputValue('event_date');
  const prize = interaction.fields.getTextInputValue('event_prize') || undefined;
  const eventType = interaction.fields.getTextInputValue('event_type') || 'custom';

  // Парсинг даты (формат: ДД.ММ.ГГГГ ЧЧ:ММ)
  const scheduledAt = parseDateMSK(dateRaw);
  if (!scheduledAt) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Неверный формат даты. Используйте: \`ДД.ММ.ГГГГ ЧЧ:ММ\` (например, \`25.02.2026 20:00\`)`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (scheduledAt.getTime() <= Date.now()) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Дата должна быть в будущем.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const config = await getServerConfig(serverId);
  const channelId = config?.announceChannelId ?? undefined;

  const event = await createEvent({
    serverId,
    createdBy: userId,
    title,
    description,
    eventType,
    scheduledAt,
    channelId,
    prize,
  });

  const embed = buildEventAnnouncementEmbed(event);

  const previewEmbed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.SUCCESS} Мероприятие создано!`)
    .setDescription(
      `**#${event.id}** - ${title}\n\n` +
        `Анонс будет автоматически отправлен в канал объявлений.\n` +
        `Напоминания: за 1 час и за 15 минут до начала.\n\n` +
        `Используйте \`/event announce ${event.id}\` для ручного анонса.`,
    )
    .setColor(UI_CONFIG.COLORS.SUCCESS);

  return interaction.reply({ embeds: [previewEmbed, embed], flags: MessageFlags.Ephemeral });
}

// ─── /event list ───

async function handleEventList(interaction: ChatInputCommandInteraction) {
  const serverId = interaction.guild!.id;
  const events = await getUpcomingEvents(serverId);
  const embed = buildEventListEmbed(events);
  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

// ─── /event cancel <id> ───

async function handleEventCancel(interaction: ChatInputCommandInteraction) {
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const eventId = interaction.options.getInteger('id', true);
  const event = await getEventById(eventId);

  if (!event || event.serverId !== interaction.guild!.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие #${eventId} не найдено.`, flags: MessageFlags.Ephemeral });
  }

  if (event.status === 'cancelled' || event.status === 'completed') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.INFO} Событие уже ${event.status === 'cancelled' ? 'отменено' : 'завершено'}.`, flags: MessageFlags.Ephemeral });
  }

  await cancelEvent(eventId);

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Мероприятие **#${eventId}** «${event.title}» отменено.`,
    flags: MessageFlags.Ephemeral,
  });
}

// ─── /event announce <id> ───

async function handleEventAnnounce(interaction: ChatInputCommandInteraction) {
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const eventId = interaction.options.getInteger('id', true);
  const event = await getEventById(eventId);

  if (!event || event.serverId !== interaction.guild!.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие #${eventId} не найдено.` });
  }

  const client = getLogClient();
  if (!client) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Бот не инициализирован.` });
  }

  const ok = await forceAnnounceEvent(client, eventId);
  if (!ok) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Не удалось отправить анонс. Проверьте канал объявлений.` });
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Анонс мероприятия **#${eventId}** «${event.title}» отправлен!`,
  });
}

// ─── /event broadcast - выбор шаблона ───

async function handleBroadcastSelect(interaction: ChatInputCommandInteraction) {
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const options = Object.entries(BROADCAST_TEMPLATES).map(([key, tpl]) => ({
    label: tpl.label,
    value: key,
    emoji: tpl.emoji,
  }));

  const select = new StringSelectMenuBuilder()
    .setCustomId('event:broadcastSelect')
    .setPlaceholder('Выберите шаблон рассылки...')
    .addOptions(options);

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);

  return interaction.reply({
    content: '📢 Выберите шаблон для рассылки в канал объявлений:',
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

// ─── Обработка select-menu шаблона ───

export async function handleBroadcastSelectMenu(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  const templateKey = interaction.values[0];
  const template = BROADCAST_TEMPLATES[templateKey];
  if (!template) {
    return interaction.update({ content: `${UI_CONFIG.EMOJI.ERROR} Шаблон не найден.`, components: [] });
  }

  // Показываем превью с кнопкой подтверждения
  const embed = template.build();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`event:confirmBroadcast:${templateKey}`)
      .setLabel('Отправить в канал')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('event:cancelBroadcast')
      .setLabel('Отмена')
      .setStyle(ButtonStyle.Secondary),
  );

  return interaction.update({ content: '**Превью рассылки:**', embeds: [embed], components: [row] });
}

// ─── Обработка кнопок event ───

export async function handleEventButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const { customId } = interaction;

  if (customId.startsWith('event:signUp:')) {
    const eventId = customId.replace('event:signUp:', '');
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка на бой **#${eventId}** учтена. Ожидайте подтверждения от модераторов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId.startsWith('event:unsign:')) {
    const eventId = customId.replace('event:unsign:', '');
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Заявка на бой **#${eventId}** отменена.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (customId.startsWith('event:confirmBroadcast:')) {
    const templateKey = customId.replace('event:confirmBroadcast:', '');
    const client = getLogClient();
    if (!client) {
      return interaction.update({ content: `${UI_CONFIG.EMOJI.ERROR} Бот не инициализирован.`, embeds: [], components: [] });
    }

    const ok = await broadcastTemplate(client, interaction.guild.id, templateKey);
    if (!ok) {
      return interaction.update({
        content: `${UI_CONFIG.EMOJI.ERROR} Не удалось отправить. Проверьте, что настроен канал объявлений (\`/settings\`).`,
        embeds: [],
        components: [],
      });
    }

    return interaction.update({
      content: `${UI_CONFIG.EMOJI.SUCCESS} Рассылка «${BROADCAST_TEMPLATES[templateKey]?.label}» отправлена!`,
      embeds: [],
      components: [],
    });
  }

  if (customId === 'event:cancelBroadcast') {
    return interaction.update({ content: 'Отменено.', embeds: [], components: [] });
  }
}

// ─── Арена: кнопка [Создать событие] → выбор типа → форма → пост в арену ───

export async function handleArenaCreateEventButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const options = Object.entries(ARENA_EVENT_TYPES).map(([value, t]) => ({
    label: t.label,
    value,
    emoji: t.emoji,
  }));

  const select = new StringSelectMenuBuilder()
    .setCustomId('arena:createSelect')
    .setPlaceholder('Выберите тип мероприятия...')
    .addOptions(options);

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);

  return interaction.reply({
    content: 'Выберите тип мероприятия:',
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleArenaCreateSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  const eventType = interaction.values[0];
  const meta = ARENA_EVENT_TYPES[eventType];
  if (!meta) {
    return interaction.update({ content: `${UI_CONFIG.EMOJI.ERROR} Неизвестный тип.`, components: [] });
  }

  if (eventType === 'team_fight') {
    const select = new StringSelectMenuBuilder()
      .setCustomId('arena:createTeamSizeSelect:team_fight')
      .setPlaceholder('Размер команд (2v2, 3v3 … 10v10)')
      .addOptions(
        [2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => ({
          label: `${n} на ${n}`,
          value: String(n),
          description: `${n} человек в команде`,
        })),
      );
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
    return interaction.update({
      content: '**Командные бои** — выберите размер команд:',
      components: [row],
    });
  }

  return showCreateArenaModal(interaction, eventType);
}

async function showCreateArenaModal(interaction: StringSelectMenuInteraction | ButtonInteraction, eventType: string) {
  const meta = ARENA_EVENT_TYPES[eventType] ?? { label: eventType };
  const modal = new ModalBuilder()
    .setCustomId(`event:createArenaModal:${eventType}`)
    .setTitle(`Создать: ${meta.label}`);

  const titleInput = new TextInputBuilder()
    .setCustomId('arena_title')
    .setLabel('Название турнира')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Белый флаг — этап 1')
    .setMaxLength(100)
    .setRequired(true);

  const dateInput = new TextInputBuilder()
    .setCustomId('arena_date')
    .setLabel('Когда бой (ДД.ММ.ГГГГ ЧЧ:ММ, МСК)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('25.02.2026 20:00')
    .setRequired(true);

  const entryInput = new TextInputBuilder()
    .setCustomId('arena_entryFee')
    .setLabel('Стартовый взнос для участия (септимы)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('100')
    .setRequired(true);

  const coverInput = new TextInputBuilder()
    .setCustomId('arena_cover')
    .setLabel('Обложка (URL картинки)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('https://...')
    .setRequired(false);

  const placeOrTeamInput = new TextInputBuilder()
    .setCustomId('arena_placeOrTeam')
    .setLabel(eventType === 'team_fight' ? 'Место события (опц.)' : 'Место или размер команды (опц.)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(eventType === 'team_fight' ? 'Арена, голосовой' : 'Арена — или число 2 для 2v2')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(titleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(dateInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(entryInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(coverInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(placeOrTeamInput),
  );

  return interaction.showModal(modal);
}

export async function handleArenaCreateTeamSizeSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/arena:createTeamSizeSelect:(.+)/);
  const eventType = match?.[1] ?? 'team_fight';
  const teamSize = parseInt(interaction.values[0] ?? '2', 10);
  if (Number.isNaN(teamSize) || teamSize < 2 || teamSize > 10) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Размер команды: от 2 до 10.`, flags: MessageFlags.Ephemeral });
  }

  await redis.set(`arena:createDraft:${interaction.user.id}`, JSON.stringify({ eventType, teamSize }), 'EX', ARENA_DRAFT_TTL);
  return showCreateArenaModal(interaction, eventType);
}

export async function handleEventCreateArenaModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const customId = interaction.customId;
  const eventType = customId.replace('event:createArenaModal:', '');
  const title = interaction.fields.getTextInputValue('arena_title').trim();
  const dateRaw = interaction.fields.getTextInputValue('arena_date').trim();
  const entryRaw = interaction.fields.getTextInputValue('arena_entryFee').trim();
  const coverUrl = interaction.fields.getTextInputValue('arena_cover')?.trim() || null;
  const placeOrTeam = interaction.fields.getTextInputValue('arena_placeOrTeam')?.trim() || '';
  let teamSize: bigint | null = null;
  let place: string | null = null;

  const draftRaw = await redis.get(`arena:createDraft:${interaction.user.id}`);
  if (eventType === 'team_fight' && draftRaw) {
    try {
      const draft = JSON.parse(draftRaw) as { eventType?: string; teamSize?: number };
      if (draft.teamSize != null && draft.teamSize >= 2 && draft.teamSize <= 10) {
        teamSize = BigInt(draft.teamSize);
      }
      await redis.del(`arena:createDraft:${interaction.user.id}`);
    } catch {
      await redis.del(`arena:createDraft:${interaction.user.id}`);
    }
    place = placeOrTeam || null;
  } else {
    const isOnlyNumber = /^\d+$/.test(placeOrTeam);
    const teamSizeRaw = isOnlyNumber ? parseInt(placeOrTeam, 10) : null;
    teamSize = teamSizeRaw != null && !Number.isNaN(teamSizeRaw) && teamSizeRaw >= 2 && teamSizeRaw <= 100
      ? BigInt(teamSizeRaw) : null;
    place = isOnlyNumber ? null : (placeOrTeam || null);
  }

  const scheduledAt = parseDateMSK(dateRaw);
  if (!scheduledAt) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Неверный формат даты. Используйте: ДД.ММ.ГГГГ ЧЧ:ММ (например 25.02.2026 20:00)`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (scheduledAt.getTime() <= Date.now()) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Дата должна быть в будущем.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const entryFee = parseInt(entryRaw, 10);
  if (Number.isNaN(entryFee) || entryFee < 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректный стартовый взнос (число ≥ 0).`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const config = await getServerConfig(interaction.guild.id) as { arenaChannelId?: string | null; eventsChannelId?: string | null };
  const arenaChannelId = config?.arenaChannelId ?? null;
  const eventsChannelId = config?.eventsChannelId ?? null;
  const isPokerOrTug = eventType === 'poker_tournament' || eventType === 'tug';
  const announceChannelId = isPokerOrTug ? (eventsChannelId ?? arenaChannelId) : arenaChannelId;

  const event = await createEvent({
    serverId: interaction.guild.id,
    createdBy: interaction.user.id,
    title,
    description: ARENA_EVENT_TYPES[eventType]?.label ?? eventType,
    eventType,
    scheduledAt,
    channelId: announceChannelId ?? undefined,
    entryFee: entryFee || null,
    coverImageUrl: coverUrl,
    teamSize,
    place,
  });

  const client = getLogClient();
  let announceSent = false;
  if (client && announceChannelId) {
    announceSent = (await sendArenaAnnounce(client, {
      id: event.id,
      title: event.title,
      eventType: event.eventType,
      scheduledAt: event.scheduledAt,
      entryFee: event.entryFee != null ? Number(event.entryFee) : null,
      coverImageUrl: event.coverImageUrl,
      serverId: event.serverId,
      place: event.place,
      discordScheduledEventId: event.discordScheduledEventId,
    })) != null;
    await sendOrUpdateAdminManagement(client, event.id);
  } else if (client) {
    await sendOrUpdateAdminManagement(client, event.id);
  }

  const channelHint = !announceChannelId
    ? ' Настройте канал арены или событий в Настройках.'
    : announceSent
      ? ` Анонс отправлен в канал ${isPokerOrTug ? 'событий' : 'арены'}.`
      : '';

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Мероприятие **#${event.id}** «${title}» создано.${channelHint}`,
    flags: MessageFlags.Ephemeral,
  });
}

// ─── Записаться на турнир / Отказаться ───

/** Для командного боя: сначала выбор роли (лидер/член). */
export async function handleArenaSignUpButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const eventId = parseInt(interaction.customId.replace('arena:signUp:', ''), 10);
  if (Number.isNaN(eventId)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.`, flags: MessageFlags.Ephemeral });
  }

  if (event.eventType === 'team_fight') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`arena:signUpRole:${eventId}:leader`)
        .setLabel('Лидер команды')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`arena:signUpRole:${eventId}:member`)
        .setLabel('Член команды')
        .setStyle(ButtonStyle.Secondary),
    );
    return interaction.editReply({
      content: '**Командный бой** — выберите роль:\n• **Лидер команды** — создать новую команду\n• **Член команды** — записаться в существующую команду',
      components: [row],
    });
  }

  const modal = new ModalBuilder()
    .setCustomId(`arena:signUpModal:${eventId}`)
    .setTitle('Запись на турнир');
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('name').setLabel('Имя').setStyle(TextInputStyle.Short).setPlaceholder('Имя персонажа или ник').setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('primeTime').setLabel('Прайм тайм').setStyle(TextInputStyle.Short).setPlaceholder('Когда удобно').setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('weaponType').setLabel('Тип оружия').setStyle(TextInputStyle.Short).setPlaceholder('Меч, лук...').setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('armorType').setLabel('Тип брони').setStyle(TextInputStyle.Short).setPlaceholder('Лёгкая, тяжёлая...').setRequired(false),
    ),
  );
  return interaction.showModal(modal);
}

/** Лидер команды → модал с названием команды. Член команды → меню выбора команды. */
export async function handleArenaSignUpRoleButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/arena:signUpRole:(\d+):(leader|member)/);
  const eventId = match ? parseInt(match[1], 10) : 0;
  const role = match?.[2];

  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.`, flags: MessageFlags.Ephemeral });
  }
  if (event.eventType !== 'team_fight') return;

  if (role === 'leader') {
    const modal = new ModalBuilder()
      .setCustomId(`arena:signUpLeaderModal:${eventId}`)
      .setTitle('Лидер команды — создание команды');
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId('teamName').setLabel('Название команды (идёт в рейтинг)').setStyle(TextInputStyle.Short).setPlaceholder('Крысиная братва').setRequired(true),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId('name').setLabel('Имя').setStyle(TextInputStyle.Short).setPlaceholder('Имя персонажа или ник').setRequired(true),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId('primeTime').setLabel('Прайм тайм').setStyle(TextInputStyle.Short).setPlaceholder('Когда удобно').setRequired(false),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId('weaponType').setLabel('Тип оружия').setStyle(TextInputStyle.Short).setPlaceholder('Меч, лук...').setRequired(false),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId('armorType').setLabel('Тип брони').setStyle(TextInputStyle.Short).setPlaceholder('Лёгкая, тяжёлая...').setRequired(false),
      ),
    );
    return interaction.showModal(modal);
  }

  if (role === 'member') {
    const teams = await getEventTeamNames(eventId);
    if (teams.length === 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.INFO} Пока нет зарегистрированных команд. Создайте команду как **лидер** или дождитесь, пока кто-то создаст.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    const select = new StringSelectMenuBuilder()
      .setCustomId(`arena:signUpTeamSelect:${eventId}`)
      .setPlaceholder('Выберите команду')
      .addOptions(teams.slice(0, 25).map((t) => ({ label: t, value: t.slice(0, 100) })));
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
    return interaction.reply({
      content: 'Выберите команду, в которую хотите записаться:',
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }
}

/** Член команды выбрал команду → модал с данными (teamName в customId). */
export async function handleArenaSignUpTeamSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/arena:signUpTeamSelect:(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : 0;
  const teamName = interaction.values[0]?.trim();
  if (!teamName) return;

  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.`, flags: MessageFlags.Ephemeral });
  }

  const safeTeam = Buffer.from(teamName, 'utf8').toString('base64url').slice(0, 60);
  const modal = new ModalBuilder()
    .setCustomId(`arena:signUpMemberModal:${eventId}:${safeTeam}`)
    .setTitle('Член команды — запись');
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('name').setLabel('Имя').setStyle(TextInputStyle.Short).setPlaceholder('Имя персонажа или ник').setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('primeTime').setLabel('Прайм тайм').setStyle(TextInputStyle.Short).setPlaceholder('Когда удобно').setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('weaponType').setLabel('Тип оружия').setStyle(TextInputStyle.Short).setPlaceholder('Меч, лук...').setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId('armorType').setLabel('Тип брони').setStyle(TextInputStyle.Short).setPlaceholder('Лёгкая, тяжёлая...').setRequired(false),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleArenaSignUpModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const eventId = parseInt(interaction.customId.replace('arena:signUpModal:', ''), 10);
  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.` });
  }

  const entryFee = event.entryFee != null ? Number(event.entryFee) : 0;
  const userId = interaction.user.id;
  const profile = await getOrCreateProfile(interaction.guild.id, userId);
  if (profile.balance < BigInt(entryFee)) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Взнос: ${entryFee}.`,
    });
  }

  const existing = await getEventParticipants(eventId);
  if (existing.some((p) => p.userId === userId)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Вы уже записаны.` });
  }

  const name = interaction.fields.getTextInputValue('name')?.trim() || null;
  const primeTime = interaction.fields.getTextInputValue('primeTime')?.trim() || null;
  const weaponType = (() => {
    try { return interaction.fields.getTextInputValue('weaponType')?.trim() || null; } catch { return null; }
  })();
  const armorType = (() => {
    try { return interaction.fields.getTextInputValue('armorType')?.trim() || null; } catch { return null; }
  })();

  await adjustBalance({ serverId: interaction.guild.id, userId, delta: -entryFee, reason: `arena_event_${eventId}_entry` });
  await addEventParticipant(eventId, { userId, name, primeTime, weaponType, armorType, paidAmount: entryFee, teamName: null });

  const client = getLogClient();
  if (client) {
    await sendAdminSignUpNotification(client, interaction.guild.id, eventId, event.title, userId, name);
    await updateAdminManagementOnly(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы записаны на **${event.title}**. Взнос ${entryFee} септимов списан. Деньги при отказе не возвращаются.`,
  });
}

export async function handleArenaSignUpLeaderModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const match = interaction.customId.match(/arena:signUpLeaderModal:(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : 0;
  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.` });
  }
  if (event.eventType !== 'team_fight') return;

  const entryFee = event.entryFee != null ? Number(event.entryFee) : 0;
  const userId = interaction.user.id;
  const profile = await getOrCreateProfile(interaction.guild.id, userId);
  if (profile.balance < BigInt(entryFee)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Взнос: ${entryFee}.` });
  }
  const existing = await getEventParticipants(eventId);
  if (existing.some((p) => p.userId === userId)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Вы уже записаны.` });
  }

  const teamName = interaction.fields.getTextInputValue('teamName')?.trim() || null;
  const name = interaction.fields.getTextInputValue('name')?.trim() || null;
  const primeTime = interaction.fields.getTextInputValue('primeTime')?.trim() || null;
  const weaponType = interaction.fields.getTextInputValue('weaponType')?.trim() || null;
  const armorType = interaction.fields.getTextInputValue('armorType')?.trim() || null;

  if (!teamName || teamName.length > 50) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Укажите название команды (до 50 символов).` });
  }

  await adjustBalance({ serverId: interaction.guild.id, userId, delta: -entryFee, reason: `arena_event_${eventId}_entry` });
  await addEventParticipant(eventId, { userId, name, primeTime, weaponType, armorType, paidAmount: entryFee, teamName });

  const client = getLogClient();
  if (client) {
    await sendAdminSignUpNotification(client, interaction.guild.id, eventId, event.title, userId, `${name} (лидер «${teamName}»)`);
    await updateAdminManagementOnly(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы записаны как **лидер команды «${teamName}»** на **${event.title}**. Взнос ${entryFee} септимов списан.\n_➕ Добавлена новая команда._`,
  });
}

export async function handleArenaSignUpMemberModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const match = interaction.customId.match(/arena:signUpMemberModal:(\d+):([A-Za-z0-9_-]+)/);
  const eventId = match ? parseInt(match[1], 10) : 0;
  const teamNameEnc = match?.[2];
  let teamName = '';
  try {
    teamName = teamNameEnc ? Buffer.from(teamNameEnc, 'base64url').toString('utf8') : '';
  } catch {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка данных. Попробуйте снова.` });
  }

  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или запись закрыта.` });
  }
  if (event.eventType !== 'team_fight') return;

  const entryFee = event.entryFee != null ? Number(event.entryFee) : 0;
  const userId = interaction.user.id;
  const profile = await getOrCreateProfile(interaction.guild.id, userId);
  if (profile.balance < BigInt(entryFee)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Взнос: ${entryFee}.` });
  }
  const existing = await getEventParticipants(eventId);
  if (existing.some((p) => p.userId === userId)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Вы уже записаны.` });
  }

  const teams = await getEventTeamNames(eventId);
  if (!teams.includes(teamName)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Команда «${teamName}» больше не найдена. Выберите другую.` });
  }

  const name = interaction.fields.getTextInputValue('name')?.trim() || null;
  const primeTime = interaction.fields.getTextInputValue('primeTime')?.trim() || null;
  const weaponType = interaction.fields.getTextInputValue('weaponType')?.trim() || null;
  const armorType = interaction.fields.getTextInputValue('armorType')?.trim() || null;

  await adjustBalance({ serverId: interaction.guild.id, userId, delta: -entryFee, reason: `arena_event_${eventId}_entry` });
  await addEventParticipant(eventId, { userId, name, primeTime, weaponType, armorType, paidAmount: entryFee, teamName });

  const client = getLogClient();
  if (client) {
    await sendAdminSignUpNotification(client, interaction.guild.id, eventId, event.title, userId, `${name} (команда «${teamName}»)`);
    await updateAdminManagementOnly(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Вы записаны в команду **«${teamName}»** на **${event.title}**. Взнос ${entryFee} септимов списан.\n_➖ Присоединились к существующей команде._`,
  });
}

export async function handleArenaUnsignButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const eventId = parseInt(interaction.customId.replace('arena:unsign:', ''), 10);
  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.` });
  }
  if (event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Запись закрыта.` });
  }

  const deleted = await removeEventParticipant(eventId, interaction.user.id);
  if (deleted.count === 0) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Вы не были записаны.` });
  }

  const client = getLogClient();
  if (client) {
    await updateAdminManagementOnly(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.INFO} Вы сняты с турнира. Взнос не возвращается.`,
  });
}

export async function handleArenaAdminStart(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const eventId = parseInt(interaction.customId.replace('arena:adminStart:', ''), 10);
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или уже начато.` });
  }

  if (event.eventType === 'team_fight') {
    const byTeam = new Map<string, typeof event.participants>();
    for (const p of event.participants) {
      const team = (p as { teamName?: string | null }).teamName?.trim() || 'Без команды';
      if (!byTeam.has(team)) byTeam.set(team, []);
      byTeam.get(team)!.push(p);
    }
    const teamsWithAtLeastOne = Array.from(byTeam.values()).filter((arr) => arr.length >= 1);
    if (teamsWithAtLeastOne.length < 2) {
      return interaction.editReply({
        content: `${UI_CONFIG.EMOJI.ERROR} Для старта командного боя нужны **минимум 2 команды**, в каждой — хотя бы 1 участник. Сейчас команд: **${teamsWithAtLeastOne.length}**.`,
      });
    }
  }

  const configForChannels = await getServerConfig(interaction.guild.id) as { arenaChannelId?: string | null; eventsChannelId?: string | null };
  const arenaChId = configForChannels?.arenaChannelId ?? null;
  const eventsChId = configForChannels?.eventsChannelId ?? null;
  const isPokerOrTug = event.eventType === 'poker_tournament' || event.eventType === 'tug';
  const postChannelId = isPokerOrTug ? eventsChId : arenaChId;
  if (!postChannelId) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} ${isPokerOrTug ? 'Канал событий' : 'Канал арены'} не настроен.`,
    });
  }

  const participantIds = event.participants.map((p) => p.id).sort((a, b) => a - b);
  const bracketState = initBracketState(participantIds);

  await prisma.event.update({
    where: { id: eventId },
    data: { status: 'active', bracketState: bracketState as unknown as object },
  });

  const embedArena = buildArenaStartedEmbed({
    title: event.title,
    eventType: event.eventType,
    scheduledAt: event.scheduledAt,
    coverImageUrl: event.coverImageUrl,
    participants: event.participants,
    entryFee: event.entryFee,
    prizePoolBonus: event.prizePoolBonus ?? 0,
  });

  const channel = await interaction.guild.channels.fetch(postChannelId).catch(() => null);
  let publicPostMessageId: string | null = null;
  if (channel?.isTextBased()) {
    const msg = await (channel as import('discord.js').TextChannel).send({ embeds: [embedArena] }).catch(() => null);
    if (msg) {
      publicPostMessageId = msg.id;
      await prisma.event.update({ where: { id: eventId }, data: { arenaStartedMessageId: msg.id, publicPostMessageId: msg.id } });
    }
  }

  if (event.participants.length > 0 && !isPokerOrTug) {
    const { buildArenaBetSelectPayload } = await import('../services/events');
    const payload = buildArenaBetSelectPayload(eventId, event.title, event.participants);
    const betChannel = await interaction.guild.channels.fetch(postChannelId).catch(() => null);
    if (betChannel?.isTextBased()) {
      const betMsg = await (betChannel as import('discord.js').TextChannel).send(payload).catch(() => null);
      if (betMsg) {
        await prisma.event.update({ where: { id: eventId }, data: { arenaBetMessageId: betMsg.id } });
      }
    }
  }

  const client = getLogClient();
  if (client) {
    await sendOrUpdateAdminManagement(client, eventId);
    await postEventStartedToAdminThread(client, eventId, embedArena);
  }

  const channelName = isPokerOrTug ? 'событий' : 'арены';
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Событие **${event.title}** запущено. Пост в канал ${channelName} отправлен.${!isPokerOrTug ? ' В админ-канале отображается текущий бой.' : ''}`,
  });
}

export async function handleArenaAdminEquipment(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const eventId = parseInt(interaction.customId.replace('arena:adminEquipment:', ''), 10);
  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.`, flags: MessageFlags.Ephemeral });
  }

  const participants = await getEventParticipants(eventId);

  const blocks: string[] = [];
  for (let i = 0; i < participants.length; i++) {
    const p = participants[i];
    const name = p.name?.trim() || 'Участник';
    const armor = (p.armorType?.trim() || '—');
    const weapon = (p.weaponType?.trim() || '—');
    const time = (p.primeTime?.trim() || '—');
    blocks.push(
      `**${name}** <@${p.userId}>`,
      `🛡️ Броня: ${armor}`,
      `⚔️ Оружие: ${weapon}`,
      `🕐 Удобное время: ${time}`,
    );
    if (i < participants.length - 1) blocks.push('――――――――――――――――――――');
  }
  const description = participants.length === 0
    ? '_Нет участников._'
    : blocks.join('\n');

  const embed = new EmbedBuilder()
    .setTitle(`# Снаряжение — ${event.title}`)
    .setDescription(description)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setFooter({ text: 'Данные из анкеты при записи' });

  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

export async function handleArenaAdminExportExcel(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const eventId = parseInt(interaction.customId.replace('arena:adminExportExcel:', ''), 10);
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const { getDailyExportFilePath, appendEventToDailyFile } = await import('../services/excelExport');
  let filePath = getDailyExportFilePath(interaction.guild.id);

  if (!filePath) {
    const totalPool = event.participants.length * (event.entryFee != null ? Number(event.entryFee) : 0) + (event.prizePoolBonus ?? 0);
    appendEventToDailyFile(interaction.guild.id, {
      id: event.id,
      title: event.title,
      eventType: event.eventType,
      completedAt: event.completedAt,
      participants: event.participants.map((p) => ({
        userId: p.userId,
        name: p.name,
        armorType: p.armorType,
        weaponType: p.weaponType,
        primeTime: p.primeTime,
        paidAmount: p.paidAmount ?? 0,
      })),
      entryFee: event.entryFee != null ? Number(event.entryFee) : null,
      totalPool,
      totalExpenses: event.totalExpenses,
    });
    filePath = getDailyExportFilePath(interaction.guild.id);
  }
  if (!filePath) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Не удалось создать файл выгрузки.`,
    });
  }

  const { AttachmentBuilder } = await import('discord.js');
  const fileName = `мероприятия_${new Date().toISOString().slice(0, 10)}.xlsx`;
  const attachment = new AttachmentBuilder(filePath, { name: fileName });

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Выгрузка за сегодня. Данные накапливаются в одном файле, завтра будет новый.`,
    files: [attachment],
  });
}

export async function handleArenaAdminEditList(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const eventId = parseInt(interaction.customId.replace('arena:adminEditList:', ''), 10);
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.` });
  }
  if (event.status !== 'scheduled') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Запись закрыта. Снимать участников можно только до начала турнира.` });
  }
  if (event.participants.length === 0) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.INFO} Нет участников для снятия.` });
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId(`arena:adminRemoveParticipant:${eventId}`)
    .setPlaceholder('Выберите участника для снятия с турнира')
    .addOptions(
      event.participants.map((p) => ({
        label: (p.name?.trim() || `Участник`).slice(0, 100),
        value: `${eventId}:${p.userId}`,
        description: `ID: ${p.userId}`,
      })),
    );
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.INFO} Выберите участника, которого нужно снять с турнира:`,
    components: [row],
  });
}

export async function handleArenaAdminRemoveParticipantSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const customId = interaction.customId;
  const eventId = parseInt(customId.replace('arena:adminRemoveParticipant:', ''), 10);
  const value = interaction.values[0];
  if (!value) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Выберите участника.`, flags: MessageFlags.Ephemeral });
  }
  const [, userId] = value.split(':');
  if (!userId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка данных.`, flags: MessageFlags.Ephemeral });
  }

  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.`, flags: MessageFlags.Ephemeral });
  }
  if (event.status !== 'scheduled') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Запись закрыта.`, flags: MessageFlags.Ephemeral });
  }

  const deleted = await removeEventParticipant(eventId, userId);
  if (deleted.count === 0) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} Участник уже снят или не был записан.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const client = getLogClient();
  if (client) {
    await updateAdminManagementOnly(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Участник <@${userId}> снят с турнира. Взнос не возвращается.`,
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleArenaAdminAddPrize(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const eventId = interaction.customId.replace('arena:adminAddPrize:', '');
  const modal = new ModalBuilder()
    .setCustomId(`arena:adminAddPrizeModal:${eventId}`)
    .setTitle('Добавить к выигрышу');

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('bonus')
        .setLabel('Сумма бонуса (септимы)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('500')
        .setRequired(true),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleArenaAdminAddPrizeModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/arena:adminAddPrizeModal:(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : NaN;
  const bonusRaw = interaction.fields.getTextInputValue('bonus').trim();
  const bonus = parseInt(bonusRaw, 10);

  if (Number.isNaN(eventId) || Number.isNaN(bonus) || bonus < 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.` });
  }

  const currentBonus = event.prizePoolBonus ?? 0;
  await prisma.event.update({
    where: { id: eventId },
    data: { prizePoolBonus: currentBonus + bonus },
  });

  const client = getLogClient();
  if (client) {
    await sendOrUpdateAdminManagement(client, eventId);
    await updateArenaAnnounce(client, eventId);
  }

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} К призовому фонду добавлено ${bonus} септимов.`,
  });
}

export async function handleArenaAdminComplete(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }
  const eventId = parseInt(interaction.customId.replace('arena:adminComplete:', ''), 10);
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.`, flags: MessageFlags.Ephemeral });
  }
  if (event.status === 'completed') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.INFO} Событие уже завершено.`, flags: MessageFlags.Ephemeral });
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  await prisma.event.update({
    where: { id: eventId },
    data: { status: 'completed', completedAt: new Date() },
  });
  const client = getLogClient();
  if (client) {
    await deleteArenaBetMessage(client, eventId);
    await runSettlementForEvent(client, eventId);
  }
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Событие **${event.title}** завершено. Смета отправлена в канал выдачи.`,
  });
}

export async function handleArenaAdminAddExpense(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }
  const eventId = interaction.customId.replace('arena:adminAddExpense:', '');
  const modal = new ModalBuilder()
    .setCustomId(`arena:adminAddExpenseModal:${eventId}`)
    .setTitle('Добавить расход');
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('Сумма (септимы)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('500')
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Причина (опционально)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('призы, выпивка, донат')
        .setRequired(false),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleArenaAdminAddExpenseModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const match = interaction.customId.match(/arena:adminAddExpenseModal:(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : NaN;
  const amountRaw = interaction.fields.getTextInputValue('amount')?.trim() ?? '0';
  const reason = interaction.fields.getTextInputValue('reason')?.trim() ?? '';
  const amount = parseInt(amountRaw, 10);
  if (Number.isNaN(eventId) || Number.isNaN(amount) || amount < 0) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму.` });
  }
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.` });
  }
  const current = event.totalExpenses ?? 0;
  await prisma.event.update({
    where: { id: eventId },
    data: { totalExpenses: current + amount },
  });
  const client = getLogClient();
  if (client && event.adminThreadId) {
    const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
    if (thread?.isTextBased()) {
      const text = reason ? `Расход зафиксирован: **${amount}** септимов (${reason}).` : `Расход зафиксирован: **${amount}** септимов.`;
      await thread.send({ content: text }).catch(() => {});
    }
  }
  if (client) await sendOrUpdateAdminManagement(client, eventId);
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Расход ${amount} септимов добавлен.${reason ? ` Причина: ${reason}` : ''}`,
  });
}

export async function handleArenaAdminSettle(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }
  const eventId = parseInt(interaction.customId.replace('arena:adminSettle:', ''), 10);
  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено.`, flags: MessageFlags.Ephemeral });
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const client = getLogClient();
  if (!client) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Сервис недоступен.` });
  }
  const sent = await runSettlementForEvent(client, eventId);
  if (!sent) {
    return interaction.editReply({
      content: event.settlementSent
        ? `${UI_CONFIG.EMOJI.INFO} Итог по этому мероприятию уже был сформирован.`
        : `${UI_CONFIG.EMOJI.ERROR} Канал выдачи не настроен. Настройте в /settings.`,
    });
  }
  if (event.adminThreadId) {
    const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
    if (thread?.isTextBased()) {
      await thread.send({ content: '**Итог сформирован и отправлен в канал выдачи.**' }).catch(() => {});
    }
  }
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Итог по мероприятию **${event.title}** сформирован и отправлен в канал выдачи.`,
  });
}

export async function handleArenaBetSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;
  const eventId = parseInt(interaction.customId.replace('arena:betSelect:', ''), 10);
  const participantIdRaw = interaction.values[0];
  if (Number.isNaN(eventId) || !participantIdRaw || participantIdRaw === '0') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка выбора.`, flags: MessageFlags.Ephemeral });
  }
  const participantId = parseInt(participantIdRaw, 10);
  if (Number.isNaN(participantId)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  const event = await getEventById(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'active') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Турнир не найден или уже завершён.`, flags: MessageFlags.Ephemeral });
  }

  const modal = new ModalBuilder()
    .setCustomId(`arena:betModal:${eventId}:${participantId}`)
    .setTitle('Ставка на бойца');

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('Сумма ставки (септимы)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('100 (макс. 5000)')
        .setRequired(true),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleArenaBetModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/arena:betModal:(\d+):(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : NaN;
  const participantId = match ? parseInt(match[2], 10) : NaN;
  const amountRaw = interaction.fields.getTextInputValue('amount')?.trim() ?? '';
  const amount = parseInt(amountRaw, 10);

  const ARENA_BET_MAX = 5000;
  if (Number.isNaN(eventId) || Number.isNaN(participantId) || Number.isNaN(amount) || amount < 1) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму.`, flags: MessageFlags.Ephemeral });
  }
  if (amount > ARENA_BET_MAX) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Максимальная ставка на турнир — **${ARENA_BET_MAX}** септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'active') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Турнир не найден или уже завершён.` });
  }
  const participant = event.participants.find((p) => p.id === participantId);
  if (!participant) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Участник не найден.` });
  }

  const userId = interaction.user.id;
  const profile = await getOrCreateProfile(interaction.guild.id, userId);
  if (profile.balance < BigInt(amount)) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance} септимов.`,
    });
  }

  const existing = await prisma.eventBet.findUnique({
    where: { eventId_userId: { eventId, userId } },
  });
  if (existing) {
    return interaction.editReply({
      content: `${UI_CONFIG.EMOJI.INFO} Вы уже сделали ставку на этот турнир. Одна ставка на одного бойца за турнир.`,
    });
  }

  await prisma.eventBet.create({
    data: { eventId, participantId, userId, amount },
  });
  await adjustBalance({
    serverId: interaction.guild.id,
    userId,
    delta: -amount,
    reason: `arena_bet_${eventId}`,
  });

  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Ставка **${amount}** септимов на бойца принята. При его победе в бою получите **${amount * 2}** септимов.`,
  });
}

export async function handleArenaAdminWinner(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const match = interaction.customId.match(/arena:adminWinner:(\d+):(\d+)/);
  const eventId = match ? parseInt(match[1], 10) : NaN;
  const winnerParticipantId = match ? parseInt(match[2], 10) : NaN;
  if (Number.isNaN(eventId) || Number.isNaN(winnerParticipantId)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const event = await getEventWithParticipants(eventId);
  if (!event || event.serverId !== interaction.guild.id || event.status !== 'active') {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Событие не найдено или не активно.` });
  }
  const state = event.bracketState as BracketState | null;
  if (!state) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Нет сетки турнира.` });
  }
  const pair = getCurrentPair(state);
  if (!pair || !pair.includes(winnerParticipantId)) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Этот участник не в текущей паре.` });
  }

  const winnerParticipant = event.participants.find((p) => p.id === winnerParticipantId);
  if (!winnerParticipant) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Участник не найден.` });
  }

  const fightNumber = getFightNumber(state);
  const serverId = interaction.guild.id;
  const client = getLogClient();

  // Похоронный бой: проигравший не получает выплат со ставок (мёртв — 0 септимов и всё)
  const loserParticipantId = pair.find((id) => id !== winnerParticipantId);
  const loserParticipant = loserParticipantId != null ? event.participants.find((p) => p.id === loserParticipantId) : null;
  const funeralLoserUserId = event.eventType === 'funeral_fight' && loserParticipant ? loserParticipant.userId : null;

  const bets = await prisma.eventBet.findMany({
    where: { eventId, participantId: winnerParticipantId, paid: false },
  });
  const payouts: { userId: string; amount: number }[] = [];
  for (const bet of bets) {
    if (funeralLoserUserId && bet.userId === funeralLoserUserId) {
      // Проигравший в похоронном — не платим, ставка сгорает и идёт в бизнес
      const { creditAdminBusinessBalance } = await import('../config/serverConfigService');
      await creditAdminBusinessBalance(serverId, bet.amount);
      continue;
    }
    const payoutAmount = bet.amount * 2;
    await adjustBalance({
      serverId,
      userId: bet.userId,
      delta: payoutAmount,
      reason: `arena_bet_win_${eventId}`,
    });
    payouts.push({ userId: bet.userId, amount: payoutAmount });
    await prisma.eventBet.update({ where: { id: bet.id }, data: { paid: true } });
  }

  // Проигрышные ставки (на проигравшего бойца) идут в казино / бизнес
  if (loserParticipantId != null) {
    const losingBets = await prisma.eventBet.findMany({
      where: { eventId, participantId: loserParticipantId },
    });
    const totalLost = losingBets.reduce((s, b) => s + b.amount, 0);
    if (totalLost > 0) {
      const { creditAdminBusinessBalance } = await import('../config/serverConfigService');
      await creditAdminBusinessBalance(serverId, totalLost);
    }
  }

  const arenaFightTypes = ['white_flag', 'team_fight', 'funeral_fight'];
  if (arenaFightTypes.includes(event.eventType)) {
    const winnerTeamName = event.eventType === 'team_fight'
      ? ((winnerParticipant as { teamName?: string | null }).teamName?.trim() || null)
      : null;
    await prisma.arenaFightWin.create({
      data: {
        serverId,
        userId: winnerParticipant.userId,
        eventType: event.eventType,
        eventId,
        teamName: winnerTeamName,
      },
    });
  }

  // Похоронный бой — проигравший «умирает»: баланс обнуляется, победы и win streak сбрасываются
  if (event.eventType === 'funeral_fight' && loserParticipant) {
    const profile = await getOrCreateProfile(serverId, loserParticipant.userId);
    if (profile.balance > 0n) {
      await adjustBalance({
        serverId,
        userId: loserParticipant.userId,
        delta: -Number(profile.balance),
        reason: 'funeral_fight_death',
      });
    }
    await prisma.arenaFightWin.deleteMany({
      where: {
        serverId,
        userId: loserParticipant.userId,
        eventType: 'funeral_fight',
      },
    });
  }

  if (client) {
    const winnerTeamName = event.eventType === 'team_fight'
      ? ((winnerParticipant as { teamName?: string | null }).teamName?.trim() || null)
      : null;
    await postFightResultToArena(client, serverId, event.title, fightNumber, winnerParticipant.userId, winnerTeamName);
    await sendPayoutLogToAccounting(client, serverId, payouts, eventId);
  }

  const newState = advanceBracket(state, winnerParticipantId);
  const round = newState.rounds[newState.roundIndex];
  const isChampion = round?.length === 1;

  await prisma.event.update({
    where: { id: eventId },
    data: {
      bracketState: newState as unknown as object,
      ...(isChampion ? { status: 'completed', completedAt: new Date() } : {}),
    },
  });

  if (client) {
    if (isChampion) {
      await deleteArenaBetMessage(client, eventId);
      await runSettlementForEvent(client, eventId);
    } else {
      await sendOrUpdateAdminManagement(client, eventId);
    }
    const { updateRatingMessage } = await import('./top');
    await updateRatingMessage(client, serverId);
  }

  const winnerLabel = event.eventType === 'team_fight'
    ? ((winnerParticipant as { teamName?: string | null }).teamName?.trim()
      ? `команда «${(winnerParticipant as { teamName?: string | null }).teamName}» (<@${winnerParticipant.userId}>)`
      : `<@${winnerParticipant.userId}>`)
    : `<@${winnerParticipant.userId}>`;
  return interaction.editReply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Победитель засчитан: ${winnerLabel}.${payouts.length ? ` Выплаты по ставкам отправлены в канал выдачи (${payouts.length} чел.).` : ''}${isChampion ? ' Турнир завершён.' : ''}`,
  });
}

// ─── Утилиты ───

function parseDateMSK(raw: string): Date | null {
  // Формат: ДД.ММ.ГГГГ ЧЧ:ММ
  const match = raw.trim().match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2})$/);
  if (!match) return null;

  const [, day, month, year, hour, minute] = match;
  const d = Number.parseInt(day, 10);
  const m = Number.parseInt(month, 10) - 1;
  const y = Number.parseInt(year, 10);
  const h = Number.parseInt(hour, 10);
  const min = Number.parseInt(minute, 10);

  if (m < 0 || m > 11 || d < 1 || d > 31 || h > 23 || min > 59) return null;

  // Создаём дату в МСК (UTC+3)
  const utcMs = Date.UTC(y, m, d, h - 3, min);
  const date = new Date(utcMs);

  if (Number.isNaN(date.getTime())) return null;
  return date;
}

function isModeratorOrAdmin(interaction: ChatInputCommandInteraction | ButtonInteraction | StringSelectMenuInteraction): boolean {
  const member = interaction.member as GuildMember | null;
  if (!member) return false;
  if (member.permissions.has('Administrator')) return true;
  if (member.permissions.has('ManageGuild')) return true;
  return false;
}
