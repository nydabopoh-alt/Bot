import { prisma } from '../db/client';

export async function getServerConfig(serverId: string) {
  return prisma.serverConfig.findUnique({
    where: { serverId },
    include: {
      roles: true,
      limits: true,
      enabledGames: true,
      channelAccessRules: true,
    },
  });
}

export async function ensureServerConfig(serverId: string) {
  const existing = await getServerConfig(serverId);
  if (existing) return existing;

  return prisma.serverConfig.create({
    data: {
      serverId,
    },
  });
}

export async function updateServerChannels(serverId: string, data: {
  gamesChannelId?: string | null;
  logChannelId?: string | null;
  ratingChannelId?: string | null;
  announceChannelId?: string | null;
  /** Канал админа: меню с кнопкой [Создать событие] */
  adminChannelId?: string | null;
  /** Арена: публикация боёв и турниров */
  arenaChannelId?: string | null;
  /** Канал событий: покер/канат — дублирование анонса */
  eventsChannelId?: string | null;
  eventVoiceChannelId?: string | null;
  /** 🎟️ Канал ставки — игроки: баланс, переводы, кнопки Вывести/Пополнить (тикеты) */
  ticketsChannelId?: string | null;
  /** ⚖️ Канал выдачи — админская бухгалтерия: тикеты и учёт */
  accountingChannelId?: string | null;
  ratingEmbedTitle?: string | null;
  ratingEmbedDescription?: string | null;
  /** ID админа с бизнес-счётом (10% с событий + комиссия игр) */
  adminUserId?: string | null;
}) {
  return prisma.serverConfig.update({
    where: { serverId },
    data,
  });
}

/** Получить бизнес-баланс админа (0 если не настроен). */
export async function getAdminBusinessBalance(serverId: string): Promise<number> {
  const config = await prisma.serverConfig.findUnique({
    where: { serverId },
    select: { adminBusinessBalance: true },
  });
  return config?.adminBusinessBalance ?? 0;
}

/** Зачислить сумму на бизнес-счёт (adminBusinessBalance). Накапливается независимо от adminUserId. */
export async function creditAdminBusinessBalance(serverId: string, amount: number): Promise<void> {
  if (amount <= 0) return;
  await prisma.serverConfig.update({
    where: { serverId },
    data: { adminBusinessBalance: { increment: amount } },
  });
}

export async function updateServerRatingEmbed(serverId: string, data: {
  ratingEmbedTitle?: string | null;
  ratingEmbedDescription?: string | null;
  ratingMessageId?: string | null;
  ratingImage1?: string | null;
  ratingImage2?: string | null;
  ratingImage3?: string | null;
  ratingImage4?: string | null;
  ratingImage5?: string | null;
  autoRatingInterval?: string | null;
  ratingFormatConfig?: object | null;
}) {
  return prisma.serverConfig.update({
    where: { serverId },
    data,
  });
}

/** Обновить конфиг одного формата рейтинга (white_flag, team_fight, funeral_fight). */
export async function updateServerRatingFormatConfig(
  serverId: string,
  eventType: string,
  data: { title?: string; image?: string },
): Promise<void> {
  const config = await getServerConfig(serverId);
  const current = (config as { ratingFormatConfig?: Record<string, { title?: string; image?: string }> | null })?.ratingFormatConfig ?? {};
  const updated = { ...current, [eventType]: { ...(current[eventType] ?? {}), ...data } };
  await prisma.serverConfig.update({
    where: { serverId },
    data: { ratingFormatConfig: updated as object },
  });
}

export async function updateServerEconomy(serverId: string, data: {
  startBalance?: number;
  dailyBonus?: number;
  casinoCommission?: number;
  minBet?: number;
  maxBet?: number;
  bigWinThreshold?: number;
}) {
  return prisma.serverConfig.update({
    where: { serverId },
    data,
  });
}

export async function updateServerRoles(serverId: string, roles: {
  playerRoleId?: string | null;
  moderatorRoleId?: string | null;
  vipRoleId?: string | null;
}) {
  const serverConfig = await ensureServerConfig(serverId);

  // Удаляем старые записи по типам, которые будем изменять
  const typesToTouch: string[] = [];
  if (roles.playerRoleId !== undefined) typesToTouch.push('PLAYER');
  if (roles.moderatorRoleId !== undefined) typesToTouch.push('MODERATOR');
  if (roles.vipRoleId !== undefined) typesToTouch.push('VIP');

  if (typesToTouch.length > 0) {
    await prisma.roleConfig.deleteMany({
      where: {
        serverConfigId: serverConfig.id,
        type: { in: typesToTouch as any },
      },
    });
  }

  const toCreate: { roleId: string; type: any }[] = [];
  if (roles.playerRoleId) {
    toCreate.push({ roleId: roles.playerRoleId, type: 'PLAYER' });
  }
  if (roles.moderatorRoleId) {
    toCreate.push({ roleId: roles.moderatorRoleId, type: 'MODERATOR' });
  }
  if (roles.vipRoleId) {
    toCreate.push({ roleId: roles.vipRoleId, type: 'VIP' });
  }

  if (toCreate.length > 0) {
    await prisma.roleConfig.createMany({
      data: toCreate.map((r) => ({
        serverConfigId: serverConfig.id,
        roleId: r.roleId,
        type: r.type,
      })),
    });
  }

  return getServerConfig(serverId);
}

export async function updateServerLimits(serverId: string, limits: {
  betPerMinute?: number | null;
  winPerHour?: number | null;
}) {
  const serverConfig = await ensureServerConfig(serverId);

  if (limits.betPerMinute !== undefined) {
    const existing = await prisma.limitConfig.findFirst({
      where: { serverConfigId: serverConfig.id, type: 'BET_PER_MINUTE' },
    });
    if (limits.betPerMinute === null || limits.betPerMinute <= 0) {
      if (existing) await prisma.limitConfig.delete({ where: { id: existing.id } });
    } else if (existing) {
      await prisma.limitConfig.update({ where: { id: existing.id }, data: { value: limits.betPerMinute } });
    } else {
      await prisma.limitConfig.create({
        data: { serverConfigId: serverConfig.id, type: 'BET_PER_MINUTE', value: limits.betPerMinute },
      });
    }
  }

  if (limits.winPerHour !== undefined) {
    const existing = await prisma.limitConfig.findFirst({
      where: { serverConfigId: serverConfig.id, type: 'WIN_PER_HOUR' },
    });
    if (limits.winPerHour === null || limits.winPerHour <= 0) {
      if (existing) await prisma.limitConfig.delete({ where: { id: existing.id } });
    } else if (existing) {
      await prisma.limitConfig.update({ where: { id: existing.id }, data: { value: limits.winPerHour } });
    } else {
      await prisma.limitConfig.create({
        data: { serverConfigId: serverConfig.id, type: 'WIN_PER_HOUR', value: limits.winPerHour },
      });
    }
  }

  return getServerConfig(serverId);
}

/** channelAccessMode: "none" | "whitelist" | "blacklist" */
export async function updateChannelAccessMode(serverId: string, mode: string) {
  return prisma.serverConfig.update({
    where: { serverId },
    data: { channelAccessMode: mode || 'none' },
  });
}

/** Список ID каналов из ChannelAccessRule */
export async function getChannelAccessRuleIds(serverId: string): Promise<string[]> {
  const config = await getServerConfig(serverId);
  if (!config?.channelAccessRules) return [];
  return (config.channelAccessRules as { channelId: string }[]).map((r) => r.channelId);
}

/** effectiveChannelId — для ветки это parentId, иначе channelId. */
export function isChannelAllowedForGames(
  config: { channelAccessMode?: string | null; gamesChannelId?: string | null; channelAccessRules?: { channelId: string }[] } | null,
  effectiveChannelId: string,
): boolean {
  if (!config) return false;
  const mode = config.channelAccessMode ?? 'none';
  const rules = (config.channelAccessRules ?? []).map((r) => r.channelId);
  const gamesChannelId = config.gamesChannelId;

  if (mode === 'none') {
    if (!gamesChannelId) return true;
    return gamesChannelId === effectiveChannelId;
  }
  if (mode === 'whitelist') {
    return rules.includes(effectiveChannelId);
  }
  if (mode === 'blacklist') {
    if (rules.includes(effectiveChannelId)) return false;
    return !gamesChannelId || gamesChannelId === effectiveChannelId;
  }
  return !gamesChannelId || gamesChannelId === effectiveChannelId;
}

/** Установить whitelist/blacklist каналов (полная замена списка) */
export async function setChannelAccessRules(serverId: string, channelIds: string[]) {
  const serverConfig = await ensureServerConfig(serverId);
  await prisma.channelAccessRule.deleteMany({
    where: { serverConfigId: serverConfig.id },
  });
  if (channelIds.length > 0) {
    await prisma.channelAccessRule.createMany({
      data: channelIds.map((channelId) => ({
        serverConfigId: serverConfig.id,
        channelId,
      })),
    });
  }
  return getServerConfig(serverId);
}

export async function updateEnabledGames(serverId: string, gameKeys: string[]) {
  const serverConfig = await ensureServerConfig(serverId);

  // Отключаем все игры, которые не в списке
  await prisma.enabledGame.updateMany({
    where: {
      serverConfigId: serverConfig.id,
      gameKey: { notIn: gameKeys },
    },
    data: { enabled: false },
  });

  // Включаем или создаём игры из списка
  for (const key of gameKeys) {
    const existing = await prisma.enabledGame.findFirst({
      where: {
        serverConfigId: serverConfig.id,
        gameKey: key,
      },
    });

    if (existing) {
      if (!existing.enabled) {
        await prisma.enabledGame.update({
          where: { id: existing.id },
          data: { enabled: true },
        });
      }
    } else {
      await prisma.enabledGame.create({
        data: {
          serverConfigId: serverConfig.id,
          gameKey: key,
          enabled: true,
        },
      });
    }
  }

  return getServerConfig(serverId);
}



