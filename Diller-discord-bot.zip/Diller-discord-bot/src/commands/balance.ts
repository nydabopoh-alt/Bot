import { ChatInputCommandInteraction, EmbedBuilder, MessageFlags } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { getBalance } from '../services/economy';
import { getServerConfig, getAdminBusinessBalance } from '../config/serverConfigService';

export async function handleBalance(interaction: ChatInputCommandInteraction) {
  const serverId = interaction.guild!.id;
  const userId = interaction.user.id;

  const balance = await getBalance(serverId, userId);
  const config = await getServerConfig(serverId);
  const adminUserId = (config as { adminUserId?: string | null })?.adminUserId ?? null;
  const isAdminWithBusiness = adminUserId === userId;

  let description: string;
  if (isAdminWithBusiness) {
    const businessBalance = await getAdminBusinessBalance(serverId);
    const total = balance + BigInt(businessBalance);
    description =
      `**Личный баланс:** ${balance} септимов\n` +
      `**Бизнес (10% с событий + комиссия игр):** ${businessBalance} септимов\n` +
      `**Всего:** ${total} септимов`;
  } else {
    description = `Текущий баланс: **${balance}** септимов`;
  }

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.COIN} Ваш баланс`)
    .setDescription(description)
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}
