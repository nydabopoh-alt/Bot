import {
  ActionRowBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  MessageFlags,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { prisma } from '../db/client';

// ─── Описания игр: правила, шансы, множители ───

interface GameInfo {
  key: string;
  label: string;
  emoji: string;
  color: number;
  rules: string;
  payouts: string;
  imageUrl?: string;
}

const GAMES: GameInfo[] = [
  {
    key: 'dicepoker',
    label: 'Покер на кубиках',
    emoji: '🎲',
    color: UI_CONFIG.COLORS.DICE,
    imageUrl: 'https://cdn.discordapp.com/attachments/1471462038998880430/1474298267025149952/iu_.png?ex=69a928c1&is=69a7d741&hm=a2e0722b880d79de7c8d5b9b5094edbc1d56a4d0fed86c09c815b17399725a0a&',
    rules:
      '**Покер на кубиках.** 1) Ставки по очереди (до броска). 2) Бросок — каждый кидает 5 кубиков по очереди. ' +
      '3) Ставки снова (по тому, что выпало). 4) Переброс — каждый по очереди перебрасывает 1–5 кубиков. 5) Финал — лучшая комбинация забирает банк.',
    payouts:
      '**Комбинации:** Покер (5 одинаковых) → Каре → Фулл-хаус → Стрит → Тройка → Две пары → Пара → Старшая.\n' +
      'Победитель забирает весь банк. Минимум 2 игрока.',
  },
  {
    key: 'blind',
    label: 'Покер',
    emoji: '🃏',
    color: UI_CONFIG.COLORS.BLIND,
    rules:
      '**Техасский холдем.** Каждому по 2 карты в ЛС. На стол выкладывают 5 общих: сначала 3, потом ещё 1, потом последняя.\n' +
      'Игроки по очереди: Проверить / Уравнять / Поставить / Сбросить. Лучшая комбинация из 7 карт (2 своих + 5 общих) забирает банк.',
    payouts:
      '**Победитель** забирает весь банк септимов (ставки всех игроков).\n' +
      'Выплата с учётом RTP и VIP. Минимум 2 игрока.',
  },
  {
    key: 'duel',
    label: 'Гвинт: Дуэль',
    emoji: '⚔️',
    color: UI_CONFIG.COLORS.DUEL,
    rules:
      'Упрощённая дуэль: вытяни карту сильнее. У каждого колода из 10 карт (1–10).\n' +
      '3 раунда: оба тянут по 1 карте, кто больше — получает очко. Карта сбрасывается. Проигравший платит ставку.',
    payouts:
      '**Победитель** забирает банк (ставка × 2). **Ничья** — ставки возвращаются. Ставка списывается с обоих до начала.',
  },
  {
    key: 'tug',
    label: 'Перетягивание каната',
    emoji: '🪢',
    color: UI_CONFIG.COLORS.TUG,
    rules:
      'Игрок против «крысёныша». У него 100 HP. Ставь септимы, кидаешь 2d6 — урон по сумме. После броска: «Кинуть ещё» или «Стоп» (забрать). Добьёшь до 0 HP — x3 ставки; слишком рано остановился — ставка в Флягу.',
    payouts:
      '**Урон:** 7 → x1 | 2–6 → x0.5 | 8–12 → x1.5 | Дубль → x2\n' +
      '**Выплаты:** 0 HP у бота → **x3** | Стоп при ≥50% урона → **(1 + % урона)** | <50% → проигрыш',
  },
  {
    key: 'intervention',
    label: 'Интервенция 21.5',
    emoji: '🃏',
    color: UI_CONFIG.COLORS.INTERVENTION,
    rules:
      'Карточная игра на жадность. Цель — ровно 21.5. Колода: 6, 7, 8, 9, J, Q, K, A. 6–9 = номинал, J/Q/K = +0.5, Туз = 1 или 11 (на выбор). «Ещё» — взять карту, «Хватит» — остановиться.',
    payouts:
      '`Ровно 21.5` — **x5**\n' +
      '`Ровно 21` — **x2**\n' +
      '`17–20.5` — **x1.5**\n' +
      '`Меньше 17` или `>21.5` — проигрыш',
  },
  {
    key: 'poker',
    label: 'Покер (2 vs 3 кости)',
    emoji: '🎰',
    color: UI_CONFIG.COLORS.POKER,
    rules:
      'Сначала кидаете вы — 2 кубика. Потом дилер — 3 кубика. У кого сумма больше, тот выиграл. Равная сумма — ничья, ставка возвращается.',
    payouts:
      '**Победа** — ставка × 2 (с учётом комиссии и VIP). **Ничья** — возврат ставки. **Проигрыш** — ставка уходит дилеру.',
  },
];

// ─── /stats - начальный экран с select menu ───

export async function handleStats(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только на сервере.`, flags: MessageFlags.Ephemeral });
  }

  const embed = await buildOverviewEmbed(interaction.guild.id, interaction.user.id);
  const row = buildGameSelect();

  return interaction.reply({
    embeds: [await embed],
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

// ─── Обработка select menu ───

export async function handleStatsSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) return;

  await interaction.deferUpdate();

  const gameKey = interaction.values[0];

  if (gameKey === 'overview') {
    const embed = await buildOverviewEmbed(interaction.guild.id, interaction.user.id);
    const row = buildGameSelect('overview');
    return interaction.editReply({ embeds: [embed], components: [row] });
  }

  const game = GAMES.find(g => g.key === gameKey);
  if (!game) {
    return interaction.editReply({ content: `${UI_CONFIG.EMOJI.ERROR} Игра не найдена.`, embeds: [], components: [] });
  }

  const serverId = interaction.guild.id;
  const userId = interaction.user.id;

  const [userStats, serverStats] = await Promise.all([
    getGameStats(serverId, userId, gameKey),
    getGameStats(serverId, null, gameKey),
  ]);

  const embed = new EmbedBuilder()
    .setTitle(`${game.emoji} ${game.label}`)
    .setColor(game.color)
    .setImage(game.imageUrl ?? null)
    .addFields(
      {
        name: `${UI_CONFIG.EMOJI.RULES} Правила`,
        value: game.rules,
        inline: false,
      },
      {
        name: `${UI_CONFIG.EMOJI.MONEY_BAG} Выплаты и множители`,
        value: game.payouts,
        inline: false,
      },
      {
        name: `${UI_CONFIG.EMOJI.CHART} Ваша статистика`,
        value: formatPlayerStats(userStats),
        inline: true,
      },
      {
        name: `${UI_CONFIG.EMOJI.STATS} Статистика сервера`,
        value: formatPlayerStats(serverStats),
        inline: true,
      },
    )
    .setFooter({ text: 'Другая игра — в меню ниже' });

  const row = buildGameSelect(gameKey);
  return interaction.editReply({ embeds: [embed], components: [row] });
}

// ─── Общий обзор ───

async function buildOverviewEmbed(serverId: string, userId: string): Promise<EmbedBuilder> {
  const allStats = await Promise.all(
    GAMES.map(async (game) => {
      const user = await getGameStats(serverId, userId, game.key);
      return { game, user };
    }),
  );

  const lines = allStats.map(({ game, user }) => {
    const winRate = user.total > 0 ? Math.round((user.wins / user.total) * 100) : 0;
    const profit = user.totalWon - user.totalBet;
    const profitSign = profit >= 0 ? '+' : '';
    return `${game.emoji} **${game.label}**\n` +
      `   Игр: **${user.total}** | Побед: **${user.wins}** (${winRate}%) | Профит: **${profitSign}${profit}** ${UI_CONFIG.EMOJI.COIN}`;
  });

  return new EmbedBuilder()
    .setTitle('🐀 Крысиная Нора — правила и статистика')
    .setDescription(
      'Выбери игру в меню — правила, множители и твоя статистика.\n\n' +
        `**${UI_CONFIG.EMOJI.CHART} Обзор по всем играм:**\n\n` +
        lines.join('\n\n'),
    )
    .setColor(0x5D100A)
    .setFooter({ text: 'Фартуна любит смелых' });
}

// ─── Эмбед «Правила игр» для канала (без статистики пользователя) ───

export function buildRulesOverviewEmbedForChannel(): EmbedBuilder {
  const lines = GAMES.map(
    (g) => `${g.emoji} **${g.label}** — правила и выплаты в меню ниже`,
  );
  return new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.RULES} Правила игр`)
    .setDescription(
      'Тот же контент, что и в команде `/stats`. Выберите игру в меню ниже — откроются **правила**, выплаты и ваша статистика по этой игре.\n\n' +
        lines.join('\n'),
    )
    .setColor(0x5D100A)
    .setFooter({ text: 'Другая игра — выберите в меню' });
}

// ─── Select menu ───

export function buildGameSelect(currentValue?: string) {
  const options = [
    {
      label: 'Общий обзор',
      value: 'overview',
      emoji: UI_CONFIG.EMOJI.STATS,
      description: 'Сводная статистика по всем играм',
      default: currentValue === 'overview' || !currentValue,
    },
    ...GAMES.map(g => ({
      label: g.label,
      value: g.key,
      emoji: g.emoji,
      description: `Правила и статистика: ${g.label}`,
      default: currentValue === g.key,
    })),
  ];

  const select = new StringSelectMenuBuilder()
    .setCustomId('stats:gameSelect')
    .setPlaceholder('Выберите игру...')
    .addOptions(options);

  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
}

// ─── Запрос статистики из БД ───

interface GameStatsResult {
  total: number;
  wins: number;
  losses: number;
  draws: number;
  totalBet: number;
  totalWon: number;
  biggestWin: number;
  biggestBet: number;
}

async function getGameStats(
  serverId: string,
  userId: string | null,
  gameType: string,
): Promise<GameStatsResult> {
  const where: any = { serverId, gameType };
  if (userId) where.userId = userId;

  const [aggregates, winCount, loseCount] = await Promise.all([
    prisma.betLog.aggregate({
      where,
      _count: true,
      _sum: { betAmount: true, payoutAmount: true },
      _max: { payoutAmount: true, betAmount: true },
    }),
    prisma.betLog.count({ where: { ...where, outcome: 'win' } }),
    prisma.betLog.count({ where: { ...where, outcome: 'lose' } }),
  ]);

  const drawCount = (aggregates._count ?? 0) - winCount - loseCount;

  return {
    total: aggregates._count ?? 0,
    wins: loseCount,
    losses: winCount,
    draws: Math.max(0, drawCount),
    totalBet: aggregates._sum?.betAmount ?? 0,
    totalWon: aggregates._sum?.payoutAmount ?? 0,
    biggestWin: aggregates._max?.payoutAmount ?? 0,
    biggestBet: aggregates._max?.betAmount ?? 0,
  };
}

// ─── Форматирование ───

function formatPlayerStats(stats: GameStatsResult): string {
  if (stats.total === 0) {
    return '_Нет данных_';
  }

  const winRate = Math.round((stats.wins / stats.total) * 100);
  const profit = stats.totalWon - stats.totalBet;
  const profitSign = profit >= 0 ? '+' : '';
  const profitEmoji = profit >= 0 ? UI_CONFIG.EMOJI.CHART : UI_CONFIG.EMOJI.LOSS;

  return [
    `Всего игр: **${stats.total}**`,
    `${UI_CONFIG.EMOJI.WIN} Побед: **${stats.wins}** (${winRate}%)`,
    `${UI_CONFIG.EMOJI.LOSS} Поражений: **${stats.losses}**`,
    stats.draws > 0 ? `Ничьих: **${stats.draws}**` : null,
    ``,
    `Поставлено: **${stats.totalBet}** ${UI_CONFIG.EMOJI.COIN}`,
    `Выиграно: **${stats.totalWon}** ${UI_CONFIG.EMOJI.COIN}`,
    `${profitEmoji} Профит: **${profitSign}${profit}** ${UI_CONFIG.EMOJI.COIN}`,
    ``,
    `${UI_CONFIG.EMOJI.FIRE} Макс. выигрыш: **${stats.biggestWin}**`,
    `${UI_CONFIG.EMOJI.TARGET} Макс. ставка: **${stats.biggestBet}**`,
  ].filter(Boolean).join('\n');
}
