import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  GuildScheduledEventEntityType,
  GuildScheduledEventPrivacyLevel,
  StringSelectMenuBuilder,
  type Client,
  type Guild,
  type TextChannel,
} from 'discord.js';
import { prisma } from '../db/client';
import { getServerConfig, creditAdminBusinessBalance } from '../config/serverConfigService';
import { UI_CONFIG } from '../config/ui';
import { formatTamrielDate } from '../utils/tamrielDate';

// ─── Типы событий и шаблоны ───

export const EVENT_TYPES: Record<string, { label: string; emoji: string; color: number }> = {
  dice_night:   { label: 'Ночь костей',          emoji: '🎲', color: UI_CONFIG.COLORS.DICE },
  blind_tourney:{ label: 'Турнир «Покер»', emoji: '🃏', color: UI_CONFIG.COLORS.BLIND },
  duel_tourney: { label: 'Турнир дуэлей',         emoji: '⚔️', color: UI_CONFIG.COLORS.DUEL },
  tug_battle:   { label: 'Битва «Перетягивание»',  emoji: '🪢', color: UI_CONFIG.COLORS.TUG },
  intervention: { label: 'Марафон «Интервенция»',  emoji: '🃏', color: UI_CONFIG.COLORS.INTERVENTION },
  fight:        { label: 'Бой / Поединок',         emoji: '🥊', color: UI_CONFIG.COLORS.EVENT_FIGHT },
  tournament:   { label: 'Общий турнир',           emoji: '🏆', color: UI_CONFIG.COLORS.EVENT_TOURNAMENT },
  special:      { label: 'Особое событие',         emoji: '🌟', color: UI_CONFIG.COLORS.EVENT_SPECIAL },
  custom:       { label: 'Пользовательское',       emoji: '📢', color: UI_CONFIG.COLORS.EVENT_CUSTOM },
};

/** Типы для арены (бои и турниры): выбор при [Создать событие] в канале админа */
export const ARENA_EVENT_TYPES: Record<string, { label: string; emoji: string; needsTeamSize?: boolean }> = {
  white_flag:     { label: 'Белый флаг (бои 1 на 1)',     emoji: '🏳️' },
  team_fight:     { label: 'Командные бои (2 на 2 и т.д.)', emoji: '👥', needsTeamSize: true },
  funeral_fight:  { label: 'Похоронный бой (1 на 1, насмерть)', emoji: '⚰️' },
  tug:            { label: 'Игра в канат',                emoji: '🪢' },
  poker_tournament: { label: 'Турнир в покер',            emoji: '🎰' },
};

function getEventMeta(eventType: string) {
  return EVENT_TYPES[eventType] ?? EVENT_TYPES.custom;
}

/** Панель для канала админа: кнопка [Создать событие] */
export function buildAdminPanelPayload(): { embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] } {
  const embed = new EmbedBuilder()
    .setTitle('🥊 Меню мероприятий')
    .setDescription(
      'Нажмите **Создать событие**, чтобы выбрать тип мероприятия и заполнить форму.\n' +
        'Бои и турниры публикуются в канале **Арена** (настраивается в Настройках).',
    )
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('arena:createEvent')
      .setLabel('Создать событие')
      .setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row] };
}

// ─── Форматирование даты ───

function formatDate(date: Date): string {
  return date.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Europe/Moscow',
  });
}

function discordTimestamp(date: Date, style: 'R' | 'F' | 'f' | 't' | 'T' | 'D' | 'd' = 'F'): string {
  return `<t:${Math.floor(date.getTime() / 1000)}:${style}>`;
}

// ─── Построение embed-ов ───

export function buildEventAnnouncementEmbed(event: {
  title: string;
  description: string;
  eventType: string;
  scheduledAt: Date;
  prize?: string | null;
  maxPlayers?: number | null;
  createdBy: string;
}) {
  const meta = getEventMeta(event.eventType);

  const embed = new EmbedBuilder()
    .setTitle(`${meta.emoji} ${event.title}`)
    .setDescription(event.description)
    .addFields(
      { name: '📅 Дата и время', value: `${discordTimestamp(event.scheduledAt, 'F')}\n${discordTimestamp(event.scheduledAt, 'R')}`, inline: true },
      { name: '🏷️ Тип', value: meta.label, inline: true },
    )
    .setColor(meta.color)
    .setFooter({ text: `Создал мероприятие` })
    .setTimestamp();

  if (event.prize) {
    embed.addFields({ name: '🎁 Приз', value: event.prize, inline: true });
  }
  if (event.maxPlayers) {
    embed.addFields({ name: '👥 Макс. участников', value: `${event.maxPlayers}`, inline: true });
  }

  return embed;
}

export function buildReminderEmbed(event: {
  title: string;
  description: string;
  eventType: string;
  scheduledAt: Date;
  prize?: string | null;
}, timeLabel: string) {
  const meta = getEventMeta(event.eventType);

  return new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.CLOCK} Напоминание: ${event.title}`)
    .setDescription(
      `${meta.emoji} **${meta.label}** начнётся ${timeLabel}!\n\n` +
        `${discordTimestamp(event.scheduledAt, 'R')}\n\n` +
        (event.prize ? `🎁 Приз: **${event.prize}**\n\n` : '') +
        `Не пропустите!`,
    )
    .setColor(meta.color)
    .setTimestamp();
}

export function buildEventStartEmbed(event: {
  title: string;
  description: string;
  eventType: string;
  prize?: string | null;
}) {
  const meta = getEventMeta(event.eventType);

  return new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.FIRE} НАЧИНАЕТСЯ: ${event.title}`)
    .setDescription(
      `${meta.emoji} **${meta.label}** стартует прямо сейчас!\n\n` +
        event.description + '\n\n' +
        (event.prize ? `🎁 Приз: **${event.prize}**` : ''),
    )
    .setColor(meta.color)
    .setTimestamp();
}

export function buildEventListEmbed(events: Array<{
  id: number;
  title: string;
  eventType: string;
  scheduledAt: Date;
  status: string;
  prize?: string | null;
}>) {
  if (events.length === 0) {
    return new EmbedBuilder()
      .setTitle('📋 Мероприятия')
      .setDescription('Нет запланированных мероприятий.')
      .setColor(UI_CONFIG.COLORS.PRIMARY);
  }

  const lines = events.map((e, i) => {
    const meta = getEventMeta(e.eventType);
    const statusIcon = e.status === 'scheduled' ? '🟢'
      : e.status === 'active' ? '🔴'
      : e.status === 'completed' ? '✅'
      : '⚫';
    return `${statusIcon} **#${e.id}** ${meta.emoji} ${e.title}\n` +
      `     ${discordTimestamp(e.scheduledAt, 'f')} (${discordTimestamp(e.scheduledAt, 'R')})` +
      (e.prize ? ` | 🎁 ${e.prize}` : '');
  });

  return new EmbedBuilder()
    .setTitle('📋 Предстоящие мероприятия')
    .setDescription(lines.join('\n\n'))
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setTimestamp();
}

// ─── Шаблоны быстрой рассылки ───

export const BROADCAST_TEMPLATES: Record<string, {
  label: string;
  emoji: string;
  build: () => EmbedBuilder;
}> = {
  dice_night: {
    label: 'Ночь костей',
    emoji: '🎲',
    build: () => new EmbedBuilder()
      .setTitle('🎲 НОЧЬ КОСТЕЙ')
      .setDescription(
        '**Сегодня вечером - Ночь костей!**\n\n' +
          'Бросайте кубики, ловите комбинации и забирайте банк!\n\n' +
          '`4-5-6` - x2 | `Трипс` - x3 | `Пара+6` - x1.5\n\n' +
          'Используйте `/dice`, чтобы начать играть.\n' +
          'Удачи и больших выигрышей! 🍀',
      )
      .setColor(UI_CONFIG.COLORS.DICE)
      .setTimestamp(),
  },
  blind_tournament: {
    label: 'Турнир «Покер»',
    emoji: '🃏',
    build: () => new EmbedBuilder()
      .setTitle('🃏 ТУРНИР «Покер»')
      .setDescription(
        '**Блеф решает всё!**\n\n' +
          'Каждому - одна скрытая карта. Ставки, блеф, вскрытие.\n' +
          'У кого карта старше - забирает банк.\n\n' +
          'Соберите компанию и запускайте `/blind`.\n' +
          'Кто станет королём блефа? 👑',
      )
      .setColor(UI_CONFIG.COLORS.BLIND)
      .setTimestamp(),
  },
  duel_arena: {
    label: 'Арена дуэлей',
    emoji: '⚔️',
    build: () => new EmbedBuilder()
      .setTitle('⚔️ АРЕНА ДУЭЛЕЙ ОТКРЫТА')
      .setDescription(
        '**Вызови соперника и докажи, что ты сильнее!**\n\n' +
          'Колода из 10 карт, 3 раунда, чистая стратегия.\n' +
          'Проигравший платит ставку.\n\n' +
          'Используйте `/duel @противник`, чтобы бросить вызов.\n' +
          'Кто окажется на вершине? ⚔️',
      )
      .setColor(UI_CONFIG.COLORS.DUEL)
      .setTimestamp(),
  },
  tug_challenge: {
    label: 'Вызов «Перетягивание каната»',
    emoji: '🪢',
    build: () => new EmbedBuilder()
      .setTitle('🪢 ПЕРЕТЯГИВАНИЕ КАНАТА - ВЫЗОВ')
      .setDescription(
        '**Бот бросает тебе вызов!**\n\n' +
          'У бота 100 HP. Бросай 2d6, наноси урон.\n' +
          'Дубль - крит x2! Убьёшь бота - получишь x3 ставки.\n\n' +
          'Но будь осторожен: остановись слишком рано - потеряешь всё.\n\n' +
          'Начни с `/tug`! 💪',
      )
      .setColor(UI_CONFIG.COLORS.TUG)
      .setTimestamp(),
  },
  intervention_marathon: {
    label: 'Марафон «Интервенция 21.5»',
    emoji: '🃏',
    build: () => new EmbedBuilder()
      .setTitle('🃏 МАРАФОН «ИНТЕРВЕНЦИЯ 21.5»')
      .setDescription(
        '**Набери ровно 21.5 и получи x5 ставки!**\n\n' +
          'J, Q, K = +0.5 | Туз = 1 или 11 (на выбор)\n' +
          'Меньше 17 - проигрыш. Больше 21.5 - перебор.\n\n' +
          'Рискни с `/intervention`!\n' +
          'Сможешь попасть в яблочко? 🎯',
      )
      .setColor(UI_CONFIG.COLORS.INTERVENTION)
      .setTimestamp(),
  },
  fight_announcement: {
    label: 'Анонс боя',
    emoji: '🥊',
    build: () => new EmbedBuilder()
      .setTitle('🥊 БОЛЬШОЙ БОЙ ПРИБЛИЖАЕТСЯ')
      .setDescription(
        '**Готовьтесь к эпичному поединку!**\n\n' +
          'Скоро состоится главное событие сервера.\n' +
          'Сделайте ставки, выберите сторону и наблюдайте!\n\n' +
          'Подробности и время - в следующем анонсе.\n' +
          'Не пропустите! 🔔',
      )
      .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
      .setTimestamp(),
  },
  weekend_games: {
    label: 'Выходные игры',
    emoji: '🎉',
    build: () => new EmbedBuilder()
      .setTitle('🎉 ИГРОВЫЕ ВЫХОДНЫЕ')
      .setDescription(
        '**Этот уик-энд - особенный!**\n\n' +
          '🎲 Кости | 🃏 Покер | ⚔️ Дуэли\n' +
          '🪢 Перетягивание | 🃏 Интервенция\n\n' +
          'Все игры активны, множители увеличены!\n' +
          'Заходите, играйте и выигрывайте! 💰',
      )
      .setColor(UI_CONFIG.COLORS.EVENT_SPECIAL)
      .setTimestamp(),
  },
};

// ─── CRUD для событий ───

/** Преобразование entryFee (bigint | number | null) в number для арифметики */
function toEntryFeeNum(ef: bigint | number | null | undefined): number {
  return ef != null ? Number(ef) : 0;
}

export async function createEvent(data: {
  serverId: string;
  createdBy: string;
  title: string;
  description: string;
  eventType: string;
  scheduledAt: Date;
  channelId?: string;
  prize?: string;
  maxPlayers?: number;
  entryFee?: number | null;
  coverImageUrl?: string | null;
  teamSize?: bigint | null;
  place?: string | null;
}) {
  const { entryFee, teamSize, ...rest } = data;
  return prisma.event.create({
    data: {
      ...rest,
      entryFee: entryFee != null ? BigInt(entryFee) : null,
      teamSize,
    },
  });
}

/** Эмбед анонса боя/турнира для канала арены (до старта). При передаче participants и prizePoolBonus показывается итоговая призовая сумма и комиссия 10%. */
export function buildArenaAnnounceEmbed(event: {
  id: number;
  title: string;
  eventType: string;
  scheduledAt: Date;
  entryFee: bigint | number | null;
  coverImageUrl: string | null;
  participants?: { userId: string }[];
  prizePoolBonus?: number;
}) {
  const meta = ARENA_EVENT_TYPES[event.eventType] ?? { label: event.eventType, emoji: '🥊' };
  const whenTamriel = formatTamrielDate(event.scheduledAt);
  const fee = toEntryFeeNum(event.entryFee);
  const fields: { name: string; value: string; inline: boolean }[] = [
    { name: 'Формат', value: meta.label, inline: true },
    { name: 'Когда', value: whenTamriel, inline: true },
    { name: 'Стартовый взнос', value: `${fee} септимов\n_списывается с баланса при записи_`, inline: true },
  ];

  const participants = event.participants ?? [];
  const bonus = event.prizePoolBonus ?? 0;
  const totalPool = participants.length * fee + bonus;
  if (totalPool > 0) {
    const { commission, toPrizes } = arenaPrizeBreakdown(totalPool);
    fields.push(
      { name: 'Призовой фонд (всего)', value: `${totalPool} септимов`, inline: true },
      { name: 'Комиссия 10%', value: `${commission} септимов`, inline: true },
      { name: 'На призы', value: `${toPrizes} септимов`, inline: true },
    );
  }

  const embed = new EmbedBuilder()
    .setTitle(`${meta.emoji} ${event.title}`)
    .addFields(fields)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();

  if (event.coverImageUrl) embed.setImage(event.coverImageUrl);
  return embed;
}

/** Эмбед «Турнир начат» для канала арены и канала событий (тамриэльская дата, призовой фонд с учётом комиссии 10%) */
export function buildArenaStartedEmbed(event: {
  title: string;
  eventType: string;
  scheduledAt: Date;
  coverImageUrl: string | null;
  participants: { userId: string }[];
  entryFee: bigint | number | null;
  prizePoolBonus: number;
}) {
  const meta = ARENA_EVENT_TYPES[event.eventType] ?? { label: event.eventType, emoji: '🥊' };
  const bracketLines = buildBracketLines(event.participants);
  const fee = toEntryFeeNum(event.entryFee);
  const totalPool = event.participants.length * fee + event.prizePoolBonus;
  const { commission, toPrizes } = arenaPrizeBreakdown(totalPool);
  const whenTamriel = formatTamrielDate(event.scheduledAt);

  const embed = new EmbedBuilder()
    .setTitle(`${meta.emoji} ${event.title}`)
    .addFields(
      { name: 'Формат', value: meta.label, inline: true },
      { name: 'Когда', value: whenTamriel, inline: true },
      { name: 'На призы', value: `${toPrizes} септимов`, inline: true },
      { name: 'Комиссия 10%', value: `${commission} септимов`, inline: true },
      { name: 'Турнирная таблица', value: bracketLines.length > 0 ? bracketLines.map((l) => `• ${l}`).join('\n') : '—', inline: false },
    )
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();

  if (event.coverImageUrl) embed.setImage(event.coverImageUrl);
  return embed;
}

/** Кнопки под анонсом в арене */
export function buildArenaAnnounceButtons(eventId: number) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`arena:signUp:${eventId}`)
      .setLabel('Записаться на турнир')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`arena:unsign:${eventId}`)
      .setLabel('Отказаться от турнира')
      .setStyle(ButtonStyle.Secondary),
  );
}

/** Покер и канат публикуются в канал событий, остальные — в арену */
function getAnnounceChannelId(config: Record<string, unknown>, eventType: string): string | null {
  const arenaChannelId = (config as { arenaChannelId?: string | null })?.arenaChannelId ?? null;
  const eventsChannelId = (config as { eventsChannelId?: string | null })?.eventsChannelId ?? null;
  const isPokerOrTug = eventType === 'poker_tournament' || eventType === 'tug';
  return isPokerOrTug ? (eventsChannelId ?? arenaChannelId) : arenaChannelId;
}

/** Discord Scheduled Event + кнопки (без эмбеда) для всех типов арены */
const ARENA_DISCORD_EVENT_TYPES = ['white_flag', 'team_fight', 'funeral_fight', 'poker_tournament', 'tug'] as const;

function buildArenaDiscordEventDescription(event: {
  eventType: string;
  scheduledAt: Date;
  entryFee: bigint | number | null;
}): string {
  const meta = ARENA_EVENT_TYPES[event.eventType] ?? { label: event.eventType };
  const whenTamriel = formatTamrielDate(event.scheduledAt);
  const fee = toEntryFeeNum(event.entryFee);
  return [
    `**Формат:** ${meta.label}`,
    `**Когда:** ${whenTamriel}`,
    `**Стартовый взнос:** ${fee} септимов (списывается с баланса при записи)`,
  ].join('\n');
}

async function ensureArenaDiscordScheduledEvent(
  client: Client,
  event: {
    id: number;
    serverId: string;
    title: string;
    eventType: string;
    scheduledAt: Date;
    entryFee: bigint | number | null;
    place?: string | null;
    discordScheduledEventId?: string | null;
  },
): Promise<string | null> {
  if (!ARENA_DISCORD_EVENT_TYPES.includes(event.eventType as (typeof ARENA_DISCORD_EVENT_TYPES)[number])) return null;
  try {
    const guild = await client.guilds.fetch(event.serverId).catch(() => null) as Guild | null;
    if (!guild) return null;

    const meta = ARENA_EVENT_TYPES[event.eventType] ?? { label: event.eventType, emoji: '🥊' };
    const name = `${meta.emoji} ${event.title}`.slice(0, 100);
    const description = buildArenaDiscordEventDescription(event).slice(0, 1000);
    const start = new Date(event.scheduledAt);
    const end = new Date(start.getTime() + 4 * 60 * 60 * 1000);
    const location = (event.place?.trim() || 'Крысиная Нора').slice(0, 100);

    if (event.discordScheduledEventId) {
      const existing = await guild.scheduledEvents.fetch(event.discordScheduledEventId).catch(() => null);
      if (existing?.url) return existing.url;
    }

    const scheduledEvent = await guild.scheduledEvents.create({
      name,
      description: description || undefined,
      scheduledStartTime: start,
      scheduledEndTime: end,
      privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
      entityType: GuildScheduledEventEntityType.External,
      entityMetadata: { location },
    });

    await prisma.event.update({
      where: { id: event.id },
      data: { discordScheduledEventId: scheduledEvent.id } as Record<string, unknown>,
    });
    return scheduledEvent.url;
  } catch (err) {
    console.error('[Events] Failed to create arena Discord scheduled event:', err);
    return null;
  }
}

/** Отправить анонс в канал арены или событий. Для типов из ARENA_DISCORD_EVENT_TYPES: только блок Discord-события + кнопки (без эмбеда). */
export async function sendArenaAnnounce(
  client: Client,
  event: { id: number; title: string; eventType: string; scheduledAt: Date; entryFee: bigint | number | null; coverImageUrl: string | null; serverId: string; place?: string | null; discordScheduledEventId?: string | null },
): Promise<string | null> {
  const config = await getServerConfig(event.serverId);
  const channelId = getAnnounceChannelId(config as Record<string, unknown>, event.eventType);
  if (!channelId) return null;

  const channel = await client.channels.fetch(channelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return null;

  const isDiscordEventType = ARENA_DISCORD_EVENT_TYPES.includes(event.eventType as (typeof ARENA_DISCORD_EVENT_TYPES)[number]);
  let eventUrl: string | null = null;
  if (isDiscordEventType) {
    eventUrl = await ensureArenaDiscordScheduledEvent(client, event);
  }

  const row = buildArenaAnnounceButtons(event.id);

  // Только блок Discord-события + кнопки (без эмбеда) — для похоронный, командный, белый флаг, покер, канат
  if (eventUrl) {
    const msg = await channel.send({ content: eventUrl, components: [row] }).catch(() => null);
    if (!msg) return null;
    await prisma.event.update({
      where: { id: event.id },
      data: { arenaMessageId: msg.id, announced: true },
    });
    return msg.id;
  }

  // Fallback: эмбед + кнопки (для старых типов или при ошибке создания Discord-события)
  const embed = buildArenaAnnounceEmbed(event);
  const msg = await channel.send({ embeds: [embed], components: [row] }).catch(() => null);
  if (!msg) return null;
  await prisma.event.update({
    where: { id: event.id },
    data: { arenaMessageId: msg.id, announced: true },
  });
  return msg.id;
}

/** Обновить сообщение-анонс (при изменении участников или призового бонуса). Если используется блок Discord-события — эмбед не обновляется. */
export async function updateArenaAnnounce(client: Client, eventId: number): Promise<void> {
  const event = await prisma.event.findUnique({
    where: { id: eventId },
    include: { participants: true },
  });
  if (!event?.arenaMessageId || event.serverId == null) return;
  // Сообщение без эмбеда (только Discord event block + кнопки) — нечего обновлять
  if (event.discordScheduledEventId) return;

  const config = await getServerConfig(event.serverId);
  const channelId = getAnnounceChannelId(config as Record<string, unknown>, event.eventType);
  if (!channelId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;
  try {
    const msg = await channel.messages.fetch(event.arenaMessageId);
    const embed = buildArenaAnnounceEmbed({
      id: event.id,
      title: event.title,
      eventType: event.eventType,
      scheduledAt: event.scheduledAt,
      entryFee: event.entryFee,
      coverImageUrl: event.coverImageUrl,
      participants: event.participants,
      prizePoolBonus: event.prizePoolBonus ?? 0,
    });
    await msg.edit({ embeds: [embed] });
  } catch {
    // Сообщение удалено или нет доступа
  }
}

/** Удалить сообщение «Ставки на турнир» при завершении (ищем в канале арены, затем в тикетах) */
export async function deleteArenaBetMessage(client: Client, eventId: number): Promise<void> {
  const event = await prisma.event.findUnique({
    where: { id: eventId },
    select: { arenaBetMessageId: true, serverId: true, eventType: true },
  });
  if (!event?.arenaBetMessageId) return;
  const config = await getServerConfig(event.serverId) as { arenaChannelId?: string | null; ticketsChannelId?: string | null; eventsChannelId?: string | null };
  const isPokerOrTug = event.eventType === 'poker_tournament' || event.eventType === 'tug';
  const channelIds = [
    isPokerOrTug ? config?.eventsChannelId : config?.arenaChannelId,
    config?.ticketsChannelId,
  ].filter(Boolean) as string[];
  for (const chId of channelIds) {
    try {
      const ch = await client.channels.fetch(chId).catch(() => null) as TextChannel | null;
      if (!ch?.isTextBased()) continue;
      const msg = await ch.messages.fetch(event.arenaBetMessageId);
      await msg.delete().catch(() => {});
      break;
    } catch {
      // Сообщение не в этом канале — пробуем следующий
    }
  }
  await prisma.event.update({
    where: { id: eventId },
    data: { arenaBetMessageId: null },
  });
}

// ─── Участники арены ───

export async function getEventParticipants(eventId: number) {
  return prisma.eventParticipant.findMany({
    where: { eventId },
    orderBy: { id: 'asc' },
  });
}

export async function addEventParticipant(eventId: number, data: {
  userId: string;
  name?: string | null;
  primeTime?: string | null;
  weaponType?: string | null;
  armorType?: string | null;
  paidAmount: number;
  teamName?: string | null;
}) {
  return prisma.eventParticipant.upsert({
    where: {
      eventId_userId: { eventId, userId: data.userId },
    },
    create: {
      eventId,
      userId: data.userId,
      name: data.name,
      primeTime: data.primeTime,
      weaponType: data.weaponType,
      armorType: data.armorType,
      paidAmount: data.paidAmount,
      teamName: data.teamName,
    },
    update: {
      name: data.name,
      primeTime: data.primeTime,
      weaponType: data.weaponType,
      armorType: data.armorType,
      paidAmount: data.paidAmount,
      teamName: data.teamName,
    },
  });
}

/** Уникальные названия команд для командного боя (из участников с teamName) */
export async function getEventTeamNames(eventId: number): Promise<string[]> {
  const participants = await prisma.eventParticipant.findMany({
    where: { eventId, teamName: { not: null } },
    select: { teamName: true },
  });
  const names = [...new Set(participants.map((p) => p.teamName).filter(Boolean))] as string[];
  return names.sort();
}

export async function removeEventParticipant(eventId: number, userId: string) {
  return prisma.eventParticipant.deleteMany({
    where: { eventId, userId },
  });
}

export async function getEventWithParticipants(eventId: number) {
  return prisma.event.findUnique({
    where: { id: eventId },
    include: { participants: true },
  });
}

/** Строки турнирной таблицы: @User1 vs @User2 и т.д. */
export function buildBracketLines(participants: { userId: string }[]): string[] {
  const lines: string[] = [];
  for (let i = 0; i < participants.length - 1; i += 2) {
    lines.push(`<@${participants[i].userId}> vs <@${participants[i + 1].userId}>`);
  }
  if (participants.length % 2 === 1) {
    lines.push(`<@${participants[participants.length - 1].userId}> — ждёт соперника`);
  }
  return lines;
}

/** Для командного боя: команды с участниками — **Название:** @u1, @u2 */
export function buildTeamParticipantLines(participants: { userId: string; name?: string | null; teamName?: string | null }[]): string[] {
  if (participants.length === 0) return [];
  const byTeam = new Map<string, { userId: string; name?: string | null }[]>();
  for (const p of participants) {
    const team = p.teamName?.trim() || 'Без команды';
    if (!byTeam.has(team)) byTeam.set(team, []);
    byTeam.get(team)!.push({ userId: p.userId, name: p.name });
  }
  return Array.from(byTeam.entries()).map(([team, members]) => {
    const mentions = members.map((m) => `<@${m.userId}>`).join(', ');
    const count = members.length;
    return `**${team}** (${count} чел.): ${mentions}`;
  });
}

// ─── Сетка турнира (bracketState) ───

export type BracketState = { roundIndex: number; pairIndex: number; rounds: number[][] };

export function initBracketState(participantIds: number[]): BracketState {
  return { roundIndex: 0, pairIndex: 0, rounds: [[...participantIds]] };
}

/** Текущая пара участников (по id) или null если турнир завершён */
export function getCurrentPair(state: BracketState | null): [number, number] | null {
  if (!state || !state.rounds[state.roundIndex]) return null;
  const round = state.rounds[state.roundIndex];
  if (round.length === 1) return null; // чемпион
  const i = state.pairIndex * 2;
  if (i + 1 >= round.length) return null;
  return [round[i], round[i + 1]];
}

/** Номер боя (1-based) по текущему pairIndex и пройденным раундам */
export function getFightNumber(state: BracketState | null): number {
  if (!state) return 0;
  let fight = 0;
  for (let r = 0; r < state.roundIndex; r++) {
    const len = state.rounds[r]?.length ?? 0;
    fight += Math.floor(len / 2);
  }
  fight += state.pairIndex;
  return fight + 1;
}

/** После выбора победителя — новый bracketState; если остался 1 — турнир завершён; при нечётном раунде — последний участник получает bye */
export function advanceBracket(state: BracketState, winnerParticipantId: number): BracketState {
  const round = state.rounds[state.roundIndex] ?? [];
  const nextRound = state.rounds[state.roundIndex + 1] ?? [];
  let newNext = [...nextRound, winnerParticipantId];
  let pairIndex = state.pairIndex + 1;
  let roundIndex = state.roundIndex;
  if (pairIndex * 2 >= round.length) {
    if (round.length % 2 === 1) {
      newNext = [...newNext, round[round.length - 1]];
    }
    roundIndex++;
    pairIndex = 0;
  }
  const rounds = [...state.rounds];
  const nextRoundIndex = state.roundIndex + 1;
  if (nextRoundIndex >= rounds.length) rounds.push(newNext);
  else rounds[nextRoundIndex] = newNext;
  return { roundIndex, pairIndex, rounds };
}

const ARENA_MIN_PARTICIPANTS_FOR_BRACKET = 6;

/** Комиссия организатора от призового фонда (10%). Учитывается в объявлениях и смете. */
export const ARENA_COMMISSION_RATE = 0.1;

export function arenaPrizeBreakdown(totalPool: number): { commission: number; toPrizes: number } {
  const commission = Math.floor(totalPool * ARENA_COMMISSION_RATE);
  return { commission, toPrizes: totalPool - commission };
}

const STATUS_LABELS: Record<string, string> = {
  scheduled: 'Набор участников',
  active: 'Идёт',
  completed: 'Завершено',
  cancelled: 'Отменено',
};

/** Эмбед для ветки админки (раздел 5): название, формат, дата, место, пары/команды, призовой фонд, статус */
export function buildAdminManagementEmbed(event: {
  id: number;
  title: string;
  eventType: string;
  scheduledAt: Date;
  entryFee: bigint | number | null;
  prizePoolBonus: number;
  participants: { userId: string; name?: string | null; teamName?: string | null }[];
  status: string;
  place?: string | null;
  totalExpenses?: number;
  teamSize?: bigint | null;
}) {
  const meta = ARENA_EVENT_TYPES[event.eventType] ?? { label: event.eventType, emoji: '🥊' };
  const isTeamFight = event.eventType === 'team_fight';
  const formatLabel = isTeamFight && event.teamSize != null
    ? `${meta.label} (${event.teamSize} на ${event.teamSize})`
    : meta.label;
  const bracketLines = isTeamFight
    ? buildTeamParticipantLines(event.participants)
    : buildBracketLines(event.participants);
  const sectionLabel = isTeamFight ? 'Команды и участники' : 'Турнирная таблица (рейтинг бойцов)';
  const numberedBracket =
    bracketLines.length > 0
      ? bracketLines.map((l, i) => `${i + 1}. ${l}`).join('\n')
      : isTeamFight
        ? '_Пока нет команд_'
        : '_Пока нет пар_';
  const fee = toEntryFeeNum(event.entryFee);
  const prizeFromFees = event.participants.length * fee;
  const totalPool = prizeFromFees + (event.prizePoolBonus ?? 0);
  const { commission, toPrizes } = arenaPrizeBreakdown(totalPool);
  const statusLabel = STATUS_LABELS[event.status] ?? event.status;

  let desc =
    `**Формат турнира:** ${formatLabel}\n\n` +
    `**Дата и время события:** <t:${Math.floor(event.scheduledAt.getTime() / 1000)}:F>\n` +
    `**Когда бой:** <t:${Math.floor(event.scheduledAt.getTime() / 1000)}:R>\n\n`;
  if (event.place?.trim()) desc += `**Место события:** ${event.place.trim()}\n\n`;
  desc += `**${sectionLabel}:**\n${numberedBracket}\n\n`;
  if (isTeamFight && bracketLines.length > 0) {
    const teamNames = bracketLines.map((l) => {
      const m = l.match(/^\*\*(.+?)\*\*/);
      return m ? m[1] : l.split(' — ')[0] ?? l;
    });
    desc += `**В рейтинг командного боя записываются названия команд.** Играют: **${teamNames.join('**, **')}**. Указывайте название точно при создании команды.\n\n`;
  }
  desc += `**Призовой фонд (всего):** ${totalPool} септимов\n`;
  desc += `**Комиссия 10% (в смету):** ${commission} септимов\n`;
  desc += `**На призы:** ${toPrizes} септимов\n`;
  if ((event.totalExpenses ?? 0) > 0) desc += `**Расходы по мероприятию:** ${event.totalExpenses} септимов\n`;
  desc += `**Статус:** ${statusLabel}`;

  const embed = new EmbedBuilder()
    .setTitle(`Управление мероприятием — ${event.title}`)
    .setDescription(desc)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();

  return embed;
}

/** Кнопки управления (в приватной ветке): два ряда */
export function buildAdminManagementButtons(eventId: number, status: string) {
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`arena:adminEditList:${eventId}`)
      .setLabel('Изменить список участников')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`arena:adminAddPrize:${eventId}`)
      .setLabel('Добавить к выигрышу')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`arena:adminStart:${eventId}`)
      .setLabel('Начать событие')
      .setStyle(ButtonStyle.Success),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`arena:adminEquipment:${eventId}`)
      .setLabel('Глянуть снаряжение')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`arena:adminComplete:${eventId}`)
      .setLabel('Завершить событие')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`arena:adminAddExpense:${eventId}`)
      .setLabel('Добавить расход')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`arena:adminSettle:${eventId}`)
      .setLabel('Сформировать итог')
      .setStyle(ButtonStyle.Secondary),
  );
  return [row1, row2];
}

type ParticipantForBracket = { id: number; userId: string; name: string | null };

/** Эмбед «Бой №N» в админ-канале */
export function buildAdminActiveFightEmbed(
  eventTitle: string,
  fightNumber: number,
  p1: ParticipantForBracket,
  p2: ParticipantForBracket,
) {
  const label1 = p1.name?.trim() || `<@${p1.userId}>`;
  const label2 = p2.name?.trim() || `<@${p2.userId}>`;
  return new EmbedBuilder()
    .setTitle(`Бой №${fightNumber}`)
    .setDescription(`**${eventTitle}**\n\n${label1} vs ${label2}\n\nВыберите победителя:`)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();
}

/** Кнопки выбора победителя: [Победитель: A] [Победитель: B] */
export function buildAdminActiveFightButtons(
  eventId: number,
  p1: ParticipantForBracket,
  p2: ParticipantForBracket,
) {
  const label1 = (p1.name?.trim() || 'Игрок 1').slice(0, 80);
  const label2 = (p2.name?.trim() || 'Игрок 2').slice(0, 80);
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`arena:adminWinner:${eventId}:${p1.id}`)
      .setLabel(`Победитель: ${label1}`)
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`arena:adminWinner:${eventId}:${p2.id}`)
      .setLabel(`Победитель: ${label2}`)
      .setStyle(ButtonStyle.Success),
  );
}

/** Эмбед «Турнир завершён» */
export function buildAdminTournamentCompleteEmbed(eventTitle: string, winner: ParticipantForBracket) {
  const label = winner.name?.trim() || `<@${winner.userId}>`;
  return new EmbedBuilder()
    .setTitle('Турнир завершён')
    .setDescription(`**${eventTitle}**\n\n🏆 Победитель: ${label}`)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();
}

/** Отправить в канал арены сообщение «Бой №N. Победитель: @user» или «команда «X»» */
export async function postFightResultToArena(
  client: Client,
  serverId: string,
  eventTitle: string,
  fightNumber: number,
  winnerUserId: string,
  winnerTeamName?: string | null,
): Promise<void> {
  const config = await getServerConfig(serverId);
  const arenaChannelId = (config as { arenaChannelId?: string | null })?.arenaChannelId ?? null;
  if (!arenaChannelId) return;
  const channel = await client.channels.fetch(arenaChannelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;
  const winnerLabel = winnerTeamName?.trim()
    ? `команда «${winnerTeamName}» (<@${winnerUserId}>)`
    : `<@${winnerUserId}>`;
  const embed = new EmbedBuilder()
    .setTitle(`Бой №${fightNumber}`)
    .setDescription(`**${eventTitle}**\n\nПобедитель: ${winnerLabel}`)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();
  await channel.send({ embeds: [embed] }).catch(() => {});
}

/** URL изображения для эмбеда «Ставки на бой» */
const ARENA_BET_EMBED_IMAGE =
  'https://cdn.discordapp.com/attachments/1471462038998880430/1471484722386305176/6ad73f0fc91fc2f2.png';

/** Эмбед + селект «Поставить на бойца» для канала тикетов */
export function buildArenaBetSelectPayload(
  eventId: number,
  eventTitle: string,
  participants: { id: number; userId: string; name: string | null }[],
) {
  const embed = new EmbedBuilder()
    .setTitle('Ставки на турнир')
    .setDescription(`**${eventTitle}**\n\nВыберите бойца, на которого ставите. Выигрыш 1:1 (при победе бойца получите удвоенную сумму).`)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setImage(ARENA_BET_EMBED_IMAGE)
    .setTimestamp();
  const options = participants.slice(0, 25).map((p) => ({
    label: (p.name?.trim() || `Участник`).slice(0, 100),
    value: String(p.id),
    description: `<@${p.userId}>`.slice(0, 100),
  }));
  const select = new StringSelectMenuBuilder()
    .setCustomId(`arena:betSelect:${eventId}`)
    .setPlaceholder('Выберите бойца...')
    .addOptions(options.length ? options : [{ label: '—', value: '0' }]);
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
  return { embeds: [embed], components: [row] };
}

/** Отправить в канал выдачи лог выплат по ставкам на бой; при указании eventId — дублировать в ветку мероприятия */
export async function sendPayoutLogToAccounting(
  client: Client,
  serverId: string,
  payouts: { userId: string; amount: number }[],
  eventId?: number,
): Promise<void> {
  if (payouts.length === 0) return;

  const total = payouts.reduce((s, p) => s + p.amount, 0);
  const lines = payouts.map((p) => `<@${p.userId}> — к выплате **${p.amount}**`);
  const embed = new EmbedBuilder()
    .setTitle('Список победителей ставок')
    .setDescription(lines.join('\n') + `\n\n**Общая сумма выплат: ${total}**`)
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setTimestamp();

  if (eventId) {
    const event = await prisma.event.findUnique({ where: { id: eventId }, select: { adminThreadId: true } });
    if (event?.adminThreadId) {
      const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
      if (thread?.isTextBased()) await thread.send({ embeds: [embed] }).catch(() => {});
    }
  }

  const config = await getServerConfig(serverId);
  const accountingChannelId = (config as { accountingChannelId?: string | null })?.accountingChannelId ?? null;
  if (!accountingChannelId) return;
  const channel = await client.channels.fetch(accountingChannelId).catch(() => null) as TextChannel | null;
  if (channel?.isTextBased()) await channel.send({ embeds: [embed] }).catch(() => {});
}

/** Одна ставка для отображения: кто, на кого, сумма, выиграл/проиграл/сгорела, выплата */
export type SettlementBetRow = {
  userId: string;
  participantName: string;
  amount: number;
  won: boolean;
  payout: number;
  burned?: boolean; // Похоронный: проигравший поставил и выиграл — ставка сгорела, в бизнес
};

/** Сформировать эмбед сметы по мероприятию (выдача: Excel, расходы, заработано, список выплат по ставкам) */
export function buildSettlementEmbed(ev: {
  id: number;
  title: string;
  completedAt: Date | null;
  participants: { id: number; userId: string; name: string | null }[];
  entryFee: number | null;
  prizePoolBonus: number;
  totalExpenses?: number | null;
  bracketState?: unknown;
  eventType?: string;
  paidBets?: { userId: string; amount: number; payout: number }[];
  allBets?: SettlementBetRow[];
  losingBetsTotal?: number;
  burnedBetsTotal?: number;
}) {
  const entrySum = ev.participants.length * toEntryFeeNum(ev.entryFee);
  const bonus = ev.prizePoolBonus ?? 0;
  const totalPool = entrySum + bonus;
  const { commission, toPrizes } = arenaPrizeBreakdown(totalPool);
  const expenses = ev.totalExpenses ?? 0;
  const paidBets = ev.paidBets ?? [];
  const betsPayout = paidBets.reduce((s, b) => s + b.payout, 0);
  const totalPayout = toPrizes + expenses + betsPayout; // Всё, что отдаём: на призы + расходы + выплаты по ставкам
  const balance = -totalPayout; // Баланс — минус, т.к. отдаём
  const losingBetsTotal = ev.losingBetsTotal ?? 0;
  const burnedBetsTotal = ev.burnedBetsTotal ?? 0;
  const businessIncome = losingBetsTotal + burnedBetsTotal + commission - totalPayout; // Проигрышные + сгоревшие + комиссия − к выплате

  let championLabel = '—';
  const state = ev.bracketState as BracketState | null;
  if (state?.rounds?.length) {
    const lastRound = state.rounds[state.rounds.length - 1];
    if (lastRound?.length === 1) {
      const champParticipant = ev.participants.find((p) => p.id === lastRound[0]);
      if (champParticipant) {
        championLabel = champParticipant.name?.trim()
          ? `${champParticipant.name} (<@${champParticipant.userId}>)`
          : `<@${champParticipant.userId}>`;
      }
    }
  }

  let desc =
    `**Дата проведения:** ${ev.completedAt ? `<t:${Math.floor(ev.completedAt.getTime() / 1000)}:F>` : '—'}\n` +
    `**Участников:** ${ev.participants.length}\n` +
    `**🥇 Победитель (1 место):** ${championLabel}\n\n` +
    `**Сумма взносов:** ${entrySum} септимов\n` +
    `**Доп. поступления (к выигрышу):** ${bonus} септимов\n` +
    `**Призовой фонд (всего):** ${totalPool} септимов\n` +
    `**Комиссия организатора 10%:** ${commission} септимов\n` +
    `**На призы:** ${toPrizes} септимов\n` +
    `**💸 Расходы по мероприятию:** ${expenses} септимов\n` +
    `**Итого к выплате (на призы + расходы + ставки):** ${totalPayout} септимов\n\n` +
    `**💰 Баланс:** ${balance} септимов _(отдаём призы, расходы и выплаты по ставкам)_\n\n` +
    `**📊 Доход бизнеса:** ${losingBetsTotal} (проигрышные)${burnedBetsTotal > 0 ? ` + ${burnedBetsTotal} (сгоревшие)` : ''} + ${commission} (комиссия) − ${totalPayout} (к выплате) = **${businessIncome}** септимов\n` +
    `_Выплаты по ставкам на бойцов — с кошельков проигравших, не из призового фонда._`;

  if (paidBets.length > 0) {
    const lines = paidBets.map((b) => `<@${b.userId}> — **${b.payout}** септимов (ставка ${b.amount})`);
    desc += `\n\n**📋 Список к выплате по ставкам (${betsPayout} септимов):**\n${lines.join('\n')}`;
  } else {
    desc += `\n\n**📋 Список к выплате по ставкам:** _нет выигравших_`;
  }

  const allBets = ev.allBets ?? [];
  if (allBets.length > 0) {
    const betLines = allBets.map((b) => {
      const outcome = b.burned ? `🔥 ставка сгорела (ушла в бизнес)` : b.won ? `✅ выиграл **${b.payout}**` : `❌ проиграл ${b.amount}`;
      return `<@${b.userId}> — на ${b.participantName}: ${b.amount} септимов → ${outcome}`;
    });
    desc += `\n\n**🎲 Ставки игроков:**\n${betLines.join('\n')}`;
  }

  const embed = new EmbedBuilder()
    .setTitle(`Итоги мероприятия — ${ev.title}`)
    .setDescription(desc)
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setTimestamp();

  return embed;
}

/** Отправить смету в канал выдачи, отметить settlementSent. Возвращает true, если смета отправлена; false, если уже была отправлена или канал не настроен. */
export async function runSettlementForEvent(client: Client, eventId: number): Promise<boolean> {
  const ev = await prisma.event.findUnique({
    where: { id: eventId },
    include: { participants: true },
  });
  if (!ev || ev.settlementSent) return false;

  const bets = await prisma.eventBet.findMany({
    where: { eventId },
    include: { participant: true },
  });

  const paidBets = bets.filter((b) => b.paid).map((b) => ({
    userId: b.userId,
    amount: b.amount,
    payout: b.amount * 2,
  }));

  const state = ev.bracketState as BracketState | null;
  let championId: number | null = null;
  let funeralLoserUserId: string | null = null;
  if (state?.rounds?.length) {
    const lastRound = state.rounds[state.rounds.length - 1];
    championId = lastRound?.length === 1 ? lastRound[0] : null;
    if (ev.eventType === 'funeral_fight' && championId != null && state.rounds.length >= 2) {
      const finalPair = state.rounds[state.rounds.length - 2] ?? [];
      const loserParticipantId = finalPair.find((id) => id !== championId);
      const loserParticipant = ev.participants.find((p) => p.id === loserParticipantId);
      funeralLoserUserId = loserParticipant?.userId ?? null;
    }
  }

  const allBets: SettlementBetRow[] = [];
  let losingBetsTotal = 0;
  let burnedBetsTotal = 0;
  for (const b of bets) {
    const won = b.participantId === championId;
    const isFuneralLoserBurned = ev.eventType === 'funeral_fight' && funeralLoserUserId && b.userId === funeralLoserUserId && won;
    if (!won) losingBetsTotal += b.amount;
    if (isFuneralLoserBurned) burnedBetsTotal += b.amount;
    const rawName = b.participant.name?.trim();
    const participantName = (rawName && rawName.toLowerCase() !== 'проиграл') ? rawName : `<@${b.participant.userId}>`;
    allBets.push({
      userId: b.userId,
      participantName,
      amount: b.amount,
      won: isFuneralLoserBurned ? false : won,
      payout: isFuneralLoserBurned ? 0 : (won ? b.amount * 2 : 0),
      burned: isFuneralLoserBurned,
    });
  }

  const config = await getServerConfig(ev.serverId);
  const accountingChannelId = (config as { accountingChannelId?: string | null })?.accountingChannelId ?? null;
  if (!accountingChannelId) return false;
  const ch = await client.channels.fetch(accountingChannelId).catch(() => null) as TextChannel | null;
  if (!ch?.isTextBased()) return false;
  const totalPool = ev.participants.length * toEntryFeeNum(ev.entryFee) + (ev.prizePoolBonus ?? 0);
  const { commission, toPrizes } = arenaPrizeBreakdown(totalPool);
  await creditAdminBusinessBalance(ev.serverId, commission);

  const betsPayout = paidBets.reduce((s, b) => s + b.payout, 0);
  const totalPayout = toPrizes + (ev.totalExpenses ?? 0) + betsPayout;
  const businessIncome = losingBetsTotal + burnedBetsTotal + commission - totalPayout;

  const embed = buildSettlementEmbed({
    id: ev.id,
    title: ev.title,
    completedAt: ev.completedAt,
    participants: ev.participants,
    entryFee: ev.entryFee != null ? Number(ev.entryFee) : null,
    prizePoolBonus: ev.prizePoolBonus ?? 0,
    totalExpenses: ev.totalExpenses,
    bracketState: ev.bracketState,
    eventType: ev.eventType,
    paidBets,
    allBets,
    losingBetsTotal,
    burnedBetsTotal,
  });

  const { appendEventToDailyFile } = await import('./excelExport');
  appendEventToDailyFile(ev.serverId, {
    id: ev.id,
    title: ev.title,
    eventType: ev.eventType,
    completedAt: ev.completedAt,
    participants: ev.participants.map((p) => ({
      userId: p.userId,
      name: p.name,
      armorType: p.armorType,
      weaponType: p.weaponType,
      primeTime: p.primeTime,
      paidAmount: p.paidAmount ?? 0,
    })),
    entryFee: ev.entryFee != null ? Number(ev.entryFee) : null,
    totalPool,
    totalExpenses: ev.totalExpenses,
    losingBetsTotal,
    burnedBetsTotal,
    commission,
    totalPayout,
    businessIncome,
  });

  const exportRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`arena:adminExportExcel:${eventId}`)
      .setLabel('Выгрузка в Excel')
      .setStyle(ButtonStyle.Secondary),
  );

  await ch.send({ embeds: [embed], components: [exportRow] }).catch(() => {});
  await prisma.event.update({
    where: { id: eventId },
    data: { settlementSent: true },
  });
  return true;
}

/** Отправить в ветку мероприятия пост «Событие начато» (как в арене) для фиксации */
export async function postEventStartedToAdminThread(
  client: Client,
  eventId: number,
  embed: EmbedBuilder,
): Promise<void> {
  const event = await prisma.event.findUnique({ where: { id: eventId }, select: { adminThreadId: true } });
  if (!event?.adminThreadId) return;
  const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
  if (!thread?.isTextBased()) return;
  await thread.send({
    content: '**Событие начато.** Пост в канал арены отправлен. Фиксация:',
    embeds: [embed],
  }).catch(() => {});
}

/** Уведомить о записи участника: в ветку мероприятия (если есть), иначе в админ-канал */
export async function sendAdminSignUpNotification(
  client: Client,
  serverId: string,
  eventId: number,
  eventTitle: string,
  userId: string,
  participantName: string | null,
): Promise<void> {
  const who = participantName?.trim() ? `${participantName} (<@${userId}>)` : `<@${userId}>`;
  const embed = new EmbedBuilder()
    .setTitle('Запись на событие')
    .setDescription(`Пользователь **${who}** записался на событие **«${eventTitle}»** (#${eventId}).`)
    .setColor(UI_CONFIG.COLORS.EVENT_FIGHT)
    .setTimestamp();

  const event = await prisma.event.findUnique({ where: { id: eventId }, select: { adminThreadId: true } });
  if (event?.adminThreadId) {
    const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
    if (thread?.isTextBased()) await thread.send({ embeds: [embed] }).catch(() => {});
    return;
  }
  const config = await getServerConfig(serverId);
  const adminChannelId = (config as { adminChannelId?: string | null })?.adminChannelId ?? null;
  if (!adminChannelId) return;
  const channel = await client.channels.fetch(adminChannelId).catch(() => null) as TextChannel | null;
  if (channel?.isTextBased()) await channel.send({ embeds: [embed] }).catch(() => {});
}

/** Отправить/обновить сообщение управления в канал админа. Ветка создаётся только при создании мероприятия (allowCreateThread), не при записи участников. */
export async function sendOrUpdateAdminManagement(
  client: Client,
  eventId: number,
  options?: { allowCreateThread?: boolean },
): Promise<void> {
  const event = await getEventWithParticipants(eventId);
  if (!event) return;

  const allowCreateThread = options?.allowCreateThread !== false;

  const config = await getServerConfig(event.serverId);
  const adminChannelId = (config as { adminChannelId?: string | null })?.adminChannelId ?? null;
  if (!adminChannelId) return;

  const channel = await client.channels.fetch(adminChannelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;

  let embed: EmbedBuilder;
  let components: ActionRowBuilder<ButtonBuilder>[];

  if (event.status === 'active' && event.bracketState && typeof event.bracketState === 'object') {
    const state = event.bracketState as BracketState;
    const round = state.rounds[state.roundIndex];
    const championId = round?.length === 1 ? round[0] : null;
    if (championId != null) {
      const winner = event.participants.find((p) => p.id === championId);
      embed = winner
        ? buildAdminTournamentCompleteEmbed(event.title, winner)
        : new EmbedBuilder().setTitle('Турнир завершён').setColor(UI_CONFIG.COLORS.EVENT_FIGHT);
      components = [];
    } else {
      const pair = getCurrentPair(state);
      if (!pair) {
        embed = buildAdminManagementEmbed(event);
        components = buildAdminManagementButtons(eventId, event.status);
      } else {
        const [id1, id2] = pair;
        const p1 = event.participants.find((p) => p.id === id1);
        const p2 = event.participants.find((p) => p.id === id2);
        if (!p1 || !p2) {
          embed = buildAdminManagementEmbed(event);
          components = buildAdminManagementButtons(eventId, event.status);
        } else {
          const fightNumber = getFightNumber(state);
          embed = buildAdminActiveFightEmbed(event.title, fightNumber, p1, p2);
          components = [buildAdminActiveFightButtons(eventId, p1, p2)];
        }
      }
    }
  } else {
    embed = buildAdminManagementEmbed(event);
    components = buildAdminManagementButtons(eventId, event.status);
  }

  const componentRows = components.filter((r) => r.components.length > 0);

  if (event.adminThreadId && event.adminEmbedMessageId) {
    const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
    if (thread?.isTextBased()) {
      try {
        const msg = await thread.messages.fetch(event.adminEmbedMessageId);
        await msg.edit({ embeds: [embed], components: componentRows });
      } catch {
        const sent = await thread.send({ embeds: [embed], components: componentRows });
        await prisma.event.update({ where: { id: eventId }, data: { adminEmbedMessageId: sent.id } });
      }
      return;
    }
  }

  if (event.adminEmbedMessageId) {
    try {
      const msg = await channel.messages.fetch(event.adminEmbedMessageId);
      await msg.edit({ embeds: [embed], components: componentRows });
    } catch {
      if (!allowCreateThread) return;
      const pointerEmbed = new EmbedBuilder()
        .setTitle(`Мероприятие: ${event.title}`)
        .setDescription('Управление — в ветке ниже.')
        .setColor(UI_CONFIG.COLORS.EVENT_FIGHT);
      const mainMsg = await channel.send({ embeds: [pointerEmbed] });
      let updateData: { adminEmbedMessageId: string; adminThreadId?: string } = { adminEmbedMessageId: mainMsg.id };
      try {
        const thread = await mainMsg.startThread({
          name: `Турнир: ${event.title.slice(0, 100)}`,
          reason: 'Ветка мероприятия — запись, финансы, итоги',
        });
        const managementMsg = await thread.send({ embeds: [embed], components: componentRows });
        updateData = { adminEmbedMessageId: managementMsg.id, adminThreadId: thread.id };
      } catch {
        // Ветки отключены — оставляем сообщение в канале
        await mainMsg.edit({ embeds: [embed], components: componentRows });
      }
      await prisma.event.update({ where: { id: eventId }, data: updateData });
    }
  } else if (allowCreateThread) {
    const pointerEmbed = new EmbedBuilder()
      .setTitle(`Мероприятие: ${event.title}`)
      .setDescription('Управление — в ветке ниже.')
      .setColor(UI_CONFIG.COLORS.EVENT_FIGHT);
    const mainMsg = await channel.send({ embeds: [pointerEmbed] });
    let updateData: { adminEmbedMessageId: string; adminThreadId?: string } = { adminEmbedMessageId: mainMsg.id };
    try {
      const thread = await mainMsg.startThread({
        name: `Турнир: ${event.title.slice(0, 100)}`,
        reason: 'Ветка мероприятия — запись, финансы, итоги',
      });
      const managementMsg = await thread.send({ embeds: [embed], components: componentRows });
      updateData = { adminEmbedMessageId: managementMsg.id, adminThreadId: thread.id };
    } catch {
      await mainMsg.edit({ embeds: [embed], components: componentRows });
    }
    await prisma.event.update({ where: { id: eventId }, data: updateData });
  }
}

/** Хелпер: обновить эмбед управления без создания ветки (при записи/снятии участников) */
export async function updateAdminManagementOnly(client: Client, eventId: number): Promise<void> {
  return sendOrUpdateAdminManagement(client, eventId, { allowCreateThread: false });
}

/** Удалить сообщения мероприятия из админ-канала (родительское «Мероприятие: X» и ветку). */
export async function deleteAdminEventMessages(
  client: Client,
  event: { id: number; serverId: string; adminEmbedMessageId?: string | null; adminThreadId?: string | null },
): Promise<void> {
  if (!event.adminThreadId && !event.adminEmbedMessageId) return;

  const config = await getServerConfig(event.serverId);
  const adminChannelId = (config as { adminChannelId?: string | null })?.adminChannelId ?? null;
  if (!adminChannelId) return;

  const channel = await client.channels.fetch(adminChannelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;

  try {
    if (event.adminThreadId) {
      const thread = await client.channels.fetch(event.adminThreadId).catch(() => null);
      if (thread?.isThread?.()) {
        const starterMsg = await thread.fetchStarterMessage().catch(() => null);
        await thread.delete().catch(() => {});
        if (starterMsg) await starterMsg.delete().catch(() => {});
      }
    } else if (event.adminEmbedMessageId) {
      const msg = await channel.messages.fetch(event.adminEmbedMessageId).catch(() => null);
      if (msg) await msg.delete().catch(() => {});
    }
    await prisma.event.update({
      where: { id: event.id },
      data: { adminEmbedMessageId: null, adminThreadId: null },
    });
  } catch (err) {
    console.error('[Events] Failed to delete admin event messages:', err);
  }
}

export async function getUpcomingEvents(serverId: string) {
  return prisma.event.findMany({
    where: {
      serverId,
      status: { in: ['scheduled', 'active'] },
      scheduledAt: { gte: new Date() },
    },
    orderBy: { scheduledAt: 'asc' },
    take: 15,
  });
}

export async function getEventById(id: number) {
  return prisma.event.findUnique({ where: { id } });
}

/** Активное событие арены (status=active) для сервера — для панели ставок в тикетах */
export async function getActiveArenaEvent(serverId: string) {
  return prisma.event.findFirst({
    where: { serverId, status: 'active' },
    include: { participants: true },
    orderBy: { updatedAt: 'desc' },
  });
}

export async function cancelEvent(id: number) {
  return prisma.event.update({
    where: { id },
    data: { status: 'cancelled' },
  });
}

export async function completeEvent(id: number) {
  return prisma.event.update({
    where: { id },
    data: { status: 'completed' },
  });
}

// ─── Discord Scheduled Event (приглашение, не эмбед) ───

type OurEvent = {
  id: number;
  serverId: string;
  title: string;
  description: string;
  eventType: string;
  scheduledAt: Date;
  discordScheduledEventId?: string | null;
};

/** Создаёт или возвращает существующее Discord-событие, сохраняет id в БД. */
async function ensureDiscordScheduledEvent(
  client: Client,
  event: OurEvent,
  voiceChannelId?: string | null,
): Promise<{ url: string } | null> {
  try {
    const guild = await client.guilds.fetch(event.serverId).catch(() => null) as Guild | null;
    if (!guild) return null;

    const meta = getEventMeta(event.eventType);
    const name = `${meta.emoji} ${event.title}`.slice(0, 100);
    const description = (event.description || '').slice(0, 1000);
    const start = new Date(event.scheduledAt);
    const end = new Date(start.getTime() + 4 * 60 * 60 * 1000); // +4 часа

    if (event.discordScheduledEventId) {
      const existing = await guild.scheduledEvents.fetch(event.discordScheduledEventId).catch(() => null);
      if (existing?.url) return { url: existing.url };
    }

    let useVoiceChannel: string | null = null;
    if (voiceChannelId) {
      const ch = await client.channels.fetch(voiceChannelId).catch(() => null);
      if (ch?.type === ChannelType.GuildVoice) useVoiceChannel = voiceChannelId;
    }

    const options = useVoiceChannel
      ? {
          name,
          description: description || undefined,
          scheduledStartTime: start,
          scheduledEndTime: end,
          privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
          entityType: GuildScheduledEventEntityType.Voice,
          channel: useVoiceChannel,
        }
      : {
          name,
          description: description || undefined,
          scheduledStartTime: start,
          scheduledEndTime: end,
          privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
          entityType: GuildScheduledEventEntityType.External,
          entityMetadata: { location: 'Крысиная Нора' },
        };

    const scheduledEvent = await guild.scheduledEvents.create(options);
    await prisma.event.update({
      where: { id: event.id },
      data: { discordScheduledEventId: scheduledEvent.id } as Record<string, unknown>,
    });
    return { url: scheduledEvent.url };
  } catch (err) {
    console.error('[Events] Failed to create Discord scheduled event:', err);
    return null;
  }
}

/** Кнопки под приглашением (как на скриншоте). */
function buildEventInviteButtons(eventId: number) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`event:signUp:${eventId}`)
      .setLabel('Записаться на бои.')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`event:unsign:${eventId}`)
      .setLabel('Отменить заявку на бой. (если создал заявку)')
      .setStyle(ButtonStyle.Secondary),
  );
}

/** Отправляет в канал приглашение на мероприятие (ссылка разворачивается в карточку) и кнопки. */
async function sendEventInviteToChannel(
  client: Client,
  channelId: string,
  event: OurEvent,
  eventUrl: string,
): Promise<string | null> {
  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (!channel?.isTextBased()) return null;
    const msg = await channel.send({
      content: eventUrl,
      components: [buildEventInviteButtons(event.id)],
    });
    return msg.id;
  } catch (err) {
    console.error(`[Events] Failed to send event invite to ${channelId}:`, err);
    return null;
  }
}

// ─── Отправка embed в канал ───

async function sendToChannel(client: Client, channelId: string, embed: EmbedBuilder): Promise<string | null> {
  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (channel?.isTextBased()) {
      const msg = await channel.send({ embeds: [embed] });
      return msg.id;
    }
  } catch (err) {
    console.error(`[Events] Failed to send to channel ${channelId}:`, err);
  }
  return null;
}

async function getAnnounceChannel(serverId: string, eventChannelId?: string | null): Promise<string | null> {
  if (eventChannelId) return eventChannelId;
  const config = await getServerConfig(serverId);
  return config?.announceChannelId ?? null;
}

// ─── Планировщик (запускается каждую минуту) ───

let schedulerInterval: ReturnType<typeof setInterval> | null = null;

export function startEventScheduler(client: Client) {
  if (schedulerInterval) return;

  // Первый запуск через 10 секунд после старта
  setTimeout(() => tick(client), 10_000);

  // Затем каждые 60 секунд
  schedulerInterval = setInterval(() => tick(client), 60_000);

  console.log('[Events] Scheduler started (interval: 60s)');
}

export function stopEventScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log('[Events] Scheduler stopped');
  }
}

async function tick(client: Client) {
  try {
    const now = new Date();

    // Все запланированные события, которые ещё не завершены / не отменены
    const events = await prisma.event.findMany({
      where: {
        status: { in: ['scheduled', 'active'] },
      },
    });

    for (const event of events) {
      const msUntil = event.scheduledAt.getTime() - now.getTime();
      const minutesUntil = msUntil / 60_000;

      const channelId = await getAnnounceChannel(event.serverId, event.channelId);
      if (!channelId) continue;

      // Первый анонс — приглашение Discord (карточка с «Интересно»), не эмбед
      if (!event.announced) {
        const config = await getServerConfig(event.serverId);
        const voiceChannelId = (config as { eventVoiceChannelId?: string | null } | null)?.eventVoiceChannelId ?? null;
        const invite = await ensureDiscordScheduledEvent(client, event, voiceChannelId);
        const msgId = invite
          ? await sendEventInviteToChannel(client, channelId, event, invite.url)
          : await sendToChannel(client, channelId, buildEventAnnouncementEmbed(event));
        await prisma.event.update({
          where: { id: event.id },
          data: { announced: true, messageId: msgId },
        });
      }

      // Напоминание за 1 день в ЛС участникам (для событий с участниками)
      const reminder1d = (event as { reminder1d?: boolean }).reminder1d;
      if (!reminder1d && minutesUntil <= 24 * 60 && minutesUntil > 60) {
        const participants = await getEventParticipants(event.id);
        const dateStr = formatDate(event.scheduledAt);
        for (const p of participants) {
          try {
            const user = await client.users.fetch(p.userId).catch(() => null);
            if (user) {
              await user.send({
                content: `Напоминание: вы записаны на событие **«${event.title}»**. Оно состоится **через день** (${dateStr}). Не пропустите!`,
              }).catch(() => {});
            }
          } catch {
            // ЛС закрыты или пользователь не найден
          }
        }
        await prisma.event.update({
          where: { id: event.id },
          data: { reminder1d: true },
        });
      }

      // Напоминание за 1 час
      if (!event.reminder1h && minutesUntil <= 60 && minutesUntil > 15) {
        const embed = buildReminderEmbed(event, 'через ~1 час');
        await sendToChannel(client, channelId, embed);
        await prisma.event.update({
          where: { id: event.id },
          data: { reminder1h: true },
        });
      }

      // Напоминание за 15 минут
      if (!event.reminder15m && minutesUntil <= 15 && minutesUntil > 0) {
        const embed = buildReminderEmbed(event, 'через ~15 минут');
        await sendToChannel(client, channelId, embed);
        await prisma.event.update({
          where: { id: event.id },
          data: { reminder15m: true },
        });
      }

      // Старт события
      if (minutesUntil <= 0 && event.status === 'scheduled') {
        const embed = buildEventStartEmbed(event);
        await sendToChannel(client, channelId, embed);
        await prisma.event.update({
          where: { id: event.id },
          data: { status: 'active' },
        });
      }

      // Авто-завершение через 4 часа после старта
      if (event.status === 'active' && minutesUntil <= -240) {
        await prisma.event.update({
          where: { id: event.id },
          data: { status: 'completed', completedAt: new Date() },
          include: { participants: true },
        });
        await deleteArenaBetMessage(client, event.id);
        await runSettlementForEvent(client, event.id);
      }
    }

    // Удаление веток мероприятий: через 3 дня после завершения (ветка и кнопки доступны всё это время)
    const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
    const toDeleteAdmin = await prisma.event.findMany({
      where: {
        status: 'completed',
        completedAt: { not: null, lte: threeDaysAgo },
        OR: [
          { adminThreadId: { not: null } },
          { adminEmbedMessageId: { not: null } },
        ],
      },
    });
    for (const ev of toDeleteAdmin) {
      await deleteAdminEventMessages(client, ev);
    }

    // Смета в выдача: через 4 дня после завершения мероприятия
    const fourDaysAgo = new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000);
    const toSettle = await prisma.event.findMany({
      where: {
        status: 'completed',
        settlementSent: false,
        completedAt: { not: null, lte: fourDaysAgo },
      },
      include: { participants: true },
    });
    for (const ev of toSettle) {
      await runSettlementForEvent(client, ev.id);
    }
  } catch (err) {
    console.error('[Events] Scheduler tick error:', err);
  }
}

// ─── Ручная рассылка шаблона ───

export async function broadcastTemplate(
  client: Client,
  serverId: string,
  templateKey: string,
  channelId?: string,
): Promise<boolean> {
  const template = BROADCAST_TEMPLATES[templateKey];
  if (!template) return false;

  const targetChannelId = channelId ?? (await getAnnounceChannel(serverId, null));
  if (!targetChannelId) return false;

  const embed = template.build();
  await sendToChannel(client, targetChannelId, embed);
  return true;
}

// ─── Ручной анонс конкретного события ───

export async function forceAnnounceEvent(
  client: Client,
  eventId: number,
): Promise<boolean> {
  const event = await getEventById(eventId);
  if (!event) return false;

  const channelId = await getAnnounceChannel(event.serverId, event.channelId);
  if (!channelId) return false;

  const config = await getServerConfig(event.serverId);
  const voiceChannelId = (config as { eventVoiceChannelId?: string | null } | null)?.eventVoiceChannelId ?? null;
  const invite = await ensureDiscordScheduledEvent(client, event, voiceChannelId);
  const msgId = invite
    ? await sendEventInviteToChannel(client, channelId, event, invite.url)
    : await sendToChannel(client, channelId, buildEventAnnouncementEmbed(event));
  await prisma.event.update({
    where: { id: event.id },
    data: { announced: true, messageId: msgId },
  });
  return true;
}
