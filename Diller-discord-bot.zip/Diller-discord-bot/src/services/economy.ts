import { prisma } from '../db/client';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { ENV } from '../config/env';

function scheduleMultiAccountCheck(serverId: string, userId: string) {
  Promise.all([import('./antifraud'), import('./logs')]).then(([antifraud, logs]) => {
    const client = logs.getLogClient();
    if (client) {
      antifraud.checkMultiAccountActivity(client, serverId, userId).catch(() => {});
    }
  }).catch(() => {});
}

export async function getOrCreateProfile(serverId: string, userId: string) {
  const existing = await prisma.userProfile.findUnique({
    where: {
      userId_serverId: { userId, serverId },
    },
  });

  if (existing) return existing;

  const config = await ensureServerConfig(serverId);

  const profile = await prisma.userProfile.create({
    data: {
      userId,
      serverId,
      balance: BigInt(config.startBalance),
    },
  });

  // Проверка мультиаккаунта при создании нового профиля
  scheduleMultiAccountCheck(serverId, userId);

  return profile;
}

export async function adjustBalance(options: {
  serverId: string;
  userId: string;
  delta: number;
  reason: string;
}) {
  const { serverId, userId, delta, reason } = options;

  const profile = await getOrCreateProfile(serverId, userId);

  const deltaBig = BigInt(Math.floor(delta));
  const balance = BigInt(Number(profile.balance) || 0);
  const totalWon = BigInt(Number(profile.totalWon ?? 0) || 0);
  const totalLost = BigInt(Number(profile.totalLost ?? 0) || 0);

  const updateData: Record<string, unknown> = {
    balance: balance + deltaBig,
  };

  // Обновляем totalWon / totalLost
  if (delta > 0 && (reason.endsWith('_payout') || reason.endsWith('_win') || reason === 'blind_win' || reason === 'duel_win')) {
    updateData.totalWon = totalWon + deltaBig;
  } else if (delta < 0 && (reason.endsWith('_bet') || reason === 'blind_ante' || reason === 'blind_buyin' || reason === 'blind_raise' || reason === 'duel_bet')) {
    updateData.totalLost = totalLost + BigInt(Math.floor(Math.abs(delta)));
  }

  const updated = await prisma.userProfile.update({
    where: { userId_serverId: { userId, serverId } },
    data: updateData,
  });

  await prisma.balanceLog.create({
    data: {
      serverId,
      userId,
      change: delta,
      reason,
    },
  });

  // Лог изменения баланса в лог-канал (не блокируем)
  import('./logs').then(logs => {
    logs.logBalanceChange({ serverId, userId, delta, reason, newBalance: Number(updated.balance) }).catch(() => {});
  }).catch(() => {});

  return updated;
}

export async function getBalance(serverId: string, userId: string): Promise<bigint> {
  const profile = await getOrCreateProfile(serverId, userId);
  return profile.balance;
}

export async function claimDaily(serverId: string, userId: string) {
  const config = await ensureServerConfig(serverId);
  const profile = await getOrCreateProfile(serverId, userId);

  const now = new Date();
  const last = profile.lastDailyAt;

  if (last && now.getTime() - last.getTime() < 24 * 60 * 60 * 1000) {
    const nextAt = new Date(last.getTime() + 24 * 60 * 60 * 1000);
    return {
      ok: false as const,
      nextAt,
    };
  }

  const balance = typeof profile.balance === 'bigint' ? profile.balance : BigInt(profile.balance);
  const updated = await prisma.userProfile.update({
    where: { userId_serverId: { userId, serverId } },
    data: {
      balance: balance + BigInt(config.dailyBonus),
      lastDailyAt: now,
    },
  });

  await prisma.balanceLog.create({
    data: {
      serverId,
      userId,
      change: config.dailyBonus,
      reason: 'daily_bonus',
    },
  });

  return {
    ok: true as const,
    amount: config.dailyBonus,
    profile: updated,
  };
}

export async function getTopRich(serverId: string, limit = 10) {
  const users = await prisma.userProfile.findMany({
    where: { serverId },
    orderBy: { balance: 'desc' },
    take: limit,
  });
  return users;
}

/** PvP-игры, где победа = один побеждённый оппонент */
const PVP_GAME_TYPES = ['duel', 'blind', 'intervention', 'dice_pvp'];

/** Топ по количеству побеждённых оппонентов (победы в дуэлях, слепой, интервенции, кости PvP). */
export async function getTopByDefeatedOpponents(serverId: string, limit = 10): Promise<{ userId: string; defeatedCount: number }[]> {
  const rows = await prisma.betLog.groupBy({
    by: ['userId'],
    where: {
      serverId,
      gameType: { in: PVP_GAME_TYPES },
      outcome: 'lose',
    },
    _count: { id: true },
  });
  rows.sort((a, b) => (b._count?.id ?? 0) - (a._count?.id ?? 0));
  return rows.slice(0, limit).map((r) => ({
    userId: r.userId,
    defeatedCount: r._count?.id ?? 0,
  }));
}

/** Количество побед в боях (PvP) для пользователя. */
export async function getBattleWinsCount(serverId: string, userId: string): Promise<number> {
  const count = await prisma.betLog.count({
    where: {
      serverId,
      userId,
      gameType: { in: PVP_GAME_TYPES },
      outcome: 'lose',
    },
  });
  return count;
}

/** Форматы арены для рейтинга (белый флаг, командный, похоронный) */
export const ARENA_FIGHT_TYPES = ['white_flag', 'team_fight', 'funeral_fight'] as const;

/** Топ по победам в боях арены (по формату). Для team_fight — по teamName, иначе по userId. */
export async function getTopByArenaFightWins(
  serverId: string,
  eventType: string,
  limit = 5,
): Promise<{ userId?: string; teamName?: string; winsCount: number }[]> {
  if (eventType === 'team_fight') {
    const rows = await prisma.arenaFightWin.groupBy({
      by: ['teamName'],
      where: { serverId, eventType, teamName: { not: null } },
      _count: { id: true },
    });
    rows.sort((a, b) => (b._count?.id ?? 0) - (a._count?.id ?? 0));
    return rows.slice(0, limit).map((r) => ({
      teamName: r.teamName ?? undefined,
      winsCount: r._count?.id ?? 0,
    }));
  }
  const rows = await prisma.arenaFightWin.groupBy({
    by: ['userId'],
    where: { serverId, eventType },
    _count: { id: true },
  });
  rows.sort((a, b) => (b._count?.id ?? 0) - (a._count?.id ?? 0));
  return rows.slice(0, limit).map((r) => ({
    userId: r.userId,
    winsCount: r._count?.id ?? 0,
  }));
}

/** Для team_fight: состав команд. Игрок приписан к команде, где у него больше побед. */
export async function getTeamFightRosters(
  serverId: string,
  teamNames: string[],
): Promise<Record<string, { userId: string; winsInTeam: number }[]>> {
  if (teamNames.length === 0) return {};
  const all = await prisma.arenaFightWin.findMany({
    where: { serverId, eventType: 'team_fight', teamName: { not: null, in: teamNames } },
    select: { userId: true, teamName: true },
  });
  const winsByUserAndTeam = new Map<string, Map<string, number>>();
  for (const r of all) {
    const team = r.teamName ?? '';
    if (!team) continue;
    let userMap = winsByUserAndTeam.get(r.userId);
    if (!userMap) {
      userMap = new Map();
      winsByUserAndTeam.set(r.userId, userMap);
    }
    userMap.set(team, (userMap.get(team) ?? 0) + 1);
  }
  const roster: Record<string, { userId: string; winsInTeam: number }[]> = {};
  for (const team of teamNames) roster[team] = [];
  for (const [userId, teamWins] of winsByUserAndTeam) {
    let bestTeam = '';
    let bestWins = 0;
    for (const [team, wins] of teamWins) {
      if (wins > bestWins || (wins === bestWins && team.localeCompare(bestTeam) < 0)) {
        bestWins = wins;
        bestTeam = team;
      }
    }
    if (bestTeam && roster[bestTeam]) {
      roster[bestTeam].push({ userId, winsInTeam: bestWins });
    }
  }
  for (const team of teamNames) {
    roster[team].sort((a, b) => b.winsInTeam - a.winsInTeam);
  }
  return roster;
}

/** Статистика игр пользователя из BetLog: количество игр, побед, поражений, винрейт. */
export async function getUserGameStats(serverId: string, userId: string): Promise<{
  totalGames: number;
  wins: number;
  losses: number;
  winrate: number;
}> {
  const [total, wins, losses] = await Promise.all([
    prisma.betLog.count({ where: { serverId, userId } }),
    prisma.betLog.count({ where: { serverId, userId, outcome: 'win' } }),
    prisma.betLog.count({ where: { serverId, userId, outcome: 'lose' } }),
  ]);
  const decisive = wins + losses;
  const winrate = decisive > 0 ? Math.round((wins / decisive) * 100) : 0;
  return { totalGames: total, wins, losses, winrate };
}

/** Количество побед в боях арены по формату (или суммарно). */
export async function getArenaFightWinsCount(
  serverId: string,
  userId: string,
  eventType?: string,
): Promise<number> {
  const where: { serverId: string; userId: string; eventType?: string } = {
    serverId,
    userId,
  };
  if (eventType) where.eventType = eventType;
  return prisma.arenaFightWin.count({ where });
}

/**
 * Проверяет, имеет ли пользователь VIP-роль на сервере.
 * memberRoleIds - массив ID ролей, которые есть у пользователя.
 */
export async function isVip(serverId: string, memberRoleIds: string[]): Promise<boolean> {
  const config = await getServerConfig(serverId);
  if (!config) return false;

  const vipRole = config.roles.find((r: any) => r.type === 'VIP');
  if (!vipRole) return false;

  return memberRoleIds.includes(vipRole.roleId);
}

/**
 * Возвращает множитель VIP-роли (1.0 если нет VIP, 1.25 если VIP).
 */
export async function getVipMultiplier(serverId: string, memberRoleIds: string[]): Promise<number> {
  const vip = await isVip(serverId, memberRoleIds);
  return vip ? 1.25 : 1.0;
}

/**
 * Рассчитывает итоговую выплату с учётом:
 *  - DEFAULT_RTP (базовый возврат)
 *  - commission (комиссия с выигрыша, 0.02 = 2%; если не передана — из ENV)
 *  - VIP-множитель
 */
export function calculatePayout(
  rawPayout: number,
  vipMultiplier: number,
  commission?: number,
): number {
  const comm = commission ?? ENV.GLOBAL_COMMISSION;
  const afterRtp = rawPayout * ENV.DEFAULT_RTP;
  const afterCommission = afterRtp * (1 - comm);
  const afterVip = afterCommission * vipMultiplier;
  return Math.floor(afterVip);
}

/** Зачислить комиссию с выигрыша на бизнес-счёт админа (если настроен). Вызывать при выплате в играх. */
export async function creditAdminCommissionFromPayout(
  serverId: string,
  rawPayout: number,
  commissionRate?: number,
): Promise<void> {
  if (rawPayout <= 0) return;
  const comm = commissionRate ?? ENV.GLOBAL_COMMISSION;
  const amount = Math.floor(rawPayout * ENV.DEFAULT_RTP * comm);
  if (amount <= 0) return;
  const { creditAdminBusinessBalance } = await import('../config/serverConfigService');
  await creditAdminBusinessBalance(serverId, amount);
}


