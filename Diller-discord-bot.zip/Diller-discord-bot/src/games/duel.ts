import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  EmbedBuilder,
  ModalBuilder,
  ModalSubmitInteraction,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance, calculatePayout, getVipMultiplier } from '../services/economy';
import { logBet } from '../services/logs';
import { setSession, getSession, deleteSession } from '../services/sessions';
import { redis } from '../db/redis';

// Колода игрока: карты 1–10. Сохраняется в Redis, уменьшается после каждого хода.
interface DuelSession {
  attackerId: string;
  opponentId: string;
  betAmount: number;
  seed: string;
  attackerDeck: number[];
  opponentDeck: number[];
  attackerScore: number;
  opponentScore: number;
  round: number;
  maxRounds: number;
  phase: 'pending' | 'bet' | 'playing' | 'done';
  attackerRoleIds: string[];
  opponentRoleIds: string[];
}

function freshDeck(): number[] {
  return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
}

function drawFromDeck(deck: number[]): { card: number; remaining: number[] } {
  const idx = crypto.randomInt(0, deck.length);
  const card = deck[idx];
  const remaining = [...deck.slice(0, idx), ...deck.slice(idx + 1)];
  return { card, remaining };
}

function duelKey(serverId: string, attackerId: string, opponentId: string) {
  const sorted = [attackerId, opponentId].sort();
  return `duel:${serverId}:${sorted[0]}:${sorted[1]}`;
}

export function buildDuelChallengeEmbed(attackerId: string, opponentId: string) {
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DUEL} Гвинт: Дуэль`)
    .setDescription(
      `<@${attackerId}> вызывает на дуэль <@${opponentId}>!\n\n` +
        '*Упрощённая дуэль: вытяни карту сильнее. Никаких рядов — чистое сравнение.*\n\n' +
        '**Как играть:**\n' +
        'У каждого колода из 10 карт (1–10). Оба тянут по 1 карте — кто больше, забирает очко.\n' +
        '3 раунда. Карта сбрасывается после хода. Проигравший платит ставку септимов.\n\n' +
        `<@${opponentId}>, принять вызов или отказаться?`,
    )
    .setColor(UI_CONFIG.COLORS.DUEL);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`duel:accept:${attackerId}:${opponentId}`)
      .setLabel('Принять')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`duel:decline:${attackerId}:${opponentId}`)
      .setLabel('Отказаться')
      .setStyle(ButtonStyle.Danger),
  );

  return { embeds: [embed], components: [row] };
}

export async function handleDuelButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const serverId = interaction.guild.id;
  const { customId } = interaction;
  const parts = customId.split(':');
  const action = parts[1]; // accept, decline, bet, draw
  const attackerId = parts[2];
  const opponentId = parts[3];

  if (action === 'decline') {
    if (interaction.user.id !== opponentId) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только вызванный игрок может ответить.`, flags: MessageFlags.Ephemeral });
    }

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DUEL} Дуэль отклонена`)
      .setDescription(`<@${opponentId}> не вышел на опилки.`)
      .setColor(UI_CONFIG.COLORS.DUEL);

    return interaction.update({ embeds: [embed], components: [] });
  }

  if (action === 'accept') {
    if (interaction.user.id !== opponentId) {
      return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только вызванный игрок может принять.`, flags: MessageFlags.Ephemeral });
    }

    const key = duelKey(serverId, attackerId, opponentId);
    const attackerMember = interaction.guild?.members.cache.get(attackerId);
    const opponentMember = interaction.guild?.members.cache.get(opponentId);
    const attackerRoleIds: string[] = attackerMember?.roles.cache.map(r => r.id) ?? [];
    const opponentRoleIds: string[] = opponentMember?.roles.cache.map(r => r.id) ?? [];
    const session: DuelSession = {
      attackerId,
      opponentId,
      betAmount: 0,
      seed: crypto.randomUUID(),
      attackerDeck: freshDeck(),
      opponentDeck: freshDeck(),
      attackerScore: 0,
      opponentScore: 0,
      round: 0,
      maxRounds: 3,
      phase: 'bet',
      attackerRoleIds,
      opponentRoleIds,
    };
    await setSession(key, session);

    // Предлагаем атакующему сделать ставку
    const modal = new ModalBuilder()
      .setCustomId(`duel:betModal:${attackerId}:${opponentId}`)
      .setTitle('Дуэль — ставка септимов');

    const input = new TextInputBuilder()
      .setCustomId('bet_amount')
      .setLabel('Сумма ставки')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(input),
    );

    return interaction.showModal(modal);
  }

  if (action === 'draw') {
    return handleDuelDraw(interaction, serverId, attackerId, opponentId);
  }
}

export async function handleDuelBetModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const serverId = interaction.guild.id;
  const parts = interaction.customId.split(':');
  const attackerId = parts[2];
  const opponentId = parts[3];
  const key = duelKey(serverId, attackerId, opponentId);

  const session = await getSession<DuelSession>(key);
  if (!session || session.phase !== 'bet') {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия не найдена.`, flags: MessageFlags.Ephemeral });
  }

  const betRaw = interaction.fields.getTextInputValue('bet_amount');
  const betAmount = Number.parseInt(betRaw, 10);
  if (Number.isNaN(betAmount) || betAmount <= 0) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Некорректная ставка.`, flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(serverId);
  if (betAmount < config.minBet || betAmount > config.maxBet) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ставка: ${config.minBet}–${config.maxBet}.`, flags: MessageFlags.Ephemeral });
  }

  // Проверяем баланс обоих
  const ap = await getOrCreateProfile(serverId, attackerId);
  const op = await getOrCreateProfile(serverId, opponentId);

  if (ap.balance < BigInt(betAmount)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} У вызывающего недостаточно средств.`, flags: MessageFlags.Ephemeral });
  }
  if (op.balance < BigInt(betAmount)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} У оппонента недостаточно средств.`, flags: MessageFlags.Ephemeral });
  }

  // Списываем ставку с обоих
  await adjustBalance({ serverId, userId: attackerId, delta: -betAmount, reason: 'duel_bet' });
  await adjustBalance({ serverId, userId: opponentId, delta: -betAmount, reason: 'duel_bet' });

  session.betAmount = betAmount;
  session.phase = 'playing';
  session.round = 1;
  await setSession(key, session);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DUEL} Дуэль — Раунд ${session.round}/${session.maxRounds}`)
    .setDescription(
      `Ставка: **${betAmount}** септимов с каждого (банк: **${betAmount * 2}**)\n` +
        `<@${attackerId}> 🆚 <@${opponentId}>\n\n` +
        `Счёт: **${session.attackerScore}** : **${session.opponentScore}**\n\n` +
        '**Тянуть карту** — тянем и сравниваем.',
    )
    .setColor(UI_CONFIG.COLORS.DUEL);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`duel:draw:${attackerId}:${opponentId}`)
      .setLabel('Тянуть карту')
      .setStyle(ButtonStyle.Primary),
  );

  return interaction.reply({ embeds: [embed], components: [row] });
}

async function handleDuelDraw(
  interaction: ButtonInteraction,
  serverId: string,
  attackerId: string,
  opponentId: string,
) {
  const userId = interaction.user.id;
  if (userId !== attackerId && userId !== opponentId) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Только участники дуэли могут нажимать эту кнопку.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const key = duelKey(serverId, attackerId, opponentId);
  const session = await getSession<DuelSession>(key);
  if (!session || session.phase !== 'playing') {
    return interaction.update({ content: `${UI_CONFIG.EMOJI.ERROR} Сессия завершена.`, embeds: [], components: [] });
  }

  // Оба тянут карту
  const aResult = drawFromDeck(session.attackerDeck);
  const oResult = drawFromDeck(session.opponentDeck);

  session.attackerDeck = aResult.remaining;
  session.opponentDeck = oResult.remaining;

  const aCard = aResult.card;
  const oCard = oResult.card;

  const lines: string[] = [];
  lines.push(`**Раунд ${session.round}/${session.maxRounds}**\n`);
  lines.push(`<@${attackerId}> вытянул: **${aCard}**`);
  lines.push(`<@${opponentId}> вытянул: **${oCard}**`);

  if (aCard > oCard) {
    session.attackerScore++;
    lines.push(`\nОчко берёт <@${attackerId}>!`);
  } else if (oCard > aCard) {
    session.opponentScore++;
    lines.push(`\nОчко берёт <@${opponentId}>!`);
  } else {
    lines.push(`\nНичья в раунде - никто не получает очко.`);
  }

  lines.push(`\nСчёт: **${session.attackerScore}** : **${session.opponentScore}**`);
  lines.push(`Карт в колоде: ${session.attackerDeck.length} / ${session.opponentDeck.length}`);

  session.round++;

  if (session.round > session.maxRounds || session.attackerDeck.length === 0 || session.opponentDeck.length === 0) {
    // Финал
    session.phase = 'done';
    await deleteSession(key);

    let winnerId: string | null = null;
    if (session.attackerScore > session.opponentScore) winnerId = attackerId;
    else if (session.opponentScore > session.attackerScore) winnerId = opponentId;

    const rawPot = session.betAmount * 2;
    const winnerRoleIds = winnerId === attackerId ? session.attackerRoleIds : session.opponentRoleIds;
    const vipMul = winnerId ? await getVipMultiplier(serverId, winnerRoleIds) : 1;
    const config = await getServerConfig(serverId);
    const pot = winnerId ? calculatePayout(rawPot, vipMul, config?.casinoCommission) : rawPot;
    if (winnerId) {
      const { creditAdminCommissionFromPayout } = await import('../services/economy');
      await creditAdminCommissionFromPayout(serverId, rawPot, config?.casinoCommission);
      await adjustBalance({ serverId, userId: winnerId, delta: pot, reason: 'duel_win' });
      await logBet({
        serverId, userId: winnerId, gameType: 'duel',
        betAmount: session.betAmount, payoutAmount: pot, outcome: 'win', seed: session.seed,
      });
      const loserId = winnerId === attackerId ? opponentId : attackerId;
      await logBet({
        serverId, userId: loserId, gameType: 'duel',
        betAmount: session.betAmount, payoutAmount: 0, outcome: 'lose', seed: session.seed,
      });
      lines.push(`\n${UI_CONFIG.EMOJI.WIN} Победитель: <@${winnerId}> забирает **${pot}**!`);
    } else {
      // Ничья - возврат
      await adjustBalance({ serverId, userId: attackerId, delta: session.betAmount, reason: 'duel_draw' });
      await adjustBalance({ serverId, userId: opponentId, delta: session.betAmount, reason: 'duel_draw' });
      lines.push(`\nНичья! Ставки возвращены.`);
    }

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.DUEL} Дуэль — Результат`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.DUEL);

    return interaction.update({ embeds: [embed], components: [] });
  }

  await setSession(key, session);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DUEL} Дуэль — Раунд ${session.round}/${session.maxRounds}`)
    .setDescription(lines.join('\n') + '\n\n**Тянуть карту** — следующий раунд.')
    .setColor(UI_CONFIG.COLORS.DUEL);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`duel:draw:${attackerId}:${opponentId}`)
      .setLabel('Тянуть карту')
      .setStyle(ButtonStyle.Primary),
  );

  return interaction.update({ embeds: [embed], components: [row] });
}

/** Запуск Дуэли из лобби: 2 игрока — сразу 1v1; >2 — очередь (2 играют, остальные ждут). */
export async function startDuelFromLobby(
  thread: import('discord.js').ThreadChannel,
  lobby: { serverId: string; hostId: string; memberIds: string[] },
  minBet: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  let [attackerId, opponentId] = lobby.memberIds;

  if (lobby.memberIds.length > 2) {
    const shuffled = [...lobby.memberIds].sort(() => Math.random() - 0.5);
    if (shuffled.length % 2 === 1) {
      const oddOne = shuffled.pop()!;
      const randomPartner = shuffled[crypto.randomInt(0, shuffled.length)];
      const pair = [oddOne, randomPartner];
      const rest = shuffled.filter((id) => id !== randomPartner);
      attackerId = pair[0];
      opponentId = pair[1];
      await saveDuelQueue(serverId, thread.id, rest);
    } else {
      attackerId = shuffled[0];
      opponentId = shuffled[1];
      const rest = shuffled.slice(2);
      if (rest.length > 0) await saveDuelQueue(serverId, thread.id, rest);
    }
  }

  const ap = await getOrCreateProfile(serverId, attackerId);
  const op = await getOrCreateProfile(serverId, opponentId);
  if (ap.balance < BigInt(minBet) || op.balance < BigInt(minBet)) {
    return { ok: false, error: `Недостаточно средств. Нужно ${minBet} септимов с каждого.` };
  }

  await adjustBalance({ serverId, userId: attackerId, delta: -minBet, reason: 'duel_bet' });
  await adjustBalance({ serverId, userId: opponentId, delta: -minBet, reason: 'duel_bet' });

  const attackerMember = await thread.guild?.members.fetch(attackerId).catch(() => null);
  const opponentMember = await thread.guild?.members.fetch(opponentId).catch(() => null);
  const key = duelKey(serverId, attackerId, opponentId);
  const session: DuelSession = {
    attackerId,
    opponentId,
    betAmount: minBet,
    seed: crypto.randomUUID(),
    attackerDeck: freshDeck(),
    opponentDeck: freshDeck(),
    attackerScore: 0,
    opponentScore: 0,
    round: 1,
    maxRounds: 3,
    phase: 'playing',
    attackerRoleIds: attackerMember?.roles.cache.map((r) => r.id) ?? [],
    opponentRoleIds: opponentMember?.roles.cache.map((r) => r.id) ?? [],
  };
  await setSession(key, session);

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.DUEL} Дуэль — Раунд 1/3`)
    .setDescription(
      `Ставка: **${minBet}** септимов с каждого (банк: **${minBet * 2}**)\n` +
        `<@${attackerId}> 🆚 <@${opponentId}>\n\n` +
        `Счёт: **0** : **0**\n\n` +
        '**Тянуть карту** — тянем и сравниваем.',
    )
    .setColor(UI_CONFIG.COLORS.DUEL);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`duel:draw:${attackerId}:${opponentId}`)
      .setLabel('Тянуть карту')
      .setStyle(ButtonStyle.Primary),
  );

  await thread.send({ embeds: [embed], components: [row] });
  return { ok: true };
}

function duelQueueKey(serverId: string, threadId: string) {
  return `duelQueue:${serverId}:${threadId}`;
}
async function saveDuelQueue(serverId: string, threadId: string, memberIds: string[]) {
  await redis.set(duelQueueKey(serverId, threadId), JSON.stringify(memberIds), 'EX', 3600);
}
