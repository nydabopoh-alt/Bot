/**
 * Локализация сообщений бота (русский).
 * Ключи: domain.key или domain.subkey
 */
export const ru = {
  common: {
    error: 'Ошибка',
    success: 'Успешно',
    warning: 'Внимание',
    info: 'Информация',
  },

  profile: {
    title: 'Карточка посетителя Норы',
    intro: 'В Норе не спрашивают имён — тут помнят за поступки. И за то, сколько септимов ты оставил на столах.',
    wallet: 'Кошелёк',
    inPocket: 'В кармане',
    lost: 'проиграно',
    won: 'выиграно',
    games: 'Игры',
    gamesPlayed: 'Игр сыграно',
    winsLosses: 'Побед / поражений',
    winrate: 'Винрейт',
    noGamesYet: 'Пока не сыграно ни одной игры',
    fights: 'Бои',
    defeatedOpponents: 'Побеждённых оппонентов',
    arenaWins: 'Побед в битвах арены',
    footer: 'Крысиная Нора · Фляга',
    fortune: 'Фартуна любит смелых',
    whoIs: 'Кто перед Фигляром',
  },

  settings: {
    adminOnly: 'Доступ к `/settings` есть только у админов и владельца сервера.',
    guildOnly: 'Настройки доступны только на сервере.',
    channels: 'Каналы',
    roles: 'Роли',
    economy: 'Экономика',
    games: 'Игры',
    save: 'Сохранить',
    access: 'Доступ',
    saved: 'Настройки сохранены.',
    accessUpdated: 'Доступ к игровым командам обновлён',
    modeNone: 'только канал игр',
    modeWhitelist: 'whitelist',
    modeBlacklist: 'blacklist',
  },

  games: {
    channelsOnly: 'Игровые команды доступны только в разрешённых каналах (см. /settings → Доступ).',
    channelsThreadsOnly: (id: string) => `Игровые команды доступны только в ветках канала <#${id}>.`,
    playerRoleRequired: (id: string) => `Для игры требуется роль <@&${id}>.`,
    gameDisabled: 'Эта игра сейчас отключена в настройках.',
    buttonsChannelsOnly: 'Игровые кнопки доступны только в разрешённых каналах (см. /settings → Доступ).',
    buttonsThreadsOnly: (id: string) => `Игровые кнопки работают только в ветках канала <#${id}>.`,
    createTableChannelsOnly: 'Создать стол можно только в разрешённых каналах (см. /settings → Доступ).',
    createTableThreadsOnly: (id: string) => `Создать стол можно только в канале игр <#${id}> или его ветках.`,
    tableChannelsOnly: 'Команды столов доступны только в разрешённых каналах (см. /settings → Доступ).',
    tableThreadsOnly: (id: string) => `Команды столов доступны только в канале игр <#${id}> или его ветках.`,
  },

  septims: 'септимов',
} as const;

export type Locale = typeof ru;
