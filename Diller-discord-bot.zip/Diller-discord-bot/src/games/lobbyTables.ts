/**
 * Столы/лобби: создание ветки с выбором игры и мест (2–6),
 * список активных столов (обновляется раз в минуту), вход по выбору, старт хозяином, пустые удаляются.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  type ButtonInteraction,
  type GuildMember,
  type TextChannel,
  type ThreadChannel,
} from 'discord.js';
import { redis } from '../db/redis';
import { UI_CONFIG } from '../config/ui';
import { getServerConfig } from '../config/serverConfigService';

/** Создать сообщение «Активные столы» в канале игр и сохранить его id (если ещё не было). */
async function ensureActiveLobbiesMessage(
  client: import('discord.js').Client,
  serverId: string,
): Promise<{ channelId: string; messageId: string } | null> {
  let msgInfo = await getActiveLobbiesMessageId(serverId);
  if (msgInfo) return msgInfo;
  const config = await getServerConfig(serverId);
  const channelId = config?.gamesChannelId;
  if (!channelId) return null;
  const channel = await client.channels.fetch(channelId).catch(() => null) as TextChannel | null;
  if (!channel || !('send' in channel)) return null;
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TABLE} Активные столы`)
    .setDescription('*Нет активных столов. Создайте стол кнопкой выше.*')
    .setColor(UI_CONFIG.COLORS.PRIMARY);
  const msg = await channel.send({ embeds: [embed] }).catch(() => null);
  if (!msg) return null;
  await setActiveLobbiesMessageId(serverId, channel.id, msg.id);
  return { channelId: channel.id, messageId: msg.id };
}

/** Ветка архивируется, если нет сообщений N минут */
const LOBBY_INACTIVITY_ARCHIVE_MS = 3 * 60 * 1000;

const GAME_LABELS: Record<string, string> = {
  dice: 'Кости',
  dicepoker: 'Покер на кубиках',
  blind: 'Покер',
  duel: 'Дуэль',
  intervention: 'Интервенция 21.5',
};

/** По названию ветки определить игру, кол-во мест и банк (для подхвата существующих веток). */
function parseTableThreadName(name: string): { gameType: LobbyTable['gameType']; seats: number; stake?: number } {
  const gameType: LobbyTable['gameType'] = 'dice';
  let seats = 6;
  let stake: number | undefined;
  // Парсим банк: «Покер — 2000 — 1/6» или «Покер на кубиках — 2000 — 1/6»
  const stakeMatch = name.match(/—\s*(\d+)\s*—\s*\d+\/\d+/);
  if (stakeMatch) stake = parseInt(stakeMatch[1], 10);
  if (/Покер на кубиках|dicepoker/i.test(name)) return { gameType: 'dicepoker', seats, stake };
  if (/Покер|Слепая|blind/i.test(name)) return { gameType: 'blind', seats, stake };
  if (/Кости|dice/i.test(name)) return { gameType: 'dice', seats, stake };
  if (/Дуэль|duel/i.test(name)) return { gameType: 'duel', seats, stake };
  if (/Интервенция|intervention/i.test(name)) return { gameType: 'intervention', seats, stake };
  const frac = name.match(/(\d+)\/(\d+)/);
  if (frac) seats = Math.min(6, Math.max(2, parseInt(frac[2], 10) || 6));
  return { gameType, seats, stake };
}

/** Подтянуть ветки канала игр в Redis: если ветка похожа на стол (🪑 или «Стол»), но нет в лобби — добавляем. */
async function syncChannelThreadsToLobbies(
  channel: TextChannel,
  serverId: string,
): Promise<void> {
  const processThread = async (thread: ThreadChannel): Promise<void> => {
    const name = thread.name ?? '';
    const isTableThread = name.startsWith('🪑') || /Стол|стол/i.test(name) || /\d+\/\d+/.test(name);
    if (!isTableThread) return;
    const existing = await getLobby(serverId, thread.id);
    if (existing) return;
    const members = await thread.members.fetch().catch(() => null);
    const memberIds = members
      ? Array.from(members.keys()).filter((id) => !members.get(id)?.user?.bot)
      : [];
    const { gameType, seats, stake } = parseTableThreadName(name);
    const hostId = memberIds[0] ?? thread.ownerId ?? '';
    const lobby: LobbyTable = {
      serverId,
      threadId: thread.id,
      channelId: channel.id,
      hostId,
      gameType,
      seats: Math.max(2, Math.min(6, seats)),
      memberIds,
      phase: 'waiting',
      createdAt: thread.createdTimestamp ?? Date.now(),
      stake: (gameType === 'blind' || gameType === 'dicepoker') && stake != null ? stake : undefined,
    };
    await saveLobby(lobby);
  };

  try {
    const active = await channel.threads.fetchActive().catch(() => null);
    if (active?.threads) {
      for (const [, thread] of active.threads) {
        await processThread(thread);
      }
    }
    const archived = await channel.threads.fetchArchived({ limit: 25 }).catch(() => null);
    if (archived?.threads) {
      for (const [, thread] of archived.threads) {
        await processThread(thread);
      }
    }
  } catch (err) {
    console.error('[lobbyTables] syncChannelThreadsToLobbies failed', { serverId, err });
  }
}

export interface LobbyTable {
  serverId: string;
  threadId: string;
  channelId: string;
  hostId: string;
  gameType: 'dice' | 'dicepoker' | 'blind' | 'duel' | 'intervention';
  seats: number;
  memberIds: string[];
  phase: 'waiting' | 'playing';
  createdAt: number;
  lobbyEmbedMessageId?: string;
  /** Для слепой ставки: банк стола (задаётся при создании) */
  stake?: number;
}

function lobbyKey(serverId: string, threadId: string) {
  return `lobby:${serverId}:${threadId}`;
}

function lobbiesSetKey(serverId: string) {
  return `lobbies:${serverId}`;
}

const LOBBY_LAST_MESSAGE_TTL = 86400; // 1 day, same as lobby

function lobbyLastMessageKey(serverId: string, threadId: string) {
  return `lobby:lastMessage:${serverId}:${threadId}`;
}

export async function setLobbyLastMessage(serverId: string, threadId: string): Promise<void> {
  await redis.set(lobbyLastMessageKey(serverId, threadId), String(Date.now()), 'EX', LOBBY_LAST_MESSAGE_TTL);
}

export async function getLobbyLastMessage(serverId: string, threadId: string): Promise<number | null> {
  const raw = await redis.get(lobbyLastMessageKey(serverId, threadId));
  if (!raw) return null;
  const ts = parseInt(raw, 10);
  return Number.isNaN(ts) ? null : ts;
}

export function activeLobbiesMessageKey(serverId: string) {
  return `gamesChannel:activeLobbiesMessage:${serverId}`;
}

export async function saveLobby(lobby: LobbyTable): Promise<void> {
  await redis.set(lobbyKey(lobby.serverId, lobby.threadId), JSON.stringify(lobby), 'EX', 86400);
  await redis.sadd(lobbiesSetKey(lobby.serverId), lobby.threadId);
}

export async function getLobby(serverId: string, threadId: string): Promise<LobbyTable | null> {
  const raw = await redis.get(lobbyKey(serverId, threadId));
  if (!raw) return null;
  return JSON.parse(raw) as LobbyTable;
}

export async function deleteLobby(serverId: string, threadId: string): Promise<void> {
  await redis.del(lobbyKey(serverId, threadId));
  await redis.srem(lobbiesSetKey(serverId), threadId);
}

export async function getLobbyThreadIds(serverId: string): Promise<string[]> {
  const list = await redis.smembers(lobbiesSetKey(serverId));
  return list;
}

export async function getLobbies(serverId: string): Promise<LobbyTable[]> {
  const threadIds = await getLobbyThreadIds(serverId);
  const lobbies: LobbyTable[] = [];
  for (const tid of threadIds) {
    const L = await getLobby(serverId, tid);
    if (L) lobbies.push(L);
  }
  return lobbies;
}

function threadName(lobby: LobbyTable, memberNames: string[]): string {
  const game = GAME_LABELS[lobby.gameType] ?? lobby.gameType;
  if (lobby.phase === 'playing') {
    return `🪑 Игра начата — ${game}`.slice(0, 100);
  }
  const n = lobby.memberIds.length;
  const s = lobby.seats;
  const stakePart = (lobby.gameType === 'blind' || lobby.gameType === 'dicepoker') && lobby.stake != null ? ` — ${lobby.stake}` : '';
  const who = memberNames.slice(0, 4).join(', ');
  const suffix = memberNames.length > 4 ? '…' : '';
  const part = who ? ` — ${who}${suffix}` : '';
  const name = `🪑 ${game}${stakePart} — ${n}/${s}${part}`;
  return name.slice(0, 100);
}

export async function setActiveLobbiesMessageId(serverId: string, channelId: string, messageId: string): Promise<void> {
  await redis.set(activeLobbiesMessageKey(serverId), JSON.stringify({ channelId, messageId }), 'EX', 86400 * 30);
}

export async function getActiveLobbiesMessageId(serverId: string): Promise<{ channelId: string; messageId: string } | null> {
  const raw = await redis.get(activeLobbiesMessageKey(serverId));
  if (!raw) return null;
  return JSON.parse(raw) as { channelId: string; messageId: string };
}

const RETRY_DELAY_MS = 5000;
const MAX_RETRIES = 2;

function isRetryableError(err: unknown): boolean {
  const code = (err as { code?: string })?.code;
  return code === 'UND_ERR_CONNECT_TIMEOUT' || code === 'ECONNRESET' || code === 'ETIMEDOUT';
}

/** Обновить эмбед «Активные столы» в канале игр (список + меню выбора). При таймауте — повтор до 2 раз. */
export async function updateActiveLobbiesEmbed(client: import('discord.js').Client, serverId: string): Promise<void> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
    let msgInfo = await getActiveLobbiesMessageId(serverId);
    if (!msgInfo) {
      msgInfo = await ensureActiveLobbiesMessage(client, serverId);
      if (!msgInfo) return;
    }
    const channel = await client.channels.fetch(msgInfo.channelId).catch(() => null) as TextChannel | null;
    if (!channel || !('send' in channel)) return;

    // Сразу подтянуть ветки канала: если в канале есть ветки-столы (🪑 или «Стол»), добавить их в список
    await syncChannelThreadsToLobbies(channel, serverId);

    const lobbies = await getLobbies(serverId);
    const guild = channel.guild;

    const toRemove: { serverId: string; threadId: string }[] = [];
    for (const lobby of lobbies) {
      try {
        const thread = await guild.channels.fetch(lobby.threadId).catch(() => null) as ThreadChannel | null;
        if (!thread) {
          toRemove.push({ serverId: lobby.serverId, threadId: lobby.threadId });
          continue;
        }
        const members = await thread.members.fetch().catch(() => null);
        const count = members?.filter((m) => !m.user?.bot).size ?? 0;
        const hasMembersInApi = count > 0;
        const hasMembersInLobby = lobby.memberIds.length > 0;
        const lastMsgAt = (await getLobbyLastMessage(lobby.serverId, lobby.threadId)) ?? lobby.createdAt;
        const inactiveMs = Date.now() - lastMsgAt;
        const isInactive = inactiveMs >= LOBBY_INACTIVITY_ARCHIVE_MS;
        // Удаляем: пустые (нет участников) ИЛИ 3+ минуты без сообщений
        if (isInactive || (!hasMembersInApi && !hasMembersInLobby)) {
          toRemove.push({ serverId: lobby.serverId, threadId: lobby.threadId });
          await thread.setArchived(true).catch(() => {});
        } else {
          if (hasMembersInApi && members) {
            const ids = Array.from(members.keys()).filter((id) => !members.get(id)?.user?.bot);
            if (ids.length !== lobby.memberIds.length || ids.some((id) => !lobby.memberIds.includes(id))) {
              lobby.memberIds = ids;
              await saveLobby(lobby);
            }
          }
          // Если API вернул 0, но в лобби есть участники — не трогаем (не удаляем)
        }
      } catch {
        toRemove.push({ serverId: lobby.serverId, threadId: lobby.threadId });
      }
    }
    for (const { serverId: s, threadId: t } of toRemove) {
      await deleteLobby(s, t);
    }
    const afterCleanup = await getLobbies(serverId);

    const lines: string[] = afterCleanup.length === 0
      ? ['*Нет активных столов. Создайте стол кнопкой выше.*']
      : afterCleanup.map((L) => {
          const game = GAME_LABELS[L.gameType] ?? L.gameType;
          const stakePart = (L.gameType === 'blind' || L.gameType === 'dicepoker') && L.stake != null ? ` — банк ${L.stake}` : '';
          const who = L.memberIds.map((id) => `<@${id}>`).join(', ');
          const status = L.phase === 'playing' ? ' (игра идёт)' : '';
          return `• <#${L.threadId}> — **${game}**${stakePart} ${L.memberIds.length}/${L.seats} — ${who}${status}`;
        });

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.TABLE} Активные столы`)
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.PRIMARY);

    const options = afterCleanup.slice(0, 25).map((L) => {
      const base = `${GAME_LABELS[L.gameType]} (${L.memberIds.length}/${L.seats})`;
      const label = (L.gameType === 'blind' || L.gameType === 'dicepoker') && L.stake != null ? `${base} — банк ${L.stake}` : base;
      return {
        label: label.slice(0, 100),
        value: L.threadId,
        description: L.memberIds.map((id) => guild.members.cache.get(id)?.user?.username ?? id).join(', ').slice(0, 100),
      };
    });

    const components: ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] = [];
    if (options.length > 0) {
      components.push(
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('gamesChannel:joinTable')
            .setPlaceholder('Выберите стол, чтобы войти')
            .addOptions(options),
        ),
      );
    }

    const msg = await channel.messages.fetch(msgInfo.messageId);
    await msg.edit({ embeds: [embed], components });
    return;
    } catch (err) {
      lastErr = err;
      if (attempt < MAX_RETRIES && isRetryableError(err)) {
        await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
        continue;
      }
      break;
    }
  }
  console.error('[lobbyTables] updateActiveLobbiesEmbed failed', { serverId, err: lastErr });
}

/** Раз в минуту обновить списки активных столов для всех серверов, где есть сохранённое сообщение. */
export async function refreshAllActiveLobbies(client: import('discord.js').Client): Promise<void> {
  let keys: string[];
  try {
    keys = await redis.keys('gamesChannel:activeLobbiesMessage:*');
  } catch (err) {
    console.error('[lobbyTables] refreshAllActiveLobbies: redis.keys failed', err);
    return;
  }
  const serverIds = [...new Set(keys.map((k) => k.replace('gamesChannel:activeLobbiesMessage:', '')))];
  for (const serverId of serverIds) {
    try {
      await updateActiveLobbiesEmbed(client, serverId);
    } catch (err) {
      console.error('[lobbyTables] refreshAllActiveLobbies: update failed for server', serverId, err);
    }
  }
}

export async function updateThreadName(thread: ThreadChannel, lobby: LobbyTable): Promise<void> {
  const names: string[] = [];
  const members = await thread.members.fetch().catch(() => null);
  if (members) {
    for (const [id] of members) {
      if (lobby.memberIds.includes(id)) {
        const m = members.get(id);
        names.push(m?.user?.username ?? id);
      }
    }
  }
  const name = threadName(lobby, names);
  await thread.setName(name).catch(() => {});
}

async function addAdminsToThread(guild: import('discord.js').Guild, thread: ThreadChannel): Promise<void> {
  try {
    const members = await guild.members.fetch();
    for (const [, m] of members) {
      if (m.user.bot) continue;
      if (guild.ownerId === m.id || m.permissions.has(PermissionFlagsBits.Administrator)) {
        await thread.members.add(m.id).catch(() => {});
      }
    }
  } catch (_) {}
}

/** Создать стол: ветка + запись лобби. Вызывается после выбора игры и мест (2–6). Для blind — stake задаётся при создании. */
export async function createTable(
  channel: TextChannel,
  hostId: string,
  hostUsername: string,
  gameType: LobbyTable['gameType'],
  seats: number,
  stake?: number,
): Promise<{ lobby: LobbyTable; thread: ThreadChannel } | null> {
  const serverId = channel.guild.id;
  const namePart = (gameType === 'blind' || gameType === 'dicepoker') && stake != null
    ? `🪑 ${GAME_LABELS[gameType]} — ${stake} — 1/${seats} — ${hostUsername}`
    : `🪑 ${GAME_LABELS[gameType]} — 1/${seats} — ${hostUsername}`;
  const thread = await channel.threads.create({
    name: namePart.slice(0, 100),
    type: ChannelType.PrivateThread,
    reason: 'Игровой стол',
  }).catch(() => null);
  if (!thread) return null;

  await thread.members.add(hostId).catch(() => {});
  // Не ждём: добавление админов в ветку может быть долгим на больших серверах
  addAdminsToThread(channel.guild, thread).catch(() => {});

  const lobby: LobbyTable = {
    serverId,
    threadId: thread.id,
    channelId: channel.id,
    hostId,
    gameType,
    seats,
    memberIds: [hostId],
    phase: 'waiting',
    createdAt: Date.now(),
    stake: (gameType === 'blind' || gameType === 'dicepoker') && stake != null ? stake : undefined,
  };
  await saveLobby(lobby);
  await setLobbyLastMessage(serverId, thread.id);

  const gameLabel = GAME_LABELS[gameType];
  const stakeLine = (gameType === 'blind' || gameType === 'dicepoker') && lobby.stake != null
    ? gameType === 'dicepoker'
      ? `**Банк стола:** ${lobby.stake} септимов (макс. ставка = банк стола). Создатель жмёт **Играть** — игра начинается.\n`
      : `**Банк стола:** ${lobby.stake} септимов (лимит ставки ×2 = ${lobby.stake * 2}). Создатель жмёт **Играть** — игра начинается.\n`
    : `**Банк стола** — создатель жмёт **Играть**, вводит взнос. Игроки вносят в стол — ставки идут из фишек.\n`;
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.TABLE} Стол: ${gameLabel}`)
    .setDescription(
      `**Игра:** ${gameLabel}\n**Мест:** ${lobby.memberIds.length}/${seats}\n**Игроки:** <@${hostId}>\n\n` +
        stakeLine +
        `Минимум 2 игрока. Пустые столы удаляются.`,
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`gamesChannel:startTable:${thread.id}`).setLabel('Играть').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`gamesChannel:leaveTable:${thread.id}`).setLabel('Покинуть стол').setStyle(ButtonStyle.Danger),
  );
  const msg = await thread.send({ embeds: [embed], components: [row] }).catch(() => null);
  if (msg) {
    lobby.lobbyEmbedMessageId = msg.id;
    await saveLobby(lobby);
  }

  return { lobby, thread };
}

/** Обновить эмбед стола при старте игры: «Игра начата» — всё в ветке, команды не нужны. */
export async function updateLobbyEmbedWhenStarted(
  thread: ThreadChannel,
  lobby: LobbyTable,
): Promise<void> {
  const msgId = lobby.lobbyEmbedMessageId;
  if (!msgId) return;
  const msg = await thread.messages.fetch(msgId).catch(() => null);
  if (!msg) return;
  const gameLabel = GAME_LABELS[lobby.gameType] ?? lobby.gameType;
  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.SUCCESS} Игра начата — ${gameLabel}`)
    .setDescription('Всё в этой ветке. Нажимайте кнопки в сообщениях выше.')
    .setColor(UI_CONFIG.COLORS.SUCCESS);
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`gamesChannel:leaveTable:${thread.id}`).setLabel('Покинуть стол').setStyle(ButtonStyle.Danger),
  );
  await msg.edit({ embeds: [embed], components: [row] }).catch(() => {});
}
