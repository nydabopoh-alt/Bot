/**
 * Правила костей по таблице: 5 костей, 12 категорий.
 * Единицы–Шестерки: сумма (кол-во × достоинство).
 * Каре, Фулхаус: сумма всех костей.
 * Короткий стрит: 25. Длинный стрит: 30. Покер: 50. Любая: сумма.
 */

export const DICE_CATEGORIES = [
  { id: '1', name: 'Единицы', short: '1' },
  { id: '2', name: 'Двойки', short: '2' },
  { id: '3', name: 'Тройки', short: '3' },
  { id: '4', name: 'Четверки', short: '4' },
  { id: '5', name: 'Пятерки', short: '5' },
  { id: '6', name: 'Шестерки', short: '6' },
  { id: 'kare', name: 'Каре', short: 'Каре' },
  { id: 'full', name: 'Фулхаус', short: 'Фул' },
  { id: 'short', name: 'Короткий стрит', short: 'К.стрит' },
  { id: 'long', name: 'Длинный стрит', short: 'Д.стрит' },
  { id: 'poker', name: 'Покер', short: 'Покер' },
  { id: 'any', name: 'Любая', short: 'Любая' },
] as const;

export type CategoryId = (typeof DICE_CATEGORIES)[number]['id'];

function countFaces(dice: number[]): Record<number, number> {
  const c: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
  for (const d of dice) {
    if (d >= 1 && d <= 6) c[d]++;
  }
  return c;
}

/** Единицы–Шестерки: кол-во × достоинство */
function scoreNumber(dice: number[], face: number): number {
  const c = countFaces(dice);
  return (c[face] ?? 0) * face;
}

/** Каре: четыре одинаковых — сумма всех костей */
function scoreKare(dice: number[]): number {
  const c = countFaces(dice);
  const hasFour = Object.values(c).some((n) => n >= 4);
  return hasFour ? dice.reduce((a, b) => a + b, 0) : 0;
}

/** Фулхаус: 2 одинаковых + 3 одинаковых — сумма всех */
function scoreFull(dice: number[]): number {
  const c = countFaces(dice);
  const counts = Object.values(c).sort((a, b) => b - a);
  const hasFull = counts[0] >= 3 && counts[1] >= 2;
  return hasFull ? dice.reduce((a, b) => a + b, 0) : 0;
}

/** Короткий стрит: четыре по возрастанию подряд — 25 */
function scoreShortStraight(dice: number[]): number {
  const s = [...new Set(dice)].sort((a, b) => a - b);
  for (let i = 0; i <= s.length - 4; i++) {
    if (s[i + 1] === s[i] + 1 && s[i + 2] === s[i] + 2 && s[i + 3] === s[i] + 3) return 25;
  }
  return 0;
}

/** Длинный стрит: пять подряд — 30 */
function scoreLongStraight(dice: number[]): number {
  const s = [...dice].sort((a, b) => a - b);
  if (
    s[0] + 1 === s[1] && s[1] + 1 === s[2] && s[2] + 1 === s[3] && s[3] + 1 === s[4]
  ) return 30;
  return 0;
}

/** Покер: пять одинаковых — 50 */
function scorePoker(dice: number[]): number {
  const c = countFaces(dice);
  return Object.values(c).some((n) => n >= 5) ? 50 : 0;
}

/** Любая: сумма всех костей */
function scoreAny(dice: number[]): number {
  return dice.reduce((a, b) => a + b, 0);
}

export function scoreCategory(dice: number[], categoryId: CategoryId): number {
  switch (categoryId) {
    case '1': return scoreNumber(dice, 1);
    case '2': return scoreNumber(dice, 2);
    case '3': return scoreNumber(dice, 3);
    case '4': return scoreNumber(dice, 4);
    case '5': return scoreNumber(dice, 5);
    case '6': return scoreNumber(dice, 6);
    case 'kare': return scoreKare(dice);
    case 'full': return scoreFull(dice);
    case 'short': return scoreShortStraight(dice);
    case 'long': return scoreLongStraight(dice);
    case 'poker': return scorePoker(dice);
    case 'any': return scoreAny(dice);
    default: return 0;
  }
}

/** Все возможные очки по категориям для данного броска */
export function getAllScores(dice: number[]): { categoryId: CategoryId; score: number; name: string }[] {
  return DICE_CATEGORIES.map((cat) => ({
    categoryId: cat.id,
    score: scoreCategory(dice, cat.id),
    name: cat.name,
  }));
}

export function diceToStr(dice: number[]): string {
  const sym = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
  return dice.map((d) => (d >= 1 && d <= 6 ? sym[d] : String(d))).join(' ');
}
