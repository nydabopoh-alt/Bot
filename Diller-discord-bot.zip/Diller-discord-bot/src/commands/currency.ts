import {
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
} from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { getOrCreateProfile, adjustBalance } from '../services/economy';

export async function handleCurrencyRoot(interaction: ChatInputCommandInteraction) {
  const guild = interaction.guild;
  if (!guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Команда только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const member = await guild.members.fetch(interaction.user.id).catch(() => null);
  const isAdmin =
    (member?.permissions.has(PermissionFlagsBits.Administrator) ?? false) ||
    guild.ownerId === interaction.user.id;

  if (!isAdmin) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Управление валютой доступно только админам и владельцу сервера.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const sub = interaction.options.getSubcommand(true);
  const targetUser = interaction.options.getUser('user', true);
  const amount = interaction.options.getInteger('amount', true);
  const serverId = guild.id;
  const userId = targetUser.id;

  if (targetUser.bot) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Нельзя изменить баланс бота.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (sub === 'add') {
    await adjustBalance({
      serverId,
      userId,
      delta: amount,
      reason: 'admin_add',
    });
    const profile = await getOrCreateProfile(serverId, userId);
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.COIN} Валюта добавлена`)
      .setDescription(
        `Пользователю **${targetUser.tag}** добавлено **${amount}** септимов.\nНовый баланс: **${profile.balance}**`,
      )
      .setColor(UI_CONFIG.COLORS.WIN);
    return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  }

  if (sub === 'remove') {
    const profile = await getOrCreateProfile(serverId, userId);
    const toRemove = Math.min(Number(profile.balance), amount);
    if (toRemove <= 0) {
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.ERROR} У пользователя **${targetUser.tag}** баланс **${profile.balance}** — убирать нечего.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    await adjustBalance({
      serverId,
      userId,
      delta: -toRemove,
      reason: 'admin_remove',
    });
    const updated = await getOrCreateProfile(serverId, userId);
    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.COIN} Валюта снята`)
      .setDescription(
        `У пользователя **${targetUser.tag}** снято **${toRemove}** септимов.\nНовый баланс: **${updated.balance}**`,
      )
      .setColor(UI_CONFIG.COLORS.LOSS);
    return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.ERROR} Неизвестная подкоманда.`,
    flags: MessageFlags.Ephemeral,
  });
}
