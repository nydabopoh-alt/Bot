import { prisma } from '../db/client';
import { getServerConfig } from '../config/serverConfigService';
import { EmbedBuilder, type Client, type TextChannel } from 'discord.js';
import { UI_CONFIG } from '../config/ui';

/**
 * Логирует подозрительную активность в БД и в лог-канал сервера.
 */
export async function logSuspicious(options: {
  client: Client;
  serverId: string;
  userId: string;
  reason: string;
  details?: string;
}) {
  const { client, serverId, userId, reason, details } = options;

  await prisma.suspiciousLog.create({
    data: { serverId, userId, reason, details },
  });

  const config = await getServerConfig(serverId);
  if (config?.logChannelId) {
    try {
      const channel = await client.channels.fetch(config.logChannelId) as TextChannel | null;
      if (channel?.isTextBased()) {
        const embed = new EmbedBuilder()
          .setTitle(`${UI_CONFIG.EMOJI.WARNING} Подозрительная активность`)
          .setDescription(
            `**Игрок:** <@${userId}>\n` +
            `**Причина:** ${reason}\n` +
            (details ? `**Детали:** ${details}` : ''),
          )
          .setColor(UI_CONFIG.COLORS.DANGER)
          .setTimestamp();

        await channel.send({ embeds: [embed] });
      }
    } catch (err) {
      console.error('[Antifraud] Failed to send log to channel:', err);
    }
  }
}

/**
 * Проверяет подозрительную частоту создания профилей.
 * Если за последний час с одного userId создано > 3 профилей
 * на разных серверах - логируем.
 */
export async function checkMultiAccountActivity(client: Client, serverId: string, userId: string) {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);

  const recentProfiles = await prisma.userProfile.count({
    where: {
      userId,
      createdAt: { gte: oneHourAgo },
    },
  });

  if (recentProfiles > 3) {
    await logSuspicious({
      client,
      serverId,
      userId,
      reason: 'Множественные профили за короткий период',
      details: `Создано ${recentProfiles} профилей за последний час на разных серверах`,
    });
  }
}

/**
 * Проверяет подозрительную активность по частоте ставок.
 * Если > 50 ставок за последние 5 минут - логируем.
 */
export async function checkRapidBetting(client: Client, serverId: string, userId: string) {
  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000);

  const recentBets = await prisma.betLog.count({
    where: {
      serverId,
      userId,
      createdAt: { gte: fiveMinAgo },
    },
  });

  if (recentBets > 50) {
    await logSuspicious({
      client,
      serverId,
      userId,
      reason: 'Подозрительно высокая частота ставок',
      details: `${recentBets} ставок за последние 5 минут`,
    });
  }
}

/**
 * Проверяет аномальный winrate (>80% побед при >20 играх за день).
 */
export async function checkAbnormalWinrate(client: Client, serverId: string, userId: string) {
  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const totalGames = await prisma.betLog.count({
    where: { serverId, userId, createdAt: { gte: dayAgo } },
  });

  if (totalGames < 20) return;

  const wins = await prisma.betLog.count({
    where: { serverId, userId, outcome: 'win', createdAt: { gte: dayAgo } },
  });

  const winrate = wins / totalGames;
  if (winrate > 0.8) {
    await logSuspicious({
      client,
      serverId,
      userId,
      reason: 'Аномально высокий винрейт',
      details: `${wins}/${totalGames} побед (${(winrate * 100).toFixed(1)}%) за последние 24ч`,
    });
  }
}
