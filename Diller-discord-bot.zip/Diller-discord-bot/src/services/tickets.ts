import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type Client,
  type GuildMember,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type TextChannel,
  MessageFlags,
} from 'discord.js';
import { getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance } from './economy';
import { UI_CONFIG } from '../config/ui';

const gamesPanelImage =
  'https://cdn.discordapp.com/attachments/1471462038998880430/1477400919304962261/image.png?ex=69a54913&is=69a3f793&hm=6df4d3effd10c58c201a6dd84ee677dc19eba28f29d83b50e8ef5be730106819&';
  const STAKES_PANEL_IMAGE = 'https://cdn.discordapp.com/attachments/1471462038998880430/1471484722386305176/6ad73f0fc91fc2f2.png?ex=69a2e0f0&is=69a18f70&hm=8692da3b302e9543f4c4bc5bc85abd90d6e0c186bfe91f19468e36c5f8af7dda';
function isModeratorOrAdmin(interaction: ButtonInteraction): boolean {
  const member = interaction.member as GuildMember | null;
  if (!member) return false;
  return member.permissions.has('Administrator') || member.permissions.has('ManageGuild');
}

/** Отправить в канал панель: меню (баланс / переводы / ставки на бои) + кнопки Вывести и Пополнить */
export async function sendStakesPanelToChannel(
  client: Client,
  serverId: string,
  channelId: string,
): Promise<void> {
  const channel = await client.channels.fetch(channelId).catch(() => null) as TextChannel | null;
  if (!channel?.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle('🎟️ Ставки — баланс, переводы, тикеты')
    .setDescription(
      '**Меню:** выберите действие ниже.\n\n' +
        '• **Баланс** — показать ваш баланс септимов.\n' +
        '• **Переводы** — перевод средств между игроками (в канале игр).\n' +
        '• **Азартные игры** — кости, дуэль, Покер и т.д. (в канале игр).\n\n' +
        '**Тикеты:** кнопки **Вывести** и **Пополнить** создают тикет — с вами свяжутся.\n\n' +
        '_Ставки на бойцов появляются в арене при создании турнира._',
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY)
    .setImage(gamesPanelImage)
    .setTimestamp();

  const select = new StringSelectMenuBuilder()
    .setCustomId('tickets:stakesMenu')
    .setPlaceholder('Выберите действие...')
    .addOptions(
      { label: 'Показать баланс', value: 'balance', description: 'Ваш баланс септимов' },
      { label: 'Переводы', value: 'transfers', description: 'Переводы — в канале игр' },
      { label: 'Азартные игры', value: 'bets', description: 'Кости, дуэль, Покер — в канале игр' },
    );

  const rowSelect = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
  const rowButtons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('tickets:withdraw')
      .setLabel('Вывести')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tickets:deposit')
      .setLabel('Пополнить')
      .setStyle(ButtonStyle.Secondary),
  );

  await channel.send({
    embeds: [embed],
    components: [rowSelect, rowButtons],
  }).catch(() => {});
}

/** Кнопка «Вывести» — модалка с суммой, затем заявка в канал выдачи */
export async function handleTicketsWithdraw(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  if (profile.balance < 1n) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} На балансе нет средств для вывода.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const modal = new ModalBuilder()
    .setCustomId('tickets:withdrawModal')
    .setTitle('Заявка на вывод');

  const amountInput = new TextInputBuilder()
    .setCustomId('amount')
    .setLabel(`Сумма вывода (макс. ${profile.balance} септимов)`)
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('100')
    .setRequired(true);

  const commentInput = new TextInputBuilder()
    .setCustomId('comment')
    .setLabel('Комментарий (необязательно)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setPlaceholder('Реквизиты, примечание...');

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(amountInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(commentInput),
  );
  return interaction.showModal(modal);
}

/** Обработка модалки «Вывести» — отправка заявки в канал выдачи */
export async function handleTicketsWithdrawModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const amountRaw = interaction.fields.getTextInputValue('amount')?.trim() ?? '';
  const comment = interaction.fields.getTextInputValue('comment')?.trim() ?? '';
  const amount = parseInt(amountRaw, 10);

  if (Number.isNaN(amount) || amount < 1) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  if (profile.balance < BigInt(amount)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс: ${profile.balance} септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const config = await getServerConfig(interaction.guild.id);
  const accountingChannelId = (config as { accountingChannelId?: string | null })?.accountingChannelId ?? null;
  if (accountingChannelId) {
    const ch = await interaction.guild.channels.fetch(accountingChannelId).catch(() => null) as TextChannel | null;
    if (ch?.isTextBased()) {
      const nonce = Date.now().toString(36);
      const embed = new EmbedBuilder()
        .setTitle('Заявка на вывод')
        .setDescription(
          `Пользователь <@${interaction.user.id}> запросил вывод **${amount}** септимов.\n` +
            `Текущий баланс: **${profile.balance}** септимов.\n` +
            (comment ? `Комментарий: ${comment}` : ''),
        )
        .setColor(UI_CONFIG.COLORS.PRIMARY)
        .setTimestamp();
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`tickets:withdrawApprove:${interaction.user.id}:${amount}:${nonce}`)
          .setLabel('Принять')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`tickets:withdrawDecline:${interaction.user.id}:${amount}:${nonce}`)
          .setLabel('Отказать')
          .setStyle(ButtonStyle.Danger),
      );
      await ch.send({ embeds: [embed], components: [row] }).catch(() => {});
    }
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка на вывод **${amount}** септимов отправлена в канал выдачи. С вами свяжутся.`,
    flags: MessageFlags.Ephemeral,
  });
}

/** Кнопка «Пополнить» — открыть модалку для заявки на пополнение */
export async function handleTicketsDeposit(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  const modal = new ModalBuilder()
    .setCustomId('tickets:depositModal')
    .setTitle('Заявка на пополнение');

  const amountInput = new TextInputBuilder()
    .setCustomId('amount')
    .setLabel('Сумма пополнения (септимы)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Например, 100')
    .setRequired(true);

  const whenInput = new TextInputBuilder()
    .setCustomId('when')
    .setLabel('Когда удобно провести пополнение?')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Например, сегодня после 20:00')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(amountInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(whenInput),
  );

  await interaction.showModal(modal);
  return;
}

/** Обработка выбора в меню: баланс / переводы / ставки на бои */
export async function handleTicketsStakesSelect(interaction: StringSelectMenuInteraction) {
  if (!interaction.guild) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const value = interaction.values[0];
  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);

  if (value === 'balance') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} **Ваш баланс:** **${profile.balance}** септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (value === 'transfers') {
    const config = await getServerConfig(interaction.guild.id);
    const gamesChannelId = (config as { gamesChannelId?: string | null })?.gamesChannelId ?? null;
    const chMention = gamesChannelId ? `<#${gamesChannelId}>` : 'канал игр';
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} **Переводы** — перевод средств между игроками доступен в ${chMention}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  if (value === 'bets') {
    const config = await getServerConfig(interaction.guild.id);
    const gamesChannelId = (config as { gamesChannelId?: string | null })?.gamesChannelId ?? null;
    const chMention = gamesChannelId ? `<#${gamesChannelId}>` : 'канале игр';
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.INFO} **Азартные игры** — кости, дуэль, Покер, интервенция и др. доступны в ${chMention}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.WARNING} Неизвестное действие.`,
    flags: MessageFlags.Ephemeral,
  });
}

/** Кнопка «Принять» на заявке вывода — списать септимы и отметить заявку */
export async function handleTicketsWithdrawApprove(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const parts = interaction.customId.replace('tickets:withdrawApprove:', '').split(':');
  const [userId, amountStr] = parts;
  const amount = parseInt(amountStr ?? '0', 10);
  if (!userId || Number.isNaN(amount) || amount < 1) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  // Пользователь не может сам себя одобрить
  if (userId === interaction.user.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нельзя одобрить свою заявку.`, flags: MessageFlags.Ephemeral });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, userId);
  if (profile.balance < BigInt(amount)) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно средств. Баланс <@${userId}>: ${profile.balance} септимов.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  await adjustBalance({
    serverId: interaction.guild.id,
    userId,
    delta: -amount,
    reason: 'withdrawal_approved',
  });

  const orig = interaction.message.embeds[0];
  const embed = new EmbedBuilder()
    .setTitle('Заявка на вывод — Принято')
    .setDescription(
      (orig?.data?.description ?? orig?.description ?? '') +
        `\n\n✅ **Одобрено** <@${interaction.user.id}> — выдача ${amount} септимов.`,
    )
    .setColor(UI_CONFIG.COLORS.SUCCESS ?? 0x57f287)
    .setTimestamp();

  await interaction.update({
    embeds: [embed],
    components: [],
  }).catch(() => {});

  try {
    const userName = (await interaction.client.users.fetch(userId).catch(() => null))?.username ?? userId;
    const thread = await interaction.message.startThread({
      name: `Вывод ${amount} — ${userName}`.slice(0, 100),
      reason: 'Заявка на вывод одобрена',
    });
    await thread.send({
      content: `✅ Выдача **${amount}** септимов для <@${userId}> выполнена. Баланс списан.`,
    }).catch(() => {});
  } catch {
    // Ветки отключены — игнорируем
  }

  return interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Выдача **${amount}** септимов для <@${userId}> выполнена.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

/** Кнопка «Отказать» на заявке вывода — отметить заявку без списания */
export async function handleTicketsWithdrawDecline(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const parts = interaction.customId.replace('tickets:withdrawDecline:', '').split(':');
  const [userId] = parts;
  if (!userId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  const orig = interaction.message.embeds[0];
  const embed = new EmbedBuilder()
    .setTitle('Заявка на вывод — Отклонено')
    .setDescription(
      (orig?.data?.description ?? orig?.description ?? '') +
        `\n\n❌ **Отклонено** <@${interaction.user.id}>.`,
    )
    .setColor(UI_CONFIG.COLORS.ERROR ?? 0xed4245)
    .setTimestamp();

  await interaction.update({
    embeds: [embed],
    components: [],
  }).catch(() => {});

  return interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка отклонена.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

/** Обработка модалки «Пополнить» — отправка заявки в канал выдачи */
export async function handleTicketsDepositModal(interaction: ModalSubmitInteraction) {
  if (!interaction.guild) return;

  const amountRaw = interaction.fields.getTextInputValue('amount')?.trim() ?? '';
  const when = interaction.fields.getTextInputValue('when')?.trim() ?? '';
  const amount = Number.parseInt(amountRaw, 10);

  if (Number.isNaN(amount) || amount < 1) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Укажите корректную сумму пополнения.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const profile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  const config = await getServerConfig(interaction.guild.id);
  const accountingChannelId = (config as { accountingChannelId?: string | null })?.accountingChannelId ?? null;

  if (!accountingChannelId) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Канал выдачи не настроен. Обратитесь к администрации.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const ch = await interaction.guild.channels.fetch(accountingChannelId).catch(() => null) as TextChannel | null;
  if (ch?.isTextBased()) {
    const nonce = Date.now().toString(36);
    const lines: string[] = [];
    lines.push(`Пользователь <@${interaction.user.id}> запросил **пополнение** на **${amount}** септимов.`);
    lines.push(`Текущий баланс: **${profile.balance}** септимов.`);
    if (when) {
      lines.push(`Удобное время: ${when}`);
    }

    const embed = new EmbedBuilder()
      .setTitle('Заявка на пополнение')
      .setDescription(lines.join('\n'))
      .setColor(UI_CONFIG.COLORS.PRIMARY)
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`tickets:depositApprove:${interaction.user.id}:${amount}:${nonce}`)
        .setLabel('Принять')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`tickets:depositDecline:${interaction.user.id}:${amount}:${nonce}`)
        .setLabel('Отказать')
        .setStyle(ButtonStyle.Danger),
    );

    await ch.send({ embeds: [embed], components: [row] }).catch(() => {});
  }

  return interaction.reply({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка на пополнение **${amount}** септимов отправлена в канал выдачи. С вами свяжутся.`,
    flags: MessageFlags.Ephemeral,
  });
}

/** Кнопка «Принять» на заявке пополнения — начислить септимы и отметить заявку */
export async function handleTicketsDepositApprove(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const parts = interaction.customId.replace('tickets:depositApprove:', '').split(':');
  const [userId, amountStr] = parts;
  const amount = Number.parseInt(amountStr ?? '0', 10);
  if (!userId || Number.isNaN(amount) || amount < 1) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  if (userId === interaction.user.id) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Нельзя одобрить свою заявку.`, flags: MessageFlags.Ephemeral });
  }

  const updated = await adjustBalance({
    serverId: interaction.guild.id,
    userId,
    delta: amount,
    reason: 'deposit_approved',
  });

  try {
    const user = await interaction.client.users.fetch(userId);
    await user.send({
      content: `${UI_CONFIG.EMOJI.SUCCESS} Ваше пополнение на **${amount}** септимов одобрено. Баланс: **${updated.balance}** септимов.`,
    }).catch(() => {});
  } catch {
    // ЛС закрыты или пользователь не найден
  }

  const orig = interaction.message.embeds[0];
  const embed = new EmbedBuilder()
    .setTitle('Заявка на пополнение — Принято')
    .setDescription(
      (orig?.data?.description ?? orig?.description ?? '') +
        `\n\n✅ **Одобрено** <@${interaction.user.id}> — пополнение на ${amount} септимов.`,
    )
    .setColor(UI_CONFIG.COLORS.SUCCESS ?? 0x57f287)
    .setTimestamp();

  await interaction.update({
    embeds: [embed],
    components: [],
  }).catch(() => {});

  try {
    const thread = await interaction.message.startThread({
      name: `Пополнение ${amount} — ${(await interaction.client.users.fetch(userId).catch(() => null))?.username ?? userId}`.slice(0, 100),
      reason: 'Заявка на пополнение одобрена',
    });
    await thread.send({
      content: `✅ Пополнение **${amount}** септимов для <@${userId}> выполнено. Баланс: **${updated.balance}** септимов.`,
    }).catch(() => {});
  } catch {
    // Ветки отключены — игнорируем
  }

  return interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Пополнение **${amount}** септимов для <@${userId}> выполнено.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

/** Кнопка «Отказать» на заявке пополнения — отметить заявку без изменений баланса */
export async function handleTicketsDepositDecline(interaction: ButtonInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Доступно только на сервере.`, flags: MessageFlags.Ephemeral });
  }
  if (!isModeratorOrAdmin(interaction)) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Только модераторы/админы.`, flags: MessageFlags.Ephemeral });
  }

  const parts = interaction.customId.replace('tickets:depositDecline:', '').split(':');
  const [userId] = parts;
  if (!userId) {
    return interaction.reply({ content: `${UI_CONFIG.EMOJI.ERROR} Ошибка.`, flags: MessageFlags.Ephemeral });
  }

  const orig = interaction.message.embeds[0];
  const embed = new EmbedBuilder()
    .setTitle('Заявка на пополнение — Отклонено')
    .setDescription(
      (orig?.data?.description ?? orig?.description ?? '') +
        `\n\n❌ **Отклонено** <@${interaction.user.id}>.`,
    )
    .setColor(UI_CONFIG.COLORS.ERROR ?? 0xed4245)
    .setTimestamp();

  await interaction.update({
    embeds: [embed],
    components: [],
  }).catch(() => {});

  return interaction.followUp({
    content: `${UI_CONFIG.EMOJI.SUCCESS} Заявка отклонена.`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
}

