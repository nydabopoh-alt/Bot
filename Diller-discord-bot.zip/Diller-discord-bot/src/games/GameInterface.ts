import type { ChatInputCommandInteraction, ButtonInteraction, ModalSubmitInteraction } from 'discord.js';

export interface GameInterface {
  key: string;

  validateBet(amount: number, context: { minBet: number; maxBet: number; balance: number }): void;

  start(options: {
    interaction: ChatInputCommandInteraction;
    betAmount: number;
    seed: string;
  }): Promise<void>;

  resolve(options: {
    interaction: ButtonInteraction | ModalSubmitInteraction;
    seed: string;
  }): Promise<void>;

  payout(options: {
    userId: string;
    serverId: string;
    betAmount: number;
    winAmount: number;
  }): Promise<void>;

  renderUI(options: {
    state: unknown;
  }): {
    content?: string;
    embeds?: any[];
    components?: any[];
  };
}

