import { ChatInputCommandInteraction, EmbedBuilder, MessageFlags } from 'discord.js';
import { UI_CONFIG } from '../config/ui';
import { claimDaily } from '../services/economy';

export async function handleDaily(interaction: ChatInputCommandInteraction) {
  const serverId = interaction.guild!.id;
  const userId = interaction.user.id;

  const result = await claimDaily(serverId, userId);

  if (!result.ok) {
    const now = new Date();
    const diffMs = result.nextAt.getTime() - now.getTime();
    const diffHours = Math.max(0, Math.floor(diffMs / (60 * 60 * 1000)));
    const diffMinutes = Math.max(
      0,
      Math.floor((diffMs % (60 * 60 * 1000)) / (60 * 1000)),
    );

    const embed = new EmbedBuilder()
      .setTitle(`${UI_CONFIG.EMOJI.CLOCK} Ежедневный бонус уже получен`)
      .setDescription(
        `Следующий бонус будет доступен через **${diffHours}ч ${diffMinutes}м**.`,
      )
      .setColor(UI_CONFIG.COLORS.PRIMARY);

    return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  }

  const embed = new EmbedBuilder()
    .setTitle(`${UI_CONFIG.EMOJI.MONEY_BAG} Ежедневный бонус`)
    .setDescription(
      `Вы получили **${result.amount}**.\nТекущий баланс: **${result.profile.balance}**.`,
    )
    .setColor(UI_CONFIG.COLORS.PRIMARY);

  return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}
