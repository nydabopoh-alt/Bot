import { ChatInputCommandInteraction, PermissionFlagsBits, MessageFlags } from 'discord.js';
import { buildDiceStartEmbed, showDicePvPStakeModal } from '../games/diceEmbed';
import { buildBlindStartEmbed } from '../games/blind';
import { buildDuelChallengeEmbed } from '../games/duel';
import { buildTugStartEmbed, buildTugEventLobbyEmbed, getTugEvent, setTugEvent } from '../games/tug';
import { buildInterventionChallengeEmbed } from '../games/intervention';
import { handlePokerRoot } from '../games/poker';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { UI_CONFIG } from '../config/ui';
import { getOrCreateProfile } from '../services/economy';
import { startDicePvP } from '../games/dicePvP';
import { redis } from '../db/redis';

const DICE_CHALLENGE_TTL = 120;

export async function handleDiceRoot(interaction: ChatInputCommandInteraction) {
  const opponent = interaction.options.getUser('opponent', true);
  const stakeOpt = interaction.options.getInteger('ставка');

  if (!interaction.guild || !interaction.channel) {
    return interaction.reply({ content: 'Только на сервере.', flags: MessageFlags.Ephemeral });
  }

  if (opponent.id === interaction.user.id) {
    return interaction.reply({ content: 'Нельзя играть с самим собой.', flags: MessageFlags.Ephemeral });
  }
  if (opponent.bot) {
    return interaction.reply({ content: 'Оппонент должен быть человеком.', flags: MessageFlags.Ephemeral });
  }

  if (stakeOpt != null) {
    const config = await ensureServerConfig(interaction.guild.id);
    const myProfile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
    const stake = stakeOpt;
    if (stake < config.minBet || stake > config.maxBet) {
      return interaction.reply({
        content: `Ставка должна быть от ${config.minBet} до ${config.maxBet}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (myProfile.balance < BigInt(stake)) {
      return interaction.reply({
        content: `Недостаточно средств. Баланс: ${myProfile.balance}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    return startDicePvP(interaction, opponent.id, stake);
  }

  // Показ модалки сразу, без тяжёлых запросов — иначе Discord "Unknown interaction" (3 сек)
  await redis.set(
    `diceChallenge:${interaction.guild.id}:${interaction.user.id}`,
    JSON.stringify({ opponentId: opponent.id }),
    'EX',
    DICE_CHALLENGE_TTL,
  );
  return showDicePvPStakeModal(interaction);
}

export async function handleBlindRoot(interaction: ChatInputCommandInteraction) {
  const { embeds, components } = buildBlindStartEmbed();
  return interaction.reply({ embeds, components });
}

export async function handleDuelRoot(interaction: ChatInputCommandInteraction) {
  const opponent = interaction.options.getUser('opponent', true);
  const { embeds, components } = buildDuelChallengeEmbed(interaction.user.id, opponent.id);
  return interaction.reply({ embeds, components });
}

export async function handleTugRoot(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    return interaction.reply({ content: 'Только на сервере.', flags: MessageFlags.Ephemeral });
  }
  const member = interaction.member as { permissions?: { has: (p: bigint) => boolean }; user?: { id: string } };
  const isAdmin =
    (member?.permissions?.has?.(PermissionFlagsBits.Administrator) ?? false) ||
    interaction.guild.ownerId === interaction.user.id;

  if (!isAdmin) {
    const { embeds, components } = buildTugStartEmbed();
    return interaction.reply({ embeds, components, flags: MessageFlags.Ephemeral });
  }

  const serverId = interaction.guild.id;
  const config = await getServerConfig(serverId) as { eventsChannelId?: string | null } | null;
  const eventsChannelId = config?.eventsChannelId ?? null;

  let targetChannelId = interaction.channelId!;
  if (eventsChannelId) {
    const ch = await interaction.guild.channels.fetch(eventsChannelId).catch(() => null);
    if (ch?.isTextBased()) targetChannelId = eventsChannelId;
  }

  const existing = await getTugEvent(serverId, targetChannelId);
  if (existing && existing.phase === 'lobby') {
    return interaction.reply({
      content: `В этом канале уже идёт набор на перетягивание каната. Используйте сообщение с кнопкой «Войти» в <#${targetChannelId}>.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const stake = interaction.options.getInteger('ставка') ?? 100;
  const allowedStakes = [50, 100, 350, 500, 1000];
  const fixedStake = allowedStakes.includes(stake) ? stake : 100;
  const joinEndsAt = Date.now() + 5 * 60 * 1000;
  const ev = {
    serverId,
    channelId: targetChannelId,
    messageId: '',
    phase: 'lobby' as const,
    joinEndsAt,
    adminId: interaction.user.id,
    fixedStake,
    players: [],
    rolls: [],
  };
  const { embeds, components } = buildTugEventLobbyEmbed(ev, true);

  if (targetChannelId !== interaction.channelId) {
    const channel = await interaction.guild.channels.fetch(targetChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      const msg = await channel.send({ embeds, components });
      ev.messageId = msg.id;
      await setTugEvent(ev);
      return interaction.reply({
        content: `${UI_CONFIG.EMOJI.SUCCESS} Ивент «Перетягивание каната» создан в канале <#${targetChannelId}>.`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  const reply = await interaction.reply({ embeds, components, fetchReply: true });
  ev.messageId = (reply as { id: string }).id;
  await setTugEvent(ev);
}

export async function handleInterventionRoot(interaction: ChatInputCommandInteraction) {
  const opponent = interaction.options.getUser('opponent', true);
  const stakeOpt = interaction.options.getInteger('ставка');

  if (!interaction.guild || !interaction.channel) {
    return interaction.reply({ content: 'Только на сервере.', flags: MessageFlags.Ephemeral });
  }
  if (opponent.id === interaction.user.id) {
    return interaction.reply({ content: 'Нельзя играть с самим собой.', flags: MessageFlags.Ephemeral });
  }
  if (opponent.bot) {
    return interaction.reply({ content: 'Оппонент должен быть человеком.', flags: MessageFlags.Ephemeral });
  }

  const config = await ensureServerConfig(interaction.guild.id);
  const myProfile = await getOrCreateProfile(interaction.guild.id, interaction.user.id);
  const oppProfile = await getOrCreateProfile(interaction.guild.id, opponent.id);

  if (stakeOpt != null && stakeOpt > 0) {
    if (stakeOpt < config.minBet || stakeOpt > config.maxBet) {
      return interaction.reply({
        content: `Ставка от ${config.minBet} до ${config.maxBet}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (myProfile.balance < BigInt(stakeOpt)) {
      return interaction.reply({
        content: `Недостаточно средств. Баланс: ${myProfile.balance}.`,
        flags: MessageFlags.Ephemeral,
      });
    }
    if (oppProfile.balance < BigInt(stakeOpt)) {
      return interaction.reply({
        content: `У оппонента недостаточно средств.`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  const { embeds, components } = buildInterventionChallengeEmbed(interaction.user.id, opponent.id, stakeOpt ?? undefined);
  return interaction.reply({ embeds, components });
}

export { handlePokerRoot };
