export const UI_CONFIG = {

  // Цвета embed-ов

  COLORS: {
    PRIMARY: 0x4a00b0,       // основной фиолетовый
    WIN: 0x2ecc71,           // зелёный - выигрыш
    LOSS: 0xe74c3c,          // красный - проигрыш
    DRAW: 0x95a5a6,          // серый - ничья
    ERROR: 0xff0000,         // ярко-красный - ошибка
    SUCCESS: 0x00ff00,       // ярко-зелёный - успех
    WARNING: 0xffaa00,       // оранжевый - предупреждение
    CANCEL: 0x95a5a6,        // серый - отмена
    GOLD: 0xffd700,          // золотой - большой выигрыш / топ
    INFO: 0x3498db,          // синий - информация

    // Цвета игр
    DICE: 0xff6600,          // оранжевый
    BLIND: 0x9b59b6,         // фиолетовый
    DUEL: 0xe74c3c,          // красный
    TUG: 0x2ecc71,           // зелёный
    INTERVENTION: 0x3498db,  // синий
    POKER: 0x1a5276,         // тёмно-синий (покер 2 vs 3 кости)

    // Мероприятия
    EVENT_FIGHT: 0xe74c3c,
    EVENT_TOURNAMENT: 0xffd700,
    EVENT_SPECIAL: 0xf1c40f,
    EVENT_CUSTOM: 0x7289da,

    // Баланс
    BALANCE_UP: 0x00ff00,
    BALANCE_DOWN: 0xff0000,

    // Антифрод
    DANGER: 0xff0000,
  },

  // Обратная совместимость - PRIMARY как дефолтный цвет
  get EMBED_PRIMARY_COLOR() {
    return this.COLORS.PRIMARY;
  },

  // Эмодзи 

  EMOJI: {
    // Статусы
    ERROR: '❌',
    SUCCESS: '✅',
    INFO: 'ℹ️',
    WARNING: '⚠️',

    // Экономика
    WIN: '🏆',
    LOSS: '💸',
    COIN: '🪙',
    MONEY_BAG: '💰',
    SHOP: '🛒',

    // Игры
    DICE: '🎲',
    BLIND: '🃏',
    DUEL: '⚔️',
    TUG: '🪢',
    INTERVENTION: '🃏',
    POKER: '🎰',
    TABLE: '🪑',

    // Навигация
    PLUS: '➕',
    MINUS: '➖',
    NEXT: '➡️',
    PREV: '⬅️',
    REFRESH: '🔄',
    LOCK: '🔒',
    UNLOCK: '🔓',

    // Декор
    STAR: '⭐',
    FIRE: '🔥',
    CLOCK: '⏰',

    // Мероприятия / рассылки
    EVENT: '📅',
    MEGAPHONE: '📢',
    BELL: '🔔',
    TROPHY: '🏅',

    // Статистика / справка
    STATS: '📊',
    RULES: '📖',
    HELP: '❓',
    CHART: '📈',
    TARGET: '🎯',
  },

  /** Команды по типу игры — только для выбранной игры. */
  GAME_COMMANDS: {
    dice: '**Кости** (`/dice opponent:@игрок`)',
    duel: '**Дуэль** (`/duel opponent:@игрок`)',
    blind: '**Покер** (`/blind`)',
    dicepoker: '**Покер на кубиках** (кнопка «Создать стол» → выберите игру)',
    intervention: '**Интервенция 21.5** (`/intervention opponent:@игрок`)',
    tug: '**Перетягивание каната** (`/tug`)',
  } as const,
} as const;

export function getGameCommands(gameType: string): string {
  return UI_CONFIG.GAME_COMMANDS[gameType as keyof typeof UI_CONFIG.GAME_COMMANDS] ?? gameType;
}
