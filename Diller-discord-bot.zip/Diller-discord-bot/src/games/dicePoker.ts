/**
 * Покер на кубиках: 5 кубиков, 2 круга (бросок → ставка → переброс 1–5 → финал).
 * Комбинации как в покере: покер, каре, фулл-хаус, стрит, тройка, две пары, пара, старшая.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from 'discord.js';
import crypto from 'node:crypto';
import { UI_CONFIG } from '../config/ui';
import { ensureServerConfig, getServerConfig } from '../config/serverConfigService';
import { getOrCreateProfile, adjustBalance } from '../services/economy';
import { logBet } from '../services/logs';
import { setSession, getSession, deleteSession } from '../services/sessions';

const DICE_SYMBOLS = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'] as const;

function diceStr(n: number): string {
  return n >= 1 && n <= 6 ? DICE_SYMBOLS[n] : String(n);
}

function diceToDisplay(dice: number[]): string {
  const symbols = dice.map(diceStr).join(' ');
  const numbers = dice.join(' ');
  return symbols ? `${symbols} (${numbers})` : numbers;
}

/** Комбинации покера на кубиках (от старшей к младшей) */
const COMBO_RANK = {
  poker: 9,      // 5 одинаковых
  kare: 8,       // 4 одинаковых
  full: 7,       // 3 + 2
  straight: 6,  // 1-2-3-4-5 или 2-3-4-5-6
  three: 5,      // 3 одинаковых
  twoPairs: 4,   // 2 пары
  pair: 3,       // 1 пара
  high: 2,       // старшая
} as const;

type ComboType = keyof typeof COMBO_RANK;

interface DiceHand {
  combo: ComboType;
  rank: number;
  /** Тайбрек: массив значений для сравнения (напр. [6,5] для каре шестёрок) */
  tiebreak: number[];
}

function countFaces(dice: number[]): Record<number, number> {
  const c: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
  for (const d of dice) {
    if (d >= 1 && d <= 6) c[d]++;
  }
  return c;
}

function evaluateHand(dice: number[]): DiceHand {
  const sorted = [...dice].sort((a, b) => b - a); // по убыванию
  const c = countFaces(dice);
  const counts = Object.entries(c)
    .filter(([, n]) => n > 0)
    .map(([face, n]) => ({ face: Number(face), n }))
    .sort((a, b) => {
      if (b.n !== a.n) return b.n - a.n;
      return b.face - a.face;
    });

  const maxCount = counts[0]?.n ?? 0;
  const secondCount = counts[1]?.n ?? 0;

  // Покер (5 одинаковых)
  if (maxCount >= 5) {
    return { combo: 'poker', rank: COMBO_RANK.poker, tiebreak: [counts[0]!.face] };
  }
  // Каре
  if (maxCount >= 4) {
    const quad = counts[0]!.face;
    const kicker = counts.find((x) => x.face !== quad)?.face ?? 0;
    return { combo: 'kare', rank: COMBO_RANK.kare, tiebreak: [quad, kicker] };
  }
  // Фулл-хаус или тройка
  if (maxCount >= 3) {
    const trip = counts[0]!.face;
    if (secondCount >= 2) {
      const pairFace = counts[1]!.face;
      return { combo: 'full', rank: COMBO_RANK.full, tiebreak: [trip, pairFace] };
    }
    const kickers = sorted.filter((x) => x !== trip).slice(0, 2);
    return { combo: 'three', rank: COMBO_RANK.three, tiebreak: [trip, ...kickers] };
  }
  // Две пары
  if (maxCount >= 2 && secondCount >= 2) {
    const p1 = counts[0]!.face;
    const p2 = counts[1]!.face;
    const kicker = counts.find((x) => x.face !== p1 && x.face !== p2)?.face ?? 0;
    return {
      combo: 'twoPairs',
      rank: COMBO_RANK.twoPairs,
      tiebreak: [Math.max(p1, p2), Math.min(p1, p2), kicker],
    };
  }
  // Пара
  if (maxCount >= 2) {
    const pairFace = counts[0]!.face;
    const kickers = sorted.filter((x) => x !== pairFace).slice(0, 3);
    return { combo: 'pair', rank: COMBO_RANK.pair, tiebreak: [pairFace, ...kickers] };
  }

  // Стрит (1-2-3-4-5 или 2-3-4-5-6)
  const uniq = [...new Set(dice)].sort((a, b) => a - b);
  if (uniq.length === 5) {
    const low = uniq[0]!;
    const high = uniq[4]!;
    if (
      (low === 1 && high === 5) ||
      (low === 2 && high === 6) ||
      (uniq[1] === low + 1 && uniq[2] === low + 2 && uniq[3] === low + 3 && uniq[4] === low + 4)
    ) {
      return { combo: 'straight', rank: COMBO_RANK.straight, tiebreak: [high] };
    }
  }

  // Старшая
  return { combo: 'high', rank: COMBO_RANK.high, tiebreak: sorted.slice(0, 5) };
}

function compareHands(a: DiceHand, b: DiceHand): number {
  if (a.rank !== b.rank) return a.rank - b.rank;
  for (let i = 0; i < Math.max(a.tiebreak.length, b.tiebreak.length); i++) {
    const va = a.tiebreak[i] ?? 0;
    const vb = b.tiebreak[i] ?? 0;
    if (va !== vb) return va - vb;
  }
  return 0;
}

const COMBO_NAMES: Record<ComboType, string> = {
  poker: 'Покер (5 одинаковых)',
  kare: 'Каре',
  full: 'Фулл-хаус',
  straight: 'Стрит',
  three: 'Тройка',
  twoPairs: 'Две пары',
  pair: 'Пара',
  high: 'Старшая',
};

const DICE_POKER_RULES =
  '**Покер на кубиках:**\n' +
  '1. **Ставки** по очереди (до броска).\n' +
  '2. **Бросок** — каждый кидает 5 кубиков по очереди.\n' +
  '3. **Ставки** снова (по тому, что выпало).\n' +
  '4. **Переброс** — каждый по очереди перебрасывает 1–5 кубиков.\n' +
  '5. **Финал** — лучшая комбинация забирает банк.\n\n' +
  '**Банк стола** — запас фишек каждого (×2 от взноса). Максимум ставки = банк стола.';

const DICE_POKER_COMBOS =
  '**Комбинации** (от старшей): Покер → Каре → Фулл-хаус → Стрит → Тройка → Две пары → Пара → Старшая';

const DICE_POKER_IMAGE =
  'https://cdn.discordapp.com/attachments/1471462038998880430/1474298267025149952/iu_.png?ex=69a928c1&is=69a7d741&hm=a2e0722b880d79de7c8d5b9b5094edbc1d56a4d0fed86c09c815b17399725a0a&';

function rollDice(n: number): number[] {
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    out.push(crypto.randomInt(1, 7));
  }
  return out;
}

interface DicePokerPlayer {
  id: string;
  dice: number[];
  /** Индексы кубиков, выбранных для переброса */
  rerollIndices: number[];
  bet: number;
  folded: boolean;
  stack: number;
}

type DicePokerPhase = 'bet1' | 'roll1' | 'bet2' | 'reroll' | 'reveal';

interface DicePokerSession {
  serverId: string;
  hostId: string;
  players: DicePokerPlayer[];
  pot: number;
  stake: number;
  phase: DicePokerPhase;
  currentTurnIndex: number;
  currentBet: number;
  minBet: number;
  respondersNeeded: number;
  /** Лимит достигнут в bet1 — пропустить bet2, сразу переброс */
  bet1ReachedLimit?: boolean;
}

function sessionKey(serverId: string, channelId: string) {
  return `dicePoker:${serverId}:${channelId}`;
}

export function buildDicePokerStartEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🎲 Покер на кубиках')
    .setDescription(
      '*Ставки → бросок → ставки → переброс → лучшая комбинация забирает банк.*\n\n' +
        DICE_POKER_RULES +
        '\n\n' +
        DICE_POKER_COMBOS +
        '\n\n**Войти** в стол, затем организатор жмёт **Старт**.',
    )
    .setImage(DICE_POKER_IMAGE)
    .setColor(UI_CONFIG.COLORS.DICE);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dicePoker:join').setLabel('Войти в стол').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dicePoker:start').setLabel('Старт').setStyle(ButtonStyle.Primary),
  );
  return { embeds: [embed], components: [row] };
}

export async function startDicePokerFromLobby(
  thread: import('discord.js').ThreadChannel,
  lobby: { serverId: string; hostId: string; memberIds: string[]; lobbyEmbedMessageId?: string },
  stake: number,
): Promise<{ ok: boolean; error?: string }> {
  const serverId = lobby.serverId;
  const channelId = thread.id;
  const config = await ensureServerConfig(serverId);
  if (!config) return { ok: false, error: 'Бот не настроен.' };
  const minBet = config.minBet ?? 10;
  const maxBet = config.maxBet ?? 10000;
  if (stake < minBet || stake > maxBet) {
    return { ok: false, error: `Взнос: ${minBet}–${maxBet} септимов.` };
  }

  const players: DicePokerPlayer[] = [];
  for (const uid of lobby.memberIds) {
    const profile = await getOrCreateProfile(serverId, uid);
    if (profile.balance < BigInt(stake)) {
      return { ok: false, error: `У <@${uid}> недостаточно септимов (баланс: ${profile.balance}).` };
    }
    players.push({
      id: uid,
      dice: [],
      rerollIndices: [],
      bet: 0,
      folded: false,
      stack: stake * 2,
    });
  }

  for (const p of players) {
    await adjustBalance({ serverId, userId: p.id, delta: -stake, reason: 'dicepoker_buyin' });
  }

  const session: DicePokerSession = {
    serverId,
    hostId: lobby.hostId,
    players,
    pot: 0,
    stake,
    phase: 'bet1',
    currentTurnIndex: 0,
    currentBet: 0,
    minBet: config.minBet ?? 10,
    respondersNeeded: players.length,
  };

  const key = sessionKey(serverId, channelId);
  await setSession(key, session);

  const embed = buildDicePokerGameEmbed(session);
  const row = buildDicePokerComponents(session);
  const payload = { embeds: [embed], components: row };

  const msgId = lobby.lobbyEmbedMessageId;
  if (msgId) {
    const msg = await thread.messages.fetch(msgId).catch(() => null);
    if (msg) {
      await msg.edit(payload).catch(() => {});
      await sendRulesToThread(thread);
      return { ok: true };
    }
  }
  await thread.send(payload).catch(() => {});
  await sendRulesToThread(thread);
  return { ok: true };
}

async function sendRulesToThread(thread: import('discord.js').ThreadChannel) {
  await thread
    .send({
      content:
        `📋 **Правила игры**\n${DICE_POKER_RULES}\n\n` +
        `${DICE_POKER_COMBOS}\n\n` +
        `**Кнопки:** Проверить / Уравнять / Поставить / Сбросить. Ход по очереди.`,
      embeds: [
        new EmbedBuilder().setImage(DICE_POKER_IMAGE).setColor(UI_CONFIG.COLORS.DICE),
      ],
    })
    .catch(() => {});
}

function buildDicePokerGameEmbed(session: DicePokerSession): EmbedBuilder {
  const lines: string[] = [];
  const pot = session.pot + session.players.reduce((s, p) => s + p.bet, 0);
  for (const p of session.players) {
    let diceStr: string;
    if (p.dice.length === 5) {
      diceStr = diceToDisplay(p.dice);
    } else if (session.phase === 'bet1') {
      diceStr = '— (до броска)';
    } else if (session.phase === 'roll1') {
      diceStr = p.dice.length ? diceToDisplay(p.dice) : '— (ждёт хода)';
    } else {
      diceStr = p.dice.length ? diceToDisplay(p.dice) : '—';
    }
    const hand = p.dice.length === 5 ? evaluateHand(p.dice) : null;
    const comboStr = hand ? COMBO_NAMES[hand.combo] : '';
    const status = p.folded ? ' (пас)' : p.bet > 0 ? ` [${p.bet}]` : '';
    lines.push(`<@${p.id}>: ${diceStr}${comboStr ? ` → ${comboStr}` : ''}${status}`);
  }
  const turnId = session.players[session.currentTurnIndex]?.id;
  let turnLine = '';
  if (session.phase !== 'reveal') {
    if (session.phase === 'roll1') {
      turnLine = `**Сейчас кидает:** <@${turnId}>\n\n`;
    } else if (session.phase === 'bet1' || session.phase === 'bet2') {
      turnLine = `**Ход:** <@${turnId}>\n\n`;
    } else if (session.phase === 'reroll') {
      turnLine = `**Переброс:** <@${turnId}>\n\n`;
    }
  }
  const desc =
    `**Пот:** ${pot} | **Стол:** ${session.stake} (макс. ставка)\n\n` +
    turnLine +
    lines.join('\n');
  let title = '🎲 Покер на кубиках';
  if (session.phase === 'reveal') {
    title = '🎲 Покер на кубиках — результат';
  }
  return new EmbedBuilder()
    .setTitle(title)
    .setDescription(desc)
    .setColor(UI_CONFIG.COLORS.DICE);
}

function buildDicePokerBetRow(session: DicePokerSession): ActionRowBuilder<ButtonBuilder> {
  const turnPlayer = session.players[session.currentTurnIndex];
  const maxBet = session.stake;
  const limitReached = session.currentBet >= maxBet;
  const toCall = session.currentBet - (turnPlayer?.bet ?? 0);
  const row = new ActionRowBuilder<ButtonBuilder>();

  if (limitReached) {
    if (toCall <= 0) {
      row.addComponents(
        new ButtonBuilder().setCustomId('dicePoker:check').setLabel('Проверить').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('dicePoker:fold').setLabel('Сбросить').setStyle(ButtonStyle.Danger),
      );
    } else {
      const callBtn = new ButtonBuilder().setCustomId('dicePoker:call').setLabel('Уравнять').setStyle(ButtonStyle.Primary);
      if (turnPlayer && turnPlayer.stack < toCall) callBtn.setDisabled(true);
      row.addComponents(callBtn, new ButtonBuilder().setCustomId('dicePoker:fold').setLabel('Сбросить').setStyle(ButtonStyle.Danger));
    }
    return row;
  }

  row.addComponents(new ButtonBuilder().setCustomId('dicePoker:check').setLabel('Проверить').setStyle(ButtonStyle.Secondary));
  if (session.currentBet > 0) {
    row.addComponents(new ButtonBuilder().setCustomId('dicePoker:call').setLabel('Уравнять').setStyle(ButtonStyle.Primary));
  }
  row.addComponents(
    new ButtonBuilder().setCustomId('dicePoker:raise').setLabel('Поставить').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('dicePoker:fold').setLabel('Сбросить').setStyle(ButtonStyle.Danger),
  );
  return row;
}

function buildDicePokerRollRow(session: DicePokerSession): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dicePoker:roll').setLabel('Кинуть').setStyle(ButtonStyle.Primary),
  );
}

/** Компоненты в зависимости от фазы: bet1/bet2 — ставки, roll1 — кнопка «Кинуть». */
function buildDicePokerComponents(session: DicePokerSession): ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] {
  if (session.phase === 'roll1') {
    return [buildDicePokerRollRow(session) as ActionRowBuilder<ButtonBuilder>];
  }
  if (session.phase === 'bet1' || session.phase === 'bet2') {
    return [buildDicePokerBetRow(session)];
  }
  if (session.phase === 'reroll') {
    return buildDicePokerRerollRow(session, session.currentTurnIndex);
  }
  return [buildDicePokerBetRow(session)];
}

function buildDicePokerRerollRow(session: DicePokerSession, playerIndex: number): ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] {
  const p = session.players[playerIndex]!;
  const options = [0, 1, 2, 3, 4].map((i) => {
    const val = p.dice[i] ?? 0;
    const sym = diceStr(val);
    return {
      label: `№${i + 1}: ${sym}`,
      value: String(i),
    };
  });
  const select = new StringSelectMenuBuilder()
    .setCustomId(`dicePoker:rerollSelect:${playerIndex}`)
    .setPlaceholder('Сколько перекинуть? Выберите кубики №1–№5')
    .setMinValues(0)
    .setMaxValues(5)
    .addOptions(options);
  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
  const rerollBtn = new ButtonBuilder()
    .setCustomId(`dicePoker:rerollAll:${playerIndex}`)
    .setLabel('Перебросить')
    .setStyle(ButtonStyle.Primary);
  const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(rerollBtn);
  return [selectRow as ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>, btnRow];
}

function getNextActiveIndex(session: DicePokerSession, from: number): number {
  const len = session.players.length;
  let i = (from + 1) % len;
  let checked = 0;
  while (checked < len) {
    if (!session.players[i]!.folded) return i;
    i = (i + 1) % len;
    checked++;
  }
  return -1;
}

function countActive(session: DicePokerSession): number {
  return session.players.filter((p) => !p.folded).length;
}

export async function handleDicePokerButton(interaction: ButtonInteraction) {
  if (!interaction.guild) return;
  const serverId = interaction.guild.id;
  const channelId = interaction.channelId;
  const userId = interaction.user.id;
  const customId = interaction.customId;

  const key = sessionKey(serverId, channelId);
  const session = await getSession<DicePokerSession>(key);
  if (!session) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сессия не найдена или игра завершена.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  if (customId === 'dicePoker:noop') return;
  if (customId === 'dicePoker:roll') {
    return handleDicePokerRoll(interaction, session, key);
  }
  if (customId === 'dicePoker:check') {
    return handleDicePokerAction(interaction, session, key, 'check');
  }
  if (customId === 'dicePoker:call') {
    return handleDicePokerAction(interaction, session, key, 'call');
  }
  if (customId === 'dicePoker:raise') {
    return handleDicePokerRaise(interaction, session, key);
  }
  if (customId === 'dicePoker:fold') {
    return handleDicePokerAction(interaction, session, key, 'fold');
  }
  const rerollAllMatch = customId.match(/^dicePoker:rerollAll:(\d+)$/);
  if (rerollAllMatch) {
    return handleDicePokerRerollAll(interaction, session, key, parseInt(rerollAllMatch[1], 10));
  }
}

async function handleDicePokerRoll(
  interaction: ButtonInteraction,
  session: DicePokerSession,
  key: string,
) {
  if (!interaction.guild) return;

  if (session.phase !== 'roll1') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не фаза броска.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  const turnPlayer = session.players[session.currentTurnIndex];
  if (!turnPlayer || turnPlayer.id !== interaction.user.id) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход <@${turnPlayer?.id ?? '?'}> — кидать кубики.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  await interaction.deferUpdate().catch(() => {});

  turnPlayer.dice = rollDice(5);
  session.respondersNeeded--;
  const nextIdx = session.players.findIndex((pl, idx) => idx > session.currentTurnIndex && !pl.folded);
  const nextIdx2 = session.players.findIndex((pl) => !pl.folded);
  const next = nextIdx >= 0 ? nextIdx : nextIdx2;

  if (session.respondersNeeded <= 0) {
    if (session.bet1ReachedLimit) {
      session.phase = 'reroll';
      session.currentBet = 0;
      session.respondersNeeded = countActive(session);
      session.currentTurnIndex = session.players.findIndex((p) => !p.folded);
      await setSession(key, session);
      const rerollRows = buildDicePokerRerollRow(session, session.currentTurnIndex);
      const embed = buildDicePokerGameEmbed(session);
      try {
        await interaction.editReply({ embeds: [embed], components: rerollRows });
      } catch {
        await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components: rerollRows }).catch(() => {});
      }
    } else {
      session.phase = 'bet2';
      session.currentBet = 0;
      session.respondersNeeded = countActive(session);
      session.currentTurnIndex = session.players.findIndex((p) => !p.folded);
      await setSession(key, session);
      const embed = buildDicePokerGameEmbed(session);
      const components = buildDicePokerComponents(session);
      try {
        await interaction.editReply({ embeds: [embed], components });
      } catch {
        await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components }).catch(() => {});
      }
    }
    return;
  }

  session.currentTurnIndex = next;
  await setSession(key, session);
  const embed = buildDicePokerGameEmbed(session);
  const components = buildDicePokerComponents(session);
  try {
    await interaction.editReply({ embeds: [embed], components });
  } catch {
    await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components }).catch(() => {});
  }
}

async function handleDicePokerAction(
  interaction: ButtonInteraction,
  session: DicePokerSession,
  key: string,
  action: 'check' | 'call' | 'fold',
) {
  if (!interaction.guild) return;

  if (session.phase !== 'bet1' && session.phase !== 'bet2') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не фаза ставок.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  const turnPlayer = session.players[session.currentTurnIndex];
  if (!turnPlayer || turnPlayer.id !== interaction.user.id) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход другого игрока.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  await interaction.deferUpdate().catch(() => {});

  if (action === 'check') {
    if (session.currentBet > 0) {
      return interaction.followUp({
        content: `${UI_CONFIG.EMOJI.ERROR} Нельзя проверить — есть ставка. Уравняйте или сбросьте.`,
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }
  }

  if (action === 'call') {
    const toCall = session.currentBet - turnPlayer.bet;
    const actual = Math.min(toCall, turnPlayer.stack);
    turnPlayer.bet += actual;
    turnPlayer.stack -= actual;
    if (actual < toCall) {
      session.currentBet = Math.min(session.stake, turnPlayer.bet);
    }
  }

  if (action === 'fold') {
    turnPlayer.folded = true;
  }

  session.respondersNeeded--;
  const next = getNextActiveIndex(session, session.currentTurnIndex);

  if (session.respondersNeeded <= 0 || countActive(session) <= 1) {
    return advanceToRerollOrReveal(interaction, session, key);
  }

  session.currentTurnIndex = next;
  if (next < 0) return advanceToRerollOrReveal(interaction, session, key);

  await setSession(key, session);
  const embed = buildDicePokerGameEmbed(session);
  const components = buildDicePokerComponents(session);
  try {
    await interaction.editReply({ embeds: [embed], components });
  } catch {
    await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components }).catch(() => {});
  }
}

async function handleDicePokerRaise(
  interaction: ButtonInteraction,
  session: DicePokerSession,
  key: string,
) {
  if (!interaction.guild) return;
  if (session.phase !== 'bet1' && session.phase !== 'bet2') {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не фаза ставок.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  const turnPlayer = session.players[session.currentTurnIndex];
  if (!turnPlayer || turnPlayer.id !== interaction.user.id) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас ход другого игрока.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  const maxBet = session.stake;
  if (session.currentBet >= maxBet) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Лимит стола (${maxBet}) достигнут. Больше ставить нельзя.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  const modal = new ModalBuilder()
    .setCustomId('dicePoker:raiseModal')
    .setTitle('Поставить')
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('amount')
          .setLabel(`Сумма (${session.currentBet + session.minBet}–${session.stake})`)
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('100')
          .setRequired(true),
      ),
    );
  await interaction.showModal(modal).catch(() => {});
}

export async function handleDicePokerRaiseModal(interaction: import('discord.js').ModalSubmitInteraction) {
  if (!interaction.guild) return;
  await interaction.deferUpdate().catch(() => {});

  const key = sessionKey(interaction.guild.id, interaction.channelId);
  const session = await getSession<DicePokerSession>(key);
  if (!session) return;

  const amount = parseInt(interaction.fields.getTextInputValue('amount') ?? '0', 10);
  if (Number.isNaN(amount) || amount < session.currentBet + session.minBet) {
    return interaction.followUp({
      content: `${UI_CONFIG.EMOJI.ERROR} Минимум ${session.currentBet + session.minBet}.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }
  const maxBet = session.stake;
  if (amount > maxBet) {
    return interaction.followUp({
      content: `${UI_CONFIG.EMOJI.ERROR} Максимум ставки — ${maxBet} септимов (банк стола).`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  const turnPlayer = session.players[session.currentTurnIndex];
  if (!turnPlayer || turnPlayer.id !== interaction.user.id) return;

  const toCall = amount - turnPlayer.bet;
  if (toCall > turnPlayer.stack) {
    return interaction.followUp({
      content: `${UI_CONFIG.EMOJI.ERROR} Недостаточно фишек (есть ${turnPlayer.stack}).`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  const actual = Math.min(toCall, turnPlayer.stack);
  turnPlayer.bet += actual;
  turnPlayer.stack -= actual;
  session.currentBet = Math.min(session.stake, actual < toCall ? turnPlayer.bet : amount);

  session.respondersNeeded = session.players.filter((p) => !p.folded && p.bet < session.currentBet).length;
  const next = getNextActiveIndex(session, session.currentTurnIndex);

  if (session.respondersNeeded <= 0 || countActive(session) <= 1) {
    return advanceToRerollOrReveal(interaction, session, key);
  }

  session.currentTurnIndex = next >= 0 ? next : getNextActiveIndex(session, 0);
  await setSession(key, session);

  const embed = buildDicePokerGameEmbed(session);
  const components = buildDicePokerComponents(session);
  try {
    await interaction.editReply({ embeds: [embed], components });
  } catch {
    await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components }).catch(() => {});
  }
}

async function advanceToRerollOrReveal(
  interaction: ButtonInteraction | import('discord.js').ModalSubmitInteraction | import('discord.js').StringSelectMenuInteraction,
  session: DicePokerSession,
  key: string,
) {
  for (const p of session.players) {
    session.pot += p.bet;
    p.bet = 0;
  }

  const activeCount = countActive(session);
  if (activeCount <= 1) {
    return revealAndEnd(interaction, session, key);
  }

  if (session.phase === 'bet1') {
    session.bet1ReachedLimit = session.currentBet >= session.stake;
    session.phase = 'roll1';
    session.respondersNeeded = activeCount;
    session.currentTurnIndex = session.players.findIndex((p) => !p.folded);
    await setSession(key, session);
    const embed = buildDicePokerGameEmbed(session);
    const components = buildDicePokerComponents(session);
    const updatePayload = () => ({ embeds: [embed], components });
    try {
      if ('editReply' in interaction && interaction.deferred) {
        await interaction.editReply(updatePayload());
      } else if ('update' in interaction) {
        await interaction.update(updatePayload());
      } else if ('message' in interaction && interaction.message) {
        await (interaction.message as import('discord.js').Message).edit(updatePayload()).catch(() => {});
      }
    } catch (_) {}
    return;
  }

  if (session.phase === 'bet2') {
    session.phase = 'reroll';
  }
  session.respondersNeeded = activeCount;
  session.currentTurnIndex = session.players.findIndex((p) => !p.folded);
  await setSession(key, session);

  const firstRerollPlayerIdx = session.currentTurnIndex;
  const rerollRows = buildDicePokerRerollRow(session, firstRerollPlayerIdx);
  const embed = buildDicePokerGameEmbed(session);
  const components = rerollRows;

  const updatePayload = () => ({ embeds: [embed], components });
  try {
    if ('editReply' in interaction && interaction.deferred) {
      await interaction.editReply(updatePayload());
    } else if ('update' in interaction) {
      await interaction.update(updatePayload());
    } else if ('message' in interaction && interaction.message) {
      await (interaction.message as import('discord.js').Message).edit(updatePayload()).catch(() => {});
    }
  } catch (_) {}
}

async function handleDicePokerRerollAll(
  interaction: ButtonInteraction,
  session: DicePokerSession,
  key: string,
  playerIndex: number,
) {
  if (!interaction.guild) return;
  if (session.phase !== 'reroll') return;

  const p = session.players[playerIndex];
  if (!p || p.id !== interaction.user.id) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не ваш ход переброса.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  await interaction.deferUpdate().catch(() => {});

  for (let i = 0; i < 5; i++) {
    p.dice[i] = crypto.randomInt(1, 7);
  }

  session.respondersNeeded--;
  const nextIdx = session.players.findIndex((pl, idx) => idx > playerIndex && !pl.folded);
  const nextIdx2 = session.players.findIndex((pl) => !pl.folded);
  const next = nextIdx >= 0 ? nextIdx : nextIdx2;

  if (session.respondersNeeded <= 0) {
    session.phase = 'reveal';
    return revealAndEnd(interaction, session, key);
  }

  session.currentTurnIndex = next;
  await setSession(key, session);

  const rerollRows = buildDicePokerRerollRow(session, next);
  const embed = buildDicePokerGameEmbed(session);
  try {
    await interaction.editReply({ embeds: [embed], components: rerollRows });
  } catch {
    await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components: rerollRows }).catch(() => {});
  }
}

export async function handleDicePokerRerollSelect(
  interaction: import('discord.js').StringSelectMenuInteraction,
) {
  if (!interaction.guild) return;

  const match = interaction.customId.match(/dicePoker:rerollSelect:(\d+)/);
  const playerIndex = match ? parseInt(match[1], 10) : -1;

  const key = sessionKey(interaction.guild.id, interaction.channelId);
  const session = await getSession<DicePokerSession>(key);
  if (!session || session.phase !== 'reroll') return;

  const p = session.players[playerIndex];
  if (!p || p.id !== interaction.user.id) {
    return interaction.reply({
      content: `${UI_CONFIG.EMOJI.ERROR} Сейчас не ваш ход переброса.`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  await interaction.deferUpdate().catch(() => {});

  const indicesToReroll = (interaction.values ?? [])
    .map((v) => parseInt(v, 10))
    .filter((i) => i >= 0 && i < 5);
  for (const i of indicesToReroll) {
    p.dice[i] = crypto.randomInt(1, 7);
  }

  session.respondersNeeded--;
  const nextIdx = session.players.findIndex((pl, idx) => idx > playerIndex && !pl.folded);
  const nextIdx2 = session.players.findIndex((pl) => !pl.folded);
  const next = nextIdx >= 0 ? nextIdx : nextIdx2;

  if (session.respondersNeeded <= 0) {
    session.phase = 'reveal';
    return revealAndEnd(interaction, session, key);
  }

  session.currentTurnIndex = next;
  await setSession(key, session);

  const rerollRows = buildDicePokerRerollRow(session, next);
  const embed = buildDicePokerGameEmbed(session);
  try {
    await interaction.editReply({ embeds: [embed], components: rerollRows });
  } catch {
    await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components: rerollRows }).catch(() => {});
  }
}

async function revealAndEnd(
  interaction: ButtonInteraction | import('discord.js').ModalSubmitInteraction | import('discord.js').StringSelectMenuInteraction,
  session: DicePokerSession,
  key: string,
) {
  const active = session.players.filter((p) => !p.folded);
  for (const p of session.players) {
    session.pot += p.bet;
    p.bet = 0;
  }

  let winner: DicePokerPlayer | null = null;
  let bestHand: DiceHand | null = null;
  for (const p of active) {
    const h = evaluateHand(p.dice);
    if (!bestHand || compareHands(h, bestHand) > 0) {
      bestHand = h;
      winner = p;
    }
  }

  const payout = session.pot;
  const guild = interaction.guild as import('discord.js').Guild;
  if (winner && guild) {
    await adjustBalance({ serverId: session.serverId, userId: winner.id, delta: payout, reason: 'dicepoker_win' });
    await logBet({
      serverId: guild.id,
      userId: winner.id,
      gameType: 'dicepoker',
      betAmount: session.stake,
      payoutAmount: payout,
      outcome: 'win',
      seed: '',
    });
  }

  await deleteSession(key);

  const embed = buildDicePokerGameEmbed({
    ...session,
    phase: 'reveal',
    players: session.players,
  });
  const winnerLine = winner
    ? `\n\n🏆 **Победитель:** <@${winner.id}> — ${COMBO_NAMES[bestHand!.combo]}! Выигрыш: **${payout}** септимов.`
    : '';
  embed.setDescription((embed.data.description ?? '') + winnerLine);

  const emptyRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('dicePoker:noop').setLabel('Игра окончена').setStyle(ButtonStyle.Secondary).setDisabled(true),
  );

  try {
    if ('editReply' in interaction && interaction.deferred) {
      await interaction.editReply({ embeds: [embed], components: [emptyRow] });
    } else if ('update' in interaction) {
      await interaction.update({ embeds: [embed], components: [emptyRow] });
    } else if ('message' in interaction && interaction.message) {
      await (interaction.message as import('discord.js').Message).edit({ embeds: [embed], components: [emptyRow] }).catch(() => {});
    }
  } catch (_) {}
}
